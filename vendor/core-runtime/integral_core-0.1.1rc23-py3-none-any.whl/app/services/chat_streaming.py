"""Shared SSE turn loop for AI chat endpoints (user + agent-initiated)."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, AsyncIterator, Dict, List, Optional, Tuple, cast

from fastapi import Request

from app.schemas.agentive.work import WorkError, WorkExecutionContext
from app.services import chat_turn_registry
from app.services.chat_providers import ChatBackendProvider, ChatTurnContext
from app.services.chat_providers.base import register_provider_cancel_hook
from app.services.chat_sse import sse_bytes
from app.services.chat_thread_events import notify_thread_stream_update
from app.services.chat_turn_registry import InFlightTurn

logger = logging.getLogger(__name__)

SSE_HEADERS = {
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


async def _await_cleanup_task(task: asyncio.Task[Any]) -> Any:
    """Wait for a durable cleanup task even when its parent is cancelled."""
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            # Preserve the parent's cancellation for its caller, but do not
            # strand run status, transcript persistence, or the thread fence.
            continue
    return task.result()


class _DeltaHumanizer:
    """Resolve raw node ids → names inside the streamed assistant text.

    Per-token deltas can split an id across chunks, so a delta is never
    humanized alone. Instead we buffer and only release text up to the last
    whitespace — a whole id (which contains no whitespace) is always complete
    before it leaves the buffer, so ``humanize_ids`` sees the full token. The
    raw deltas still flow to ``turn_events`` for persistence (which humanizes
    independently); this only cleans the LIVE wire. Best-effort and bounded to
    one trailing partial word of latency.
    """

    def __init__(
        self, *, user_id: str | None = None, workspace_id: str | None = None
    ) -> None:
        self._buf = ""
        self._user_id = user_id
        self._workspace_id = workspace_id

    async def _humanize(self, text: str) -> str:
        if not text:
            return text
        try:
            from app.services.id_resolver import humanize_ids

            return await humanize_ids(
                text, user_id=self._user_id, workspace_id=self._workspace_id
            )
        except Exception:  # noqa: BLE001
            logger.debug("chat_streaming.humanize_failed", exc_info=True)
            return text

    async def feed(self, delta: str) -> Optional[str]:
        """Buffer ``delta``; return humanized complete words (or None)."""
        self._buf += delta or ""
        cut = max(self._buf.rfind(" "), self._buf.rfind("\n"), self._buf.rfind("\t"))
        if cut < 0:
            return None
        ready, self._buf = self._buf[: cut + 1], self._buf[cut + 1 :]
        return await self._humanize(ready)

    async def flush(self) -> Optional[str]:
        """Humanize + return any buffered remainder (end of message/stream)."""
        if not self._buf:
            return None
        ready, self._buf = self._buf, ""
        return await self._humanize(ready)


# Wire codes for a turn that died with an exception. The raw exception text
# never leaves the process — it is logged with the stack; the browser gets a
# stable code plus a sentence a person can act on.
_ERROR_MESSAGES: Dict[str, str] = {
    "storage_setup_required": (
        "Integral's storage encryption is not configured correctly. Ask the "
        "installation owner to check setup and the original storage encryption "
        "key, then restart Integral. Existing keys must be preserved."
    ),
    "harness_storage_unreadable": (
        "Integral could not read its saved AI state. Ask the installation owner "
        "to verify the original storage encryption key and restore from a backup "
        "if needed. No saved work was replayed."
    ),
    "model_setup_required": (
        "Choose a model in Settings → AI Models to start using Integral AI. "
        "You can connect a cloud provider or a local Ollama model."
    ),
    "model_key_required": (
        "No model API key is configured for this workspace. "
        "Add one in Settings and try again."
    ),
    "ai_quota_exceeded": (
        "This workspace has reached its AI usage limit. Add your own model "
        "API key in Settings → Agents, or try again later."
    ),
    "walker_failed": (
        "The assistant hit an internal error before it could finish. "
        "Please try again."
    ),
    "model_context_limit": (
        "This request exceeded the selected model's context limit before it "
        "could answer. Shorten the request or start a new conversation and try again."
    ),
    "harness_usage_limit": (
        "This turn reached Integral's safe generation limit before it could "
        "finish. Start a new conversation with a shorter request and try again."
    ),
    "harness_reconciliation_required": (
        "I couldn't restore the previous assistant state safely, so its work was "
        "not replayed. Send a new message to continue, and check the current "
        "workspace state before repeating any earlier change."
    ),
    "model_configuration_invalid": (
        "Integral AI's model configuration is invalid. Check Settings → AI Models. "
        "For a server model, ask the administrator to review INTEGRAL_NATIVE_MODEL "
        "and the Ollama settings in the active installation configuration, then restart."
    ),
    "model_authentication_failed": (
        "The model provider rejected its credentials. Update the API key or model "
        "access in Settings → AI Models. For a server model, ask the administrator "
        "to check the provider credentials and restart."
    ),
    "model_endpoint_unreachable": (
        "Integral AI could not reach the model provider. Check the connection. "
        "For local Ollama, ensure it is running and the server's OLLAMA_API_BASE "
        "points to a reachable address."
    ),
    "model_empty_response": "The model did not return a reply after the available attempts. Please try again shortly.",
    "model_request_timeout": "The model provider took too long to respond. Check its availability before trying again.",
    "model_rate_limited": "The model provider's usage limit was reached. Check the provider's quota or try again later.",
    "model_unavailable": "The selected model is unavailable. Choose an available model in Settings → AI Models.",
    "model_provider_unavailable": "The model provider is temporarily unavailable. Check its status before trying again.",
    "model_request_rejected": (
        "The model provider rejected this step. Try again in this conversation. "
        "If it keeps happening, review the selected model in Settings → AI Models."
    ),
    "chat_storage_unavailable": (
        "Live chat is unavailable because this installation needs transactional "
        "storage. Ask your administrator to configure PostgreSQL for Integral."
    ),
    "chat_step_rolled_back": (
        "This step failed and its database changes were rolled back. "
        "The assistant could not complete the requested work. Review the failed "
        "step before retrying; do not assume the requested records were saved."
    ),
    "internal_error": "Something went wrong on our side. Please try again.",
    "scaffold_plan_invalid": (
        "The approved setup could not be built. Please try again."
    ),
}

_SCAFFOLD_PLAN_COACHING = " Correct the generated operation plan"


def _scaffold_plan_failure_message(exc: BaseException) -> Optional[str]:
    """User text when a build-plan retry budget is spent.

    Pydantic AI raises ``UnexpectedModelBehavior`` after ``ModelRetry``. The
    seed or plan reason is on the cause chain; the outer message only says
    the retry count was exceeded. Return that reason without the coaching
    sentence written for the model.
    """
    outer = str(getattr(exc, "message", exc))
    if "max retries" not in outer.lower():
        return None
    detail = ""
    current: Optional[BaseException] = exc
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        text = str(getattr(current, "message", current)).strip()
        coaching_at = text.find(_SCAFFOLD_PLAN_COACHING)
        if coaching_at >= 0:
            text = text[:coaching_at].strip()
        if text and (
            "does not match a declared field" in text
            or text.startswith("Operation ")
            or "approved design" in text.lower()
        ):
            detail = text
            break
        current = current.__cause__ or current.__context__
    lead = "The approved setup could not be built."
    if detail:
        return f"{lead} {detail}"
    return lead


# These current-state conflicts can happen on a first-ever conversation. Do
# not describe them as an earlier user run requiring outcome reconciliation.
_HARNESS_CURRENT_STATE_REASONS = frozenset(
    {
        "harness_session_id_collision",
        "harness_session_pointer_mismatch",
        "harness_session_pointer_missing",
        "harness_session_scope_mismatch",
        "harness_session_revision_changed",
        "harness_session_generation_conflict",
        "harness_session_edge_missing",
        "harness_session_terminal",
        "harness_checkpoint_manifest_unavailable",
        "harness_checkpoint_fence_lost",
    }
)
_HARNESS_RECOVERY_REASONS = frozenset(
    {
        "harness_model_request_unsettled",
        "harness_tool_effect_unresolved",
        "harness_recovery_reconciliation_required",
        "harness_recovery_message_unavailable",
        "harness_checkpoint_unavailable",
    }
)
_HARNESS_CURRENT_STATE_MESSAGE = (
    "The assistant could not safely complete this response. "
    "Please send your message again."
)


def classify_turn_exception(
    exc: BaseException, *, provider: ChatBackendProvider | None = None
) -> Tuple[str, str]:
    """Map an exception raised mid-stream to ``(code, user_facing_message)``."""
    try:
        from app.api.errors import ResourceConflictError, ServiceUnavailableError

        if (
            isinstance(exc, ServiceUnavailableError)
            and getattr(exc, "details", {}).get("reason")
            == "native_model_not_configured"
        ):
            return "model_setup_required", _ERROR_MESSAGES["model_setup_required"]

        if (
            isinstance(exc, ServiceUnavailableError)
            and getattr(exc, "details", {}).get("reason")
            == "native_model_configuration_invalid"
        ):
            return (
                "model_configuration_invalid",
                _ERROR_MESSAGES["model_configuration_invalid"],
            )

        if (
            isinstance(exc, ServiceUnavailableError)
            and getattr(exc, "details", {}).get("reason")
            == "native_storage_encryption_not_configured"
        ):
            return "storage_setup_required", _ERROR_MESSAGES["storage_setup_required"]

        if isinstance(exc, ResourceConflictError):
            details = getattr(exc, "details", {})
            reason = details.get("reason") if isinstance(details, dict) else None
            if isinstance(reason, str) and reason.startswith("harness_"):
                # Log only a fixed host reason code. Exception text/details
                # can contain private data and never belong in this diagnostic.
                safe_reason = (
                    reason
                    if reason
                    in _HARNESS_CURRENT_STATE_REASONS | _HARNESS_RECOVERY_REASONS
                    else "harness_unclassified_conflict"
                )
                logger.warning("Native chat authority guard denied: %s", safe_reason)
                code = "harness_reconciliation_required"
                message = (
                    _HARNESS_CURRENT_STATE_MESSAGE
                    if reason in _HARNESS_CURRENT_STATE_REASONS
                    else _ERROR_MESSAGES[code]
                )
                return code, message
    except Exception:  # noqa: BLE001 — keep error reporting best-effort
        pass

    from app.services.app_operations.transaction_scope import (
        OperationTransactionRolledBack,
        OperationTransactionUnavailable,
    )

    if isinstance(exc, OperationTransactionRolledBack):
        return "chat_step_rolled_back", _ERROR_MESSAGES["chat_step_rolled_back"]
    if isinstance(exc, OperationTransactionUnavailable):
        return "chat_storage_unavailable", _ERROR_MESSAGES["chat_storage_unavailable"]

    model_key_exc: Optional[type] = None
    try:
        from app.services.model_credential_resolver import (
            ModelKeyRequiredError as _ModelKeyRequiredError,
        )

        model_key_exc = _ModelKeyRequiredError
    except Exception:  # noqa: BLE001 — resolver is optional at import time
        model_key_exc = None
    if model_key_exc is not None and isinstance(exc, model_key_exc):
        code = "model_key_required"
    else:
        try:
            from app.api.errors import QuotaExceededError as _QuotaExceededError

            if isinstance(exc, _QuotaExceededError):
                code = "ai_quota_exceeded"
                msg = str(exc).strip()
                return code, msg or _ERROR_MESSAGES[code]
        except Exception:  # noqa: BLE001
            pass
        scaffold_message = _scaffold_plan_failure_message(exc)
        if scaffold_message:
            return "scaffold_plan_invalid", scaffold_message
        classify_provider_error = getattr(provider, "classify_exception", None)
        provider_code = None
        if callable(classify_provider_error):
            try:
                provider_code = classify_provider_error(exc)
            except Exception:  # noqa: BLE001 — classification must not mask failure
                logger.debug(
                    "chat_streaming.provider_error_classification_failed", exc_info=True
                )
        code = (
            provider_code
            if isinstance(provider_code, str) and provider_code in _ERROR_MESSAGES
            else "internal_error"
        )
    return code, _ERROR_MESSAGES[code]


def _register_cancel_hook(
    turn_handle: InFlightTurn, thread_id: str, provider: ChatBackendProvider
) -> None:
    """Bind host cancellation to the active provider's transport."""
    register_provider_cancel_hook(turn_handle, thread_id=thread_id, provider=provider)


async def _handle_meta_event(
    ev: Dict[str, Any],
    *,
    thread: Any,
    provider_session_seen: Optional[str],
    interact_payload: Dict[str, Any],
    persist_session,
) -> Optional[str]:
    if ev.get("clear_provider_session"):
        try:
            from app.services.chat_threads import clear_provider_session

            await clear_provider_session(thread)
        except Exception:
            logger.exception("Failed to clear orphaned provider_session_id")
        interact_payload["provider_session_id"] = None
        return None

    sid = ev.get("provider_session_id")
    if sid and sid != provider_session_seen:
        provider_session_seen = sid
        try:
            await persist_session(thread, provider_session_seen)
        except Exception:
            logger.exception("Failed to persist provider_session_id early")
    interact_payload["provider_session_id"] = sid
    iid = ev.get("provider_interaction_id")
    if iid:
        interact_payload["provider_interaction_id"] = iid
    return provider_session_seen


async def _checkpoint_on_boundary(
    turn_events: List[Dict[str, Any]],
    *,
    thread: Any,
    checkpoint_draft_index: int,
    interact_payload: Dict[str, Any],
    drafts_from_events,
    persist_assistant_drafts,
    thread_id: str,
    work_execution_context: Optional[WorkExecutionContext] = None,
) -> int:
    async def persist() -> int:
        drafts = drafts_from_events(turn_events)
        end = max(0, len(drafts) - 1)
        return await persist_assistant_drafts(
            thread,
            turn_events,
            start_index=checkpoint_draft_index,
            end_index=end,
            interact_payload=interact_payload,
        )

    try:
        async with _authorized_work_item_effect(work_execution_context):
            return await persist()
    except WorkError:
        raise
    except Exception:
        logger.exception("Failed checkpoint persist for thread=%s", thread_id)
        return checkpoint_draft_index


def _work_execution_context(
    turn_ctx: ChatTurnContext,
) -> Optional[WorkExecutionContext]:
    """Load only the server-provided durable authority from turn context."""
    extra_data = getattr(turn_ctx, "extra_data", None) or {}
    raw = extra_data.get("work_execution_context")
    if raw is None:
        return None
    return WorkExecutionContext.model_validate(raw)


async def _assert_work_authority_current(
    context: Optional[WorkExecutionContext],
) -> None:
    if context is None:
        return
    from app.agentive.services.work_items import assert_work_item_execution_current

    await assert_work_item_execution_current(context)


async def _ignore_provider_session(_thread: Any, _session_id: Optional[str]) -> None:
    """Native Harness sessions are rooted separately under WorkItem authority."""
    return None


@asynccontextmanager
async def _authorized_work_item_effect(
    context: Optional[WorkExecutionContext],
):
    """Fence one host persistence callback in the WorkItem transaction."""
    if context is None:
        yield None
        return
    from app.agentive.services.work_items import authorized_work_item_effect

    async with authorized_work_item_effect(context) as graph:
        yield graph


async def generate_chat_turn_sse(
    *,
    request: Request,
    thread: Any,
    user_id: str,
    provider: ChatBackendProvider,
    turn_handle: InFlightTurn,
    turn_ctx: ChatTurnContext,
    interact_payload: Dict[str, Any],
    drafts_from_events,
    persist_assistant_drafts,
    persist_provider_session_if_needed,
    notify_extra: Optional[Dict[str, Any]] = None,
    error_log_label: str = "AI chat stream",
    on_terminal=None,
    on_event=None,
    validate_completed=None,
) -> AsyncIterator[bytes]:
    """Run one provider stream, yielding SSE bytes until completion or cancel."""
    turn_events: List[Dict[str, Any]] = []
    checkpoint_draft_index = 0
    provider_session_seen: Optional[str] = thread.provider_session_id
    work_execution_context = _work_execution_context(turn_ctx)

    _register_cancel_hook(turn_handle, thread.id, provider)
    humanizer = _DeltaHumanizer(
        user_id=getattr(turn_ctx, "user_id", None),
        workspace_id=getattr(turn_ctx, "workspace_id", None),
    )

    persisted = False
    work_authority_rejected = False
    terminal_status = "cancelled"
    terminal_error: Optional[Dict[str, Any]] = None

    async def _flush_drafts() -> None:
        """Persist everything accumulated since the last checkpoint. Idempotent.

        Called on the normal end of stream AND from ``finally`` when the turn
        was interrupted, because tool calls have already had their real-world
        effect by the time we get here — a staged token is minted, a write is
        queued — and dropping the message that carries their results orphans
        those effects from the conversation that produced them.
        """
        nonlocal persisted
        if persisted:
            return
        persisted = True
        async with _authorized_work_item_effect(work_execution_context):
            if work_execution_context is None:
                await persist_provider_session_if_needed(thread, provider_session_seen)
            drafts = drafts_from_events(turn_events)
            await persist_assistant_drafts(
                thread,
                turn_events,
                start_index=checkpoint_draft_index,
                end_index=len(drafts),
                interact_payload=interact_payload,
            )

    async def _flush_drafts_logged() -> None:
        try:
            await _flush_drafts()
        except Exception:
            logger.exception(
                "Failed to persist interrupted turn for thread=%s", thread.id
            )

    # ``completed`` flips only when the provider iterator was drained to its
    # natural end. Anything else — client disconnect, /cancel, an exception,
    # the ASGI server cancelling us at a yield — leaves it False, and the
    # harness turn behind the iterator must then be cancelled explicitly:
    # agent runtime's walker runs as its own task and keeps calling the model and
    # dispatching tools after the stream that fed it is gone.
    completed = False
    cancelled = False
    try:
        await _assert_work_authority_current(work_execution_context)
        yield sse_bytes(
            "interact-context",
            {"type": "interact-context", "payload": interact_payload},
        )

        # ``aclosing`` runs the provider generator's ``finally`` blocks (the
        # scope/focus ContextVar resets in agent runtime_provider) in THIS task's
        # context when the loop exits early. Left to the event loop's
        # asyncgen finalizer they run in a different Context and
        # ``ContextVar.reset(token)`` raises.
        async with contextlib.aclosing(
            cast(
                AsyncGenerator[Dict[str, Any], None],
                provider.stream_turn(turn_ctx),
            )
        ) as stream:
            try:
                async for ev in stream:
                    if (
                        await request.is_disconnected()
                        or turn_handle.cancel_event.is_set()
                    ):
                        cancelled = True
                        break

                    await _assert_work_authority_current(work_execution_context)

                    if ev.get("type") == "_meta":
                        async with _authorized_work_item_effect(work_execution_context):
                            provider_session_seen = await _handle_meta_event(
                                ev,
                                thread=thread,
                                provider_session_seen=provider_session_seen,
                                interact_payload=interact_payload,
                                persist_session=(
                                    persist_provider_session_if_needed
                                    if work_execution_context is None
                                    else _ignore_provider_session
                                ),
                            )
                        continue

                    turn_events.append(ev)  # raw events drive persistence

                    if ev.get("type") == "error":
                        terminal_status = "failed"
                        terminal_error = {
                            "code": str(ev.get("code") or "provider_error"),
                            "message": str(ev.get("message") or "Provider failed"),
                        }

                    # Execution receipts are deliberately written only for
                    # model/tool boundaries, never for token deltas. A failed
                    # observability write must not turn a successful provider
                    # response into a chat failure.
                    if on_event is not None:
                        try:
                            async with _authorized_work_item_effect(
                                work_execution_context
                            ):
                                await on_event(ev, ordinal=len(turn_events))
                        except WorkError:
                            raise
                        except Exception:
                            logger.exception(
                                "Failed to persist run event for thread=%s", thread.id
                            )

                    # Stream assistant text through the id-humanizing buffer
                    # so the live bubble never shows a raw n.<Type>.<hex> id.
                    # Raw deltas still went to turn_events above.
                    if ev.get("type") == "text-delta":
                        ready = await humanizer.feed(ev.get("delta") or "")
                        if ready:
                            await _assert_work_authority_current(work_execution_context)
                            yield sse_bytes(
                                "text-delta", {"type": "text-delta", "delta": ready}
                            )
                        continue

                    # Any non-text event marks a boundary for buffered text —
                    # flush the humanized remainder before the event so
                    # ordering is preserved.
                    pending = await humanizer.flush()
                    if pending:
                        await _assert_work_authority_current(work_execution_context)
                        yield sse_bytes(
                            "text-delta", {"type": "text-delta", "delta": pending}
                        )

                    if ev.get("type") == "message-boundary":
                        checkpoint_draft_index = await _checkpoint_on_boundary(
                            turn_events,
                            thread=thread,
                            checkpoint_draft_index=checkpoint_draft_index,
                            interact_payload=interact_payload,
                            drafts_from_events=drafts_from_events,
                            persist_assistant_drafts=persist_assistant_drafts,
                            thread_id=thread.id,
                            work_execution_context=work_execution_context,
                        )

                    await _assert_work_authority_current(work_execution_context)
                    yield sse_bytes(ev["type"], ev)
                else:
                    completed = True
            finally:
                # Before ``aclosing`` closes the provider generator: the
                # embed transport unregisters its walker task in its own
                # ``finally``, so the cancel hook (embed.cancel_interact
                # keyed by thread_id) only finds the walker while the
                # generator is still open.
                if not completed:
                    turn_handle.cancel()

        # Flush any trailing buffered text at end of stream.
        pending = await humanizer.flush()
        if pending:
            await _assert_work_authority_current(work_execution_context)
            yield sse_bytes("text-delta", {"type": "text-delta", "delta": pending})

        if completed and terminal_status != "failed" and validate_completed:
            validation_error = await validate_completed(turn_events)
            if validation_error:
                terminal_status = "failed"
                terminal_error = validation_error
                error_event = {"type": "error", **validation_error}
                turn_events.append(error_event)
                await _assert_work_authority_current(work_execution_context)
                yield sse_bytes("error", error_event)

        try:
            await _flush_drafts()
        except WorkError:
            raise
        except Exception:
            logger.exception(
                "Failed to persist assistant message for thread=%s",
                thread.id,
            )

        if cancelled:
            terminal_status = "cancelled"
            await _assert_work_authority_current(work_execution_context)
            yield sse_bytes(
                "status",
                {"type": "status", "status": "cancelled", "text": "Turn cancelled."},
            )

        elif completed and terminal_status != "failed":
            terminal_status = "succeeded"

    except asyncio.CancelledError:
        raise
    except WorkError as exc:
        work_authority_rejected = True
        terminal_status = (
            "cancelled"
            if exc.code
            in {"work.cancelled", "work.lease_lost", "work.deadline_exceeded"}
            else "failed"
        )
        terminal_error = {"code": exc.code, "message": exc.message}
        raise
    except Exception as exc:
        logger.exception("%s failed for thread=%s", error_log_label, thread.id)
        code, message = classify_turn_exception(exc, provider=provider)
        error_event = {"type": "error", "code": code, "message": message}
        terminal_status = "failed"
        terminal_error = {"code": code, "message": message}
        # Persist the failure as part of the assistant turn so the transcript
        # shows WHY there is no answer after a reload, instead of a user
        # message with nothing under it.
        turn_events.append(error_event)
        await _flush_drafts_logged()
        yield sse_bytes("error", error_event)
    finally:
        if not completed and not work_authority_rejected and not persisted:
            if not any(event.get("type") == "error" for event in turn_events):
                # A tool can commit before its return event or final prose.
                # Preserve uncertainty explicitly rather than a blank turn;
                # the next request must read current state before retrying.
                turn_events.append(
                    {
                        "type": "error",
                        "code": "turn.interrupted",
                        "message": (
                            "The response was interrupted. Some work may have "
                            "completed; check the current records before retrying."
                        ),
                    }
                )
        # The turn can end without reaching the persist above: the ASGI server
        # cancels this generator at its `yield` when the client disconnects
        # (navigation, tab close, a routine switching threads), so the
        # CancelledError skips straight here. Everything since the last
        # message-boundary checkpoint would be lost — observed in the wild as a
        # staged change with no card, because commit_batch had run but the
        # message carrying its token never landed.
        #
        # Run the flush as its own task and shield it: awaiting directly during
        # cancellation re-raises immediately. If the shield is cancelled the
        # inner task still completes, and it logs its own failures.
        if not persisted and turn_events and not work_authority_rejected:
            flush_task = asyncio.create_task(_flush_drafts_logged())
            try:
                await _await_cleanup_task(flush_task)
            except Exception:
                logger.exception(
                    "Unexpected error flushing interrupted turn for thread=%s",
                    thread.id,
                )
        if on_terminal is not None:
            logger.info(
                "chat turn terminalizing thread=%s status=%s",
                thread.id,
                terminal_status,
            )

            async def _persist_terminal() -> None:
                async with _authorized_work_item_effect(work_execution_context):
                    await on_terminal(terminal_status, terminal_error)

            terminal_task = asyncio.create_task(_persist_terminal())
            try:
                await _await_cleanup_task(terminal_task)
            except WorkError:
                logger.info(
                    "Skipped stale WorkItem terminal callback for thread=%s",
                    thread.id,
                )
            except Exception:
                logger.exception(
                    "Failed to persist terminal run for thread=%s", thread.id
                )
        if work_execution_context is None:
            # Keep the thread fenced until its durable execution status is
            # terminal. Otherwise an immediate follow-up can begin recovery
            # while the prior AgentRun still says `running` and cannot yet be
            # admitted by the safe-resume checks.
            release_task = asyncio.create_task(
                chat_turn_registry.release_turn(thread.id)
            )
            await _await_cleanup_task(release_task)
            logger.info("chat turn released thread=%s", thread.id)
            await notify_thread_stream_update(
                user_id,
                thread.id,
                status="completed",
                workspace_id=getattr(thread, "workspace_id", None) or None,
                turn_id=turn_handle.turn_id,
                extra=notify_extra,
            )

    # EOF is not a reliable application-level completion signal: proxies and
    # browser stream readers may keep a response body alive briefly after the
    # server has finished the turn. Send an explicit acknowledgement only
    # after terminal cleanup and any request-owned turn-fence release have run.
    # Clients can then settle immediately without guessing from transport EOF.
    yield sse_bytes(
        "turn-settled",
        {"type": "turn-settled", "status": terminal_status},
    )
