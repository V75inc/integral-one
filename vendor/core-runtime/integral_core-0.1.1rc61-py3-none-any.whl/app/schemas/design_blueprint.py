"""Typed App design blueprint recorded by ``integral_propose_design`` (W1.3).

The markdown preview is what the user reads; the blueprint is what the builder
and later verification compare against. Every constituent carries an ``id``
that stays stable across amendments, so a revision is a diff of item IDs
rather than a re-read of prose. Optional constituents are absent or empty;
platform defaults the build relies on are listed explicitly.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Annotated, Any, Dict, Iterator, List, Literal, Optional, Tuple

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    model_validator,
)

from app.schemas.app_home import ScaffoldHome

ItemId = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=r"^[a-z][a-z0-9_]*(?:[.-][a-z0-9_]+)*$",
        max_length=96,
    ),
]
FieldKey = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True, pattern=r"^[a-z][a-z0-9_]*$", max_length=64
    ),
]
Label = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)
]
Text = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=2000)
]


_RELATION_KEYS = (
    "target",
    "target_entry_types",
    "target_track",
    "target_track_template",
    "track_template",
    "target_track_types",
    "allow_cross_track",
    "many",
)


class _Item(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: ItemId = Field(
        description=(
            "Stable ID unique across every item in this whole blueprint. "
            "Use namespaced IDs such as track.tools.field.notes and "
            "track.checkouts.field.notes; do not reuse an ID on another item."
        )
    )


class BlueprintApp(_Item):
    name: Label
    description: Optional[Text] = None
    home: Optional[ScaffoldHome] = None


class BlueprintGoal(_Item):
    text: Text


class BlueprintActor(_Item):
    name: Label
    role: Optional[Text] = None


class BlueprintRelation(BaseModel):
    """Lookup (``target: entry``) or expansion (``target: track``) reference."""

    model_config = ConfigDict(extra="forbid")

    target: Literal["entry", "track"]
    target_entry_types: List[Label] = Field(
        default_factory=list,
        description=(
            "For target='entry', REQUIRED and non-empty: names of the entry "
            "types this lookup can reference."
        ),
    )
    target_track: Optional[ItemId] = None
    target_track_template: Optional[ItemId] = None
    target_track_types: List[Label] = Field(
        default_factory=list,
        description=(
            "For target='entry', names Tracks that may contain the target entry "
            "types."
        ),
    )
    allow_cross_track: Optional[bool] = None
    many: bool = False

    @model_validator(mode="after")
    def _shape(self) -> "BlueprintRelation":
        if self.target == "entry" and not self.target_entry_types:
            raise ValueError("an entry relation names target_entry_types")
        if self.target == "track" and not self.target_track_template:
            raise ValueError("a track relation names target_track_template")
        if self.target == "entry" and self.target_track_template:
            raise ValueError("target_track_template is only for target: track")
        return self


class BlueprintField(_Item):
    key: FieldKey
    name: Label
    type: Label
    required: bool = False
    options: List[Label] = Field(
        default_factory=list, validation_alias=AliasChoices("options", "enum")
    )
    relation: Optional[BlueprintRelation] = None

    @model_validator(mode="before")
    @classmethod
    def _fold_relation_keys(cls, data: Any) -> Any:
        """Planners put relation keys on the field or under ``config``."""
        if not isinstance(data, dict) or data.get("type") != "relation":
            return data
        data = dict(data)
        config = data.pop("config", None)
        relation = dict(data.get("relation") or {})
        for source in (config if isinstance(config, dict) else {}, data):
            for key in _RELATION_KEYS:
                if key in source:
                    relation.setdefault(key, source[key])
                    if source is data:
                        data.pop(key)
        if "track_template" in relation:
            relation.setdefault("target_track_template", relation.pop("track_template"))
        if relation.get("target_track_template") and not relation.get("target"):
            relation["target"] = "track"
        if relation:
            data["relation"] = relation
        return data

    @model_validator(mode="after")
    def _relation_matches_type(self) -> "BlueprintField":
        if (self.type == "relation") != (self.relation is not None):
            raise ValueError(f"field {self.key}: relation config iff type is relation")
        return self


class BlueprintEntryType(_Item):
    name: Label
    fields: List[BlueprintField] = Field(default_factory=list)


class BlueprintTagGroup(_Item):
    name: Label
    tags: List[Label] = Field(min_length=1)


class BlueprintTrack(_Item):
    name: Label
    description: Optional[Text] = None
    entry_types: List[BlueprintEntryType] = Field(min_length=1)
    tag_groups: List[BlueprintTagGroup] = Field(default_factory=list)


class BlueprintTrackTemplate(BlueprintTrack):
    """Detail-Track shape provisioned per parent Entry through ``ANCHORS``."""


class BlueprintView(_Item):
    track: ItemId
    name: Label
    type: Label
    decision: Text
    config: Dict[str, Any] = Field(default_factory=dict)
    is_default: bool = False


class BlueprintWidget(_Item):
    title: Label
    type: Label
    track: Optional[ItemId] = None
    decision: Text


class BlueprintDashboard(_Item):
    name: Label
    widgets: List[BlueprintWidget] = Field(min_length=1)


class BlueprintSkill(_Item):
    name: Label
    purpose: Text
    visibility: Literal["app_private", "workspace"] = "app_private"


class BlueprintRoutine(_Item):
    name: Label
    purpose: Text
    cron: Optional[Label] = None
    run_at: Optional[Label] = None

    @model_validator(mode="after")
    def _one_schedule(self) -> "BlueprintRoutine":
        if bool(self.cron) == bool(self.run_at):
            raise ValueError(f"routine {self.id}: give exactly one of cron or run_at")
        return self


class BlueprintSeed(_Item):
    track: ItemId
    title: Label
    fields: Dict[FieldKey, Any] = Field(default_factory=dict)
    tags: List[Label] = Field(default_factory=list)


class BlueprintOperationField(BaseModel):
    """One typed input or output on a custom action. Names are field keys."""

    model_config = ConfigDict(extra="forbid")

    name: FieldKey
    type: Literal["string", "number", "integer", "boolean", "object", "array"] = (
        "string"
    )
    required: bool = False


class BlueprintOperation(_Item):
    name: Label
    purpose: Text
    # Optional contract the model already knows. Absent fields are filled
    # when the operation spec is emitted; the prose purpose stays the source.
    inputs: List[BlueprintOperationField] = Field(default_factory=list)
    outputs: List[BlueprintOperationField] = Field(default_factory=list)
    policy_action: Optional[Label] = None
    effects: List[Text] = Field(default_factory=list)
    conflict_rule: Optional[Text] = None


class BlueprintAccess(_Item):
    subject: Label
    grant: Label


class BlueprintOpenDecision(_Item):
    question: Text


class BlueprintPlatformDefault(_Item):
    kind: Label
    detail: Text


class DesignBlueprint(BaseModel):
    """Machine form of an approved App design; see module docstring."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    app: BlueprintApp
    goals: List[BlueprintGoal] = Field(default_factory=list)
    actors: List[BlueprintActor] = Field(default_factory=list)
    # An explicitly reviewed blank App is a valid container. Keep the list
    # required so an omitted structure cannot silently become a blank design.
    tracks: List[BlueprintTrack]
    track_templates: List[BlueprintTrackTemplate] = Field(default_factory=list)
    views: List[BlueprintView] = Field(default_factory=list)
    dashboard: Optional[BlueprintDashboard] = None
    skills: List[BlueprintSkill] = Field(default_factory=list)
    routines: List[BlueprintRoutine] = Field(default_factory=list)
    seeds: List[BlueprintSeed] = Field(default_factory=list)
    operations: List[BlueprintOperation] = Field(default_factory=list)
    access: List[BlueprintAccess] = Field(default_factory=list)
    open_decisions: List[BlueprintOpenDecision] = Field(default_factory=list)
    platform_defaults: List[BlueprintPlatformDefault] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _derive_schema_ids(cls, data: Any) -> Any:
        """Entry types, fields and tag groups may omit ``id``; derive it from the Track id.

        A field's key is already its identity within a Track, so
        ``<track_id>.<key>`` is as stable as the key itself.
        """
        if not isinstance(data, dict):
            return data
        data = dict(data)
        for section in ("tracks", "track_templates"):
            tracks = data.get(section)
            if not isinstance(tracks, list):
                continue
            filled_tracks = []
            for track in tracks:
                if not isinstance(track, dict) or not isinstance(track.get("id"), str):
                    filled_tracks.append(track)
                    continue
                entry_types = []
                for entry_type in track.get("entry_types") or []:
                    if not isinstance(entry_type, dict):
                        entry_types.append(entry_type)
                        continue
                    slug = "_".join(str(entry_type.get("name") or "").lower().split())
                    fields = [
                        (
                            {**f, "id": f"{track['id']}.{f['key']}"}
                            if isinstance(f, dict)
                            and "id" not in f
                            and isinstance(f.get("key"), str)
                            else f
                        )
                        for f in entry_type.get("fields") or []
                    ]
                    entry_types.append(
                        {
                            "id": f"{track['id']}.type.{slug}",
                            **entry_type,
                            "fields": fields,
                        }
                    )
                tag_groups = [
                    (
                        {
                            "id": f"{track['id']}.tags."
                            + re.sub(
                                r"[^a-z0-9]+", "_", str(group.get("name") or "").lower()
                            ).strip("_"),
                            **group,
                        }
                        if isinstance(group, dict)
                        else group
                    )
                    for group in track.get("tag_groups") or []
                ]
                filled_tracks.append(
                    {**track, "entry_types": entry_types, "tag_groups": tag_groups}
                )
            data[section] = filled_tracks

        # Field IDs are blueprint-global, while natural field keys such as
        # ``notes`` commonly recur on separate Tracks. If a model reuses a
        # field ID, namespace all colliding fields by their stable Track/key
        # identity. This mirrors the canonical IDs already derived for fields
        # that omit ``id`` and leaves all non-colliding explicit IDs intact.
        all_tracks = [
            track
            for section in ("tracks", "track_templates")
            for track in data.get(section, [])
            if isinstance(track, dict)
        ]
        field_ids = [
            field.get("id")
            for track in all_tracks
            for entry_type in track.get("entry_types") or []
            if isinstance(entry_type, dict)
            for field in entry_type.get("fields") or []
            if isinstance(field, dict) and isinstance(field.get("id"), str)
        ]
        repeated_field_ids = {
            item_id for item_id, count in Counter(field_ids).items() if count > 1
        }
        if repeated_field_ids:
            for track in all_tracks:
                track_id = track.get("id")
                if not isinstance(track_id, str):
                    continue
                for entry_type in track.get("entry_types") or []:
                    if not isinstance(entry_type, dict):
                        continue
                    for field in entry_type.get("fields") or []:
                        if (
                            isinstance(field, dict)
                            and field.get("id") in repeated_field_ids
                            and isinstance(field.get("key"), str)
                        ):
                            entry_type_id = entry_type.get("id")
                            if isinstance(entry_type_id, str):
                                field["id"] = (
                                    f"{track_id}.{entry_type_id}.{field['key']}"
                                )
        return data

    def items(self) -> Iterator[Tuple[str, BaseModel]]:
        """Yield ``(item_id, constituent)`` for every identified constituent."""
        yield self.app.id, self.app
        for track in [*self.tracks, *self.track_templates]:
            yield track.id, track
            for entry_type in track.entry_types:
                yield entry_type.id, entry_type
                for field in entry_type.fields:
                    yield field.id, field
            for group in track.tag_groups:
                yield group.id, group
        for section in (
            self.goals,
            self.actors,
            self.views,
            self.skills,
            self.routines,
            self.seeds,
            self.operations,
            self.access,
            self.open_decisions,
            self.platform_defaults,
        ):
            for item in section:
                yield item.id, item
        if self.dashboard:
            yield self.dashboard.id, self.dashboard
            for widget in self.dashboard.widgets:
                yield widget.id, widget

    @model_validator(mode="after")
    def _references_resolve(self) -> "DesignBlueprint":
        track_names = {track.name.casefold() for track in self.tracks}
        if self.app.home and any(
            name.casefold() not in track_names for name in self.app.home.track_shortcuts
        ):
            raise ValueError("Home Track shortcuts must match Tracks in this blueprint")
        both = [
            t.name for t in self.track_templates if t.name.casefold() in track_names
        ]
        if both:
            raise ValueError(
                f"{', '.join(both)}: a track template is not also a Track; list it "
                "only under track_templates (its detail Tracks are created per entry)"
            )
        ids: List[str] = [item_id for item_id, _ in self.items()]
        duplicates = sorted({i for i in ids if ids.count(i) > 1})
        if duplicates:
            raise ValueError(f"item ids must be unique: {', '.join(duplicates)}")
        tracks = {track.id: track for track in self.tracks}
        templates = {template.id for template in self.track_templates}
        names = [track.name.casefold() for track in self.tracks]
        if len(set(names)) != len(names):
            raise ValueError("track names must be unique")
        for track in [*self.tracks, *self.track_templates]:
            keys = [f.key for et in track.entry_types for f in et.fields]
            if len(set(keys)) != len(keys):
                raise ValueError(f"track {track.id}: field keys must be unique")
            for field in (f for et in track.entry_types for f in et.fields):
                relation = field.relation
                if (
                    relation
                    and relation.target_track
                    and relation.target_track not in tracks
                ):
                    raise ValueError(f"field {field.id}: unknown target_track")
                if (
                    relation
                    and relation.target_track_template
                    and relation.target_track_template not in templates
                ):
                    raise ValueError(f"field {field.id}: unknown target_track_template")
        anchored = {
            f.relation.target_track_template
            for track in self.tracks
            for et in track.entry_types
            for f in et.fields
            if f.relation and f.relation.target_track_template
        }
        unanchored = ", ".join(sorted(templates - anchored))
        if unanchored:
            raise ValueError(
                f"track template {unanchored} is anchored by no field: give the "
                "parent entry type a relation field {type: relation, relation: "
                "{target: track, target_track_template: <template id>}}"
            )
        widget_tracks = [
            w.track for w in (self.dashboard.widgets if self.dashboard else [])
        ]
        for label, track_id in [
            *((f"view {v.id}", v.track) for v in self.views),
            *((f"seed {s.id}", s.track) for s in self.seeds),
            *(("dashboard widget", t) for t in widget_tracks if t),
        ]:
            if track_id in templates:
                raise ValueError(
                    f"{label}: {track_id} is a track template; views, seeds and "
                    "widgets on its per-entry detail Tracks are not buildable yet, "
                    "so drop this item (each detail Track still gets its Feed)"
                )
            if track_id not in tracks:
                raise ValueError(f"{label}: unknown track {track_id}")
        default_tracks = [v.track for v in self.views if v.is_default]
        doubled = sorted({t for t in default_tracks if default_tracks.count(t) > 1})
        if doubled:
            raise ValueError(
                f"track {', '.join(doubled)}: only one view per track is_default"
            )
        for seed in self.seeds:
            known = {f.key for et in tracks[seed.track].entry_types for f in et.fields}
            unknown = sorted(set(seed.fields) - known)
            if unknown:
                raise ValueError(
                    f"seed {seed.id}: unknown field keys {', '.join(unknown)}"
                )
            # A sample must be saveable before the design can be approved.
            # Multiple types may have different required fields; accept only
            # a type whose complete shape fits this seed, rather than merging
            # the requirements of unrelated types.
            candidates = [
                et
                for et in tracks[seed.track].entry_types
                if set(seed.fields) <= {f.key for f in et.fields}
            ]
            failures = []
            for candidate in candidates:
                missing = [
                    f.key
                    for f in candidate.fields
                    if f.required
                    and (
                        f.key not in seed.fields
                        or seed.fields[f.key] is None
                        or (
                            isinstance(seed.fields[f.key], str)
                            and not seed.fields[f.key].strip()
                        )
                        or seed.fields[f.key] == []
                    )
                    and not (f.relation and f.relation.target == "track")
                ]
                invalid = [
                    f.key
                    for f in candidate.fields
                    if f.type == "select"
                    and f.options
                    and f.key in seed.fields
                    and seed.fields[f.key] not in (None, "")
                    and seed.fields[f.key] not in f.options
                ]
                if not missing and not invalid:
                    break
                failures.append(
                    f"{candidate.name}: missing required fields {missing}; invalid choices {invalid}"
                )
            else:
                raise ValueError(
                    f"seed {seed.id} cannot be saved: "
                    + "; ".join(failures or ["fields do not match one entry type"])
                )
            vocabulary = {
                tag.casefold() for g in tracks[seed.track].tag_groups for tag in g.tags
            }
            undeclared = [t for t in seed.tags if t.casefold() not in vocabulary]
            if undeclared:
                raise ValueError(
                    f"seed {seed.id}: tags not in its track's tag_groups: "
                    + ", ".join(undeclared)
                )
        for track in [*self.tracks, *self.track_templates]:
            tags = [t.casefold() for g in track.tag_groups for t in g.tags]
            if len(set(tags)) != len(tags):
                raise ValueError(f"track {track.id}: tag names must be unique")
        return self
