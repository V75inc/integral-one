"""Compatibility boundary for the third-party Pydantic AI Harness APIs.

Integral's tenant, policy, billing, tool-catalogue, and persistence contracts
must not depend on Pydantic AI implementation details. Imports and narrowly
version-sensitive construction live here so a library upgrade can be handled
at this seam and qualified by adapter contract tests.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any, Callable

from pydantic_ai import (
    Agent,
    AgentRunResultEvent,
    BinaryContent,
    CallDeferred,
    CancellationToken,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    ModelRetry,
    ModelSettings,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    RetryPromptPart,
    RunContext,
    TextOutput,
    TextPart,
    TextPartDelta,
    ThinkingPart,
    Tool,
    ToolOutput,
    UsageLimitExceeded,
    UsageLimits,
)
from pydantic_ai.capabilities import (
    AbstractCapability,
    Capability,
    Instrumentation,
    ToolSearch,
)
from pydantic_ai.messages import (
    EnqueuedMessagesEvent,
    LoadCapabilityCallPart,
    LoadCapabilityReturnPart,
    ModelMessagesTypeAdapter,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    SystemPromptPart,
    ToolAvailabilityDeltaPart,
    ToolCallPart,
    ToolReturn,
    ToolReturnPart,
    UserPromptPart,
    post_compaction_window,
)
from pydantic_ai.models import InstructionPart
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.litellm import LiteLLMProvider
from pydantic_ai.tools import DeferredToolRequests, DeferredToolResults
from pydantic_ai.workspaces import LocalWorkspaceBackend
from pydantic_ai_harness import Planning, Skills, StepPersistence
from pydantic_ai_harness.compaction import (
    ClearToolResults,
    SummarizingCompaction,
    TieredCompaction,
    WarnNearLimits,
)
from pydantic_ai_harness.conversation_search import (
    ConversationSearch,
    SnapshotHistorySource,
)
from pydantic_ai_harness.planning import PlanItem, PlanStore, TaskStatus
from pydantic_ai_harness.step_persistence import (
    ContinuableSnapshot,
    RunRecord,
    StepEvent,
    StepStore,
    ToolEffectRecord,
    continue_run,
)
from pydantic_core import SchemaValidator, core_schema, to_jsonable_python
from pydantic_graph import End

from app.agentive.harness.contracts import HarnessExecutionScope
from app.agentive.harness.pydantic_context import (
    IntegralContextAdmission,
    IntegralContextLifecycle,
    IntegralContextOverflow,
    IntegralContextPolicy,
    account_context_reclaim,
    active_turn_start,
    protected_work_start,
    request_estimate,
)
from app.agentive.harness.turn_progress import FINAL_RESPONSE_FALLBACK, TurnProgress


def final_response_reserved(ctx: RunContext[Any]) -> bool:
    """Reserve the final permitted model request for a tool-free handoff.

    Read the framework's live allowance, including adaptive-request deductions;
    never increase the budget or infer intent from the user's words.
    """
    limits = getattr(ctx, "usage_limits", None)
    limit = getattr(limits, "request_limit", None)
    usage = getattr(ctx, "usage", None)
    if (
        isinstance(limit, int)
        and limit > 1
        and getattr(usage, "requests", 0) >= limit - 1
    ):
        return True
    tool_limit = getattr(limits, "tool_calls_limit", None)
    if isinstance(tool_limit, int) and tool_limit > 1:
        if getattr(usage, "tool_calls", 0) >= max(
            1, tool_limit - min(4, tool_limit // 4)
        ):
            return True
    token_limit = getattr(limits, "total_tokens_limit", None)
    if isinstance(token_limit, int):
        used = getattr(usage, "total_tokens", 0)
        # Budget for the next prompt grows with history. Reserve the cost of
        # another response before the framework rejects it after generation.
        last_input = next(
            (
                m.usage.input_tokens
                for m in reversed(getattr(ctx, "messages", ()))
                if isinstance(m, ModelResponse)
            ),
            0,
        )
        if used and used + max(last_input * 2, 2048) >= token_limit:
            return True
    return False


class IntegralLimitWarnings(AbstractCapability):
    """Project native usage warnings into dynamic instructions.

    Capture public queued system parts on a disposable projection. The native
    provider lowering can otherwise turn them into extra user input, which
    must never become a task/compaction boundary in Integral's working history.
    """

    async def before_model_request(self, ctx, request_context):
        limits = ctx.usage_limits
        requests = getattr(limits, "request_limit", None)
        tokens = getattr(limits, "total_tokens_limit", None)
        requests = requests if isinstance(requests, int) and requests > 0 else None
        tokens = tokens if isinstance(tokens, int) and tokens > 0 else None
        if requests is None and tokens is None:
            return request_context
        captured = []
        projection = SimpleNamespace(
            usage=ctx.usage,
            enqueue=lambda part, **options: captured.append(part),
        )
        await WarnNearLimits(
            max_iterations=requests, max_total_tokens=tokens, warning_threshold=0.6
        ).before_model_request(
            projection,
            replace(request_context, messages=[ModelRequest(parts=[])]),
        )
        warning = "\n".join(
            part.content for part in captured if isinstance(part, SystemPromptPart)
        )
        if warning:
            parameters = request_context.model_request_parameters
            request_context.model_request_parameters = replace(
                parameters,
                instruction_parts=[
                    *(parameters.instruction_parts or []),
                    InstructionPart(
                        warning, dynamic=True, name="integral-limit-warning"
                    ),
                ],
            )
        return request_context


@dataclass
class IntegralToolDisclosure(ToolSearch):
    """Use unified catalog search with framework-owned deferred disclosure.

    Search returns ``ToolReturn.tools``; Pydantic AI records and replays that
    availability itself. Supported ToolSearch extension points and toolset
    filtering remove the duplicate search entrypoint, without altering skill
    loading, history or library code. Used only with search_capabilities.
    """

    turn_progress: TurnProgress | None = None
    require_initial_search: bool = True
    pending_decision_tool: str | None = None
    continuation_tools: frozenset[str] = frozenset()
    workflow_skill_ids: frozenset[str] = frozenset()
    recovery_read_tools: frozenset[str] = frozenset({"integral_describe_capabilities"})

    def get_native_tools(self):
        return []

    async def prepare_tools(self, ctx, tool_defs):
        """Advertise exact loadable procedure IDs through the public schema hook.

        A free-text loader encouraged invented names, followed by a terminal
        framework retry error. This is disclosure, not authority: the native
        loader and broker still admit the current capability and every effect.
        """
        prepared = await super().prepare_tools(ctx, tool_defs)
        self._observe_discovery(ctx)
        if final_response_reserved(ctx) or (
            self.turn_progress and self.turn_progress.should_finalize
        ):
            # Withhold function schemas through the supported ToolSearch hook.
            # Some providers ignore tool_choice=none while tools remain in the
            # request, repeatedly selecting schema reads instead of synthesizing
            # the retained evidence. Disclosure is invocation-local; Core's
            # effect admission and durable availability remain unchanged.
            return []
        current = set(getattr(ctx, "capabilities", {}))
        available = (self.workflow_skill_ids & current) - ctx.active_capability_ids
        if not available:
            return prepared
        # Prefer the last search's small offered set. A different authorized
        # workflow remains discoverable through another capability search.
        turn_start = _active_turn_start(ctx.messages)
        for message in reversed(ctx.messages[turn_start or 0 :]):
            if not isinstance(message, ModelRequest):
                continue
            found = None
            for part in reversed(message.parts):
                if (
                    isinstance(part, ToolReturnPart)
                    and part.tool_name == "search_capabilities"
                    and isinstance(part.content, dict)
                    and not part.content.get("error")
                ):
                    found = {
                        item.get("load_with", {}).get("id")
                        for item in part.content.get("results", ())
                        if isinstance(item, dict)
                        and item.get("kind") == "skill"
                        and isinstance(item.get("load_with"), dict)
                        and item["load_with"].get("tool") == "load_capability"
                    }
                    break
            if found is not None:
                offered = available.intersection(found)
                if offered:
                    available = offered
                break
        result = []
        for definition in prepared:
            if definition.name != "load_capability":
                result.append(definition)
                continue
            schema = definition.parameters_json_schema
            properties = schema.get("properties", {})
            if not isinstance(properties.get("id"), dict):
                result.append(definition)
                continue
            result.append(
                replace(
                    definition,
                    parameters_json_schema={
                        **schema,
                        "properties": {
                            **properties,
                            "id": {
                                **properties["id"],
                                "enum": sorted(available),
                                "description": "Choose an exact offered skill ID; do not invent a name.",
                            },
                        },
                    },
                )
            )
        return result

    def get_model_settings(self):
        """Require initial discovery through the library's dynamic tool choice.

        Reuse framework-restored availability under the current Core catalogue
        and session revision. Fresh runs discover first; warm runs can use their
        loaded workflow or search for another. No user-text classifier participates.
        """
        inherited = super().get_model_settings()

        def settings(ctx: RunContext[Any]) -> ModelSettings:
            baseline = inherited(ctx) if callable(inherited) else inherited
            resolved = ModelSettings(**(baseline or {}))
            self._observe_discovery(ctx)
            if final_response_reserved(ctx) or (
                self.turn_progress and self.turn_progress.should_finalize
            ):
                resolved["tool_choice"] = "none"
                return resolved
            # A scoped pending proposal already supplies its decision tool.
            # Do not force rediscovery of a different workflow before the
            # model can interpret the reply; Core still validates that decision.
            profile = ctx.model.profile
            # Respect public model capabilities. Conservatively leave models
            # with thinking-specific restrictions on normal choice rather than
            # duplicating the library's provider/thinking resolution rules.
            if not profile.get("supports_forced_tool_choice", True) or not profile.get(
                "supports_forced_tool_choice_with_thinking", True
            ):
                return resolved
            # Public message boundaries separate the current request from
            # restored discovery. This is structural turn state, not intent
            # classification or routing based on the user's wording.
            turn_start = next(
                (
                    index
                    for index in range(len(ctx.messages) - 1, -1, -1)
                    if isinstance(ctx.messages[index], ModelRequest)
                    and any(
                        isinstance(part, UserPromptPart)
                        for part in ctx.messages[index].parts
                    )
                ),
                0,
            )
            # A Core refusal can name its read-only recovery contract. Enforce
            # that contract before another broad read; availability and live
            # broker checks still apply. Never force an effect or replay a write.
            recovery = None
            for message in ctx.messages[turn_start:]:
                if not isinstance(message, ModelRequest):
                    continue
                for part in message.parts:
                    if not isinstance(part, ToolReturnPart):
                        continue
                    content = part.content
                    if isinstance(content, dict) and content.get("error"):
                        next_tool = content.get("next_tool")
                        if next_tool in self.recovery_read_tools:
                            recovery = next_tool
                    elif part.tool_name == recovery:
                        recovery = None
            if recovery:
                recovery_available: frozenset[str] = getattr(
                    ctx, "available_tool_names", frozenset()
                )
                resolved["tool_choice"] = [
                    (
                        recovery
                        if recovery in recovery_available
                        else "search_capabilities"
                    )
                ]
                return resolved
            if self.pending_decision_tool:
                decided = any(
                    isinstance(part, ToolReturnPart)
                    and part.tool_name == self.pending_decision_tool
                    for message in ctx.messages[turn_start:]
                    if isinstance(message, ModelRequest)
                    for part in message.parts
                )
                if not decided:
                    # The primary model interprets approve/reject/no-decision
                    # against a concrete Core proposal. Questions and ambiguous
                    # replies select no-decision; no text classifier participates.
                    resolved["tool_choice"] = [self.pending_decision_tool]
                    return resolved
            if not self.require_initial_search or self.workflow_skill_ids.intersection(
                ctx.active_capability_ids
            ):
                return resolved
            searched = any(
                isinstance(part, ToolReturnPart)
                and part.tool_name == "search_capabilities"
                and not (isinstance(part.content, dict) and part.content.get("error"))
                for message in ctx.messages[turn_start:]
                if isinstance(message, ModelRequest)
                for part in message.parts
            )
            if not searched:
                available: frozenset[str] = getattr(
                    ctx, "available_tool_names", frozenset()
                )
                if "integral_get_page_context" in available:
                    # Let the model select the current-screen read on demand.
                    # The response hook below still requires discovery for
                    # arbitrary operational answers before a workflow is loaded.
                    resolved["tool_choice"] = "auto"
                elif not any(name.startswith("integral_") for name in available):
                    # Native Skills already advertises procedure descriptions.
                    # Permit a direct model-selected load instead of forcing a
                    # redundant search round before the same native loader.
                    resolved["tool_choice"] = ["search_capabilities"] + (
                        ["load_capability"] if "load_capability" in available else []
                    )
            else:
                candidates = {
                    item.get("load_with", {}).get("id")
                    for message in ctx.messages[turn_start:]
                    if isinstance(message, ModelRequest)
                    for part in message.parts
                    if isinstance(part, ToolReturnPart)
                    and part.tool_name == "search_capabilities"
                    and isinstance(part.content, dict)
                    and not part.content.get("error")
                    for item in part.content.get("results", ())
                    if isinstance(item, dict)
                    and item.get("kind") == "skill"
                    and isinstance(item.get("load_with"), dict)
                    and item["load_with"].get("tool") == "load_capability"
                }
                candidates.discard(None)
                if (
                    candidates
                    and not candidates.intersection(ctx.active_capability_ids)
                    and not self.workflow_skill_ids.intersection(
                        ctx.active_capability_ids
                    )
                ):
                    # The model chooses the fitting returned procedure. Core
                    # metadata requires an initial procedure to be loaded, without
                    # selecting it from user wording or assigning authority.
                    # Once a workflow is active, discovering a missing read
                    # must not force loading every skill that also owns it.
                    # Write handlers still enforce their applicable procedure.
                    resolved["tool_choice"] = ["load_capability"]
            return resolved

        return settings

    def _failure_message(self):
        return (
            self.turn_progress.failure_message()
            if self.turn_progress
            else FINAL_RESPONSE_FALLBACK
        )

    def _observe_discovery(self, ctx):
        if self.turn_progress is None:
            return
        # Inspect only this invocation, never restored public history.
        start = _active_turn_start(ctx.messages)
        if start is None:
            return
        available = frozenset(getattr(ctx, "available_tool_names", ())) | frozenset(
            ctx.active_capability_ids
        )
        for message in ctx.messages[start:]:
            if isinstance(message, ModelRequest):
                for part in message.parts:
                    if isinstance(part, ToolReturnPart) and part.tool_name in {
                        "search_capabilities",
                        "load_capability",
                    }:
                        self.turn_progress.observe_discovery(
                            part.tool_call_id, available
                        )

    async def after_model_request(self, ctx, *, request_context, response):
        """Enforce discovery even when a provider cannot force tool choice.

        This validates structural turn state, never the user's wording. A
        pending decision, authorized continuation or already disclosed Integral
        workflow retains its existing path. No capability is executed here.
        """
        response = await super().after_model_request(
            ctx, request_context=request_context, response=response
        )
        from app.agentive.harness.disclosure import is_public_support_text

        calls = [p for p in response.parts if p.part_kind == "tool-call"]
        finalizing = final_response_reserved(ctx) or bool(
            self.turn_progress and self.turn_progress.should_finalize
        )
        if (
            finalizing
            and (request_context.model_settings or {}).get("tool_choice") == "none"
        ):
            if calls:
                # Provider noncompliance must not produce another effect or
                # replace the conversation with a framework exception.
                return replace(response, parts=[TextPart(self._failure_message())])
            return response
        tool_limit = getattr(ctx.usage_limits, "tool_calls_limit", None)
        if (
            isinstance(tool_limit, int)
            and ctx.usage.tool_calls + len(calls) > tool_limit
        ):
            request_limit = getattr(ctx.usage_limits, "request_limit", None)
            if request_limit is None or ctx.usage.requests < request_limit:
                if self.turn_progress is None:
                    self.turn_progress = TurnProgress()
                self.turn_progress.reason = (
                    "The proposed tool batch exceeds the remaining allowance."
                )
                # Use the framework's corrective-request lifecycle once. No
                # member of the rejected batch has executed. The next request
                # is tool-free; provider noncompliance takes the fallback above.
                raise ModelRetry(
                    "This tool batch was not executed. Give a final answer now "
                    "using only earlier verified results. Identify any missing "
                    "evidence or capability precisely; do not call more tools "
                    "or claim that the rejected actions happened."
                )
            return replace(response, parts=[TextPart(self._failure_message())])

        # A fixed host support response carries no current-state assertions.
        # This permits a model-recognized disclosure request to stop without
        # forcing workspace retrieval. Arbitrary prose still requires discovery.
        if not any(
            part.part_kind == "tool-call" for part in response.parts
        ) and is_public_support_text(
            "".join(
                part.content for part in response.parts if isinstance(part, TextPart)
            )
        ):
            return response
        if (
            not self.require_initial_search
            or self.pending_decision_tool
            or self.continuation_tools
            or any(part.part_kind == "tool-call" for part in response.parts)
        ):
            return response
        turn_start = next(
            (
                index
                for index in range(len(ctx.messages) - 1, -1, -1)
                if isinstance(ctx.messages[index], ModelRequest)
                and any(
                    isinstance(part, UserPromptPart)
                    for part in ctx.messages[index].parts
                )
            ),
            0,
        )
        outcomes = [
            part
            for message in ctx.messages[turn_start:]
            if isinstance(message, ModelRequest)
            for part in message.parts
            if isinstance(part, ToolReturnPart)
        ]
        searches = [
            part
            for part in outcomes
            if part.tool_name == "search_capabilities"
            and not (isinstance(part.content, dict) and part.content.get("error"))
        ]
        # Page orientation identifies the target; it is not workflow discovery.
        # Merely exposing other schemas also does not prove they were used.
        # Keep restored active procedures and actual operational reads usable.
        if (
            not searches
            and not self.workflow_skill_ids.intersection(ctx.active_capability_ids)
            and not any(
                part.tool_name.startswith("integral_")
                and part.tool_name != "integral_get_page_context"
                for part in outcomes
            )
        ):
            raise ModelRetry(
                "This turn has not searched Integral's authorized capabilities. "
                "Call search_capabilities now with the user's requested outcome. "
                "A promise to search or request for workspace context does not "
                "complete discovery. Use the returned skill/tool schemas; only "
                "then answer or explain an observed limitation."
            )
        candidates = {
            item.get("load_with", {}).get("id")
            for part in searches
            if isinstance(part.content, dict)
            for item in part.content.get("results", ())
            if isinstance(item, dict)
            and item.get("kind") == "skill"
            and isinstance(item.get("load_with"), dict)
            and item["load_with"].get("tool") == "load_capability"
        }
        candidates.discard(None)
        if (
            candidates
            and not candidates.intersection(ctx.active_capability_ids)
            and not self.workflow_skill_ids.intersection(ctx.active_capability_ids)
            and not any(part.tool_name.startswith("integral_") for part in outcomes)
        ):
            raise ModelRetry(
                "Discovery returned available workflow skills, but none has been "
                "loaded. Call the load_capability tool now. Its id argument must "
                f"be one of these authorized ids: {', '.join(sorted(candidates))}. "
                "Choose the id whose returned description fits the user's question. "
                "Loading reads the skill instructions; it does not grant access or "
                "modify workspace records. Follow its procedure and "
                "perform the required authorized reads before answering. Do not "
                "ask the user to supply records you have not attempted to read."
            )
        return response

    def get_wrapper_toolset(self, toolset):
        def should_disclose(ctx: RunContext[Any], definition) -> bool:
            if definition.name == self.function_tool_name:
                return False
            if definition.name == "search_capabilities":
                return True
            if (
                definition.name == self.pending_decision_tool
                or definition.name in self.continuation_tools
            ):
                # This exact decision capability was supplied from current
                # Core authority, not the searchable skill catalog.
                return ctx.is_tool_available(definition)
            # Pydantic AI owns deferred skill activation through this tool.
            # Keep it available; the model-settings policy still requires the
            # catalog search first on providers that support forced choice.
            # Hiding it based on serialized tool-result shapes can strand a
            # skill recommendation and make the model retry discovery forever.
            if definition.name == "load_capability":
                return True
            if not definition.name.startswith("integral_"):
                return True
            # Restored discovery is not permission to disclose the full
            # Integral tool catalogue. Ask the framework whether this concrete
            # definition is available: it accounts for both search discovery and
            # deferred Skills ownership, including the required load-before-call
            # boundary.
            if definition.name.startswith("integral_"):
                return ctx.is_tool_available(definition)
            return True

        return super().get_wrapper_toolset(toolset).filtered(should_disclose)


def build_integral_json_schema_tool(
    *,
    function: Callable[..., Any],
    name: str,
    description: str,
    json_schema: dict[str, Any],
    prepare: Callable[..., Any] | None,
    defer_loading: bool,
    sequential: bool = False,
    max_retries: int | None = None,
) -> Tool[Any, Any]:
    """Adapt an Integral JSON Schema tool to Pydantic AI's callable tool API.

    Integral validates the authoritative, complete JSON Schema again at the
    capability broker. Pydantic calls this function with keyword arguments;
    construction uses public Tool.from_schema rather than a second schema
    engine or a private library import.
    """

    tool = Tool.from_schema(
        function=function,
        takes_ctx=True,
        sequential=sequential,
        name=name,
        description=description,
        json_schema=dict(json_schema),
    )
    tool.prepare = prepare
    tool.defer_loading = defer_loading
    tool.max_retries = max_retries
    return tool


def build_integral_run_instructions(
    base_instructions: str,
    turn_progress: TurnProgress | None = None,
) -> Callable[[RunContext[Any]], str]:
    """Add current framework-owned capability state to each model request.

    Pydantic AI Harness intentionally keeps loaded capabilities in its discovery
    catalog for prompt-cache stability. Some models repeatedly reload an active
    skill after tool results. Make the authoritative active set explicit at the
    adapter boundary so they can continue with the already-loaded procedure.
    """

    # Capture once for this invocation. Resumed/new runs build fresh instructions;
    # model requests within the run share a stable, server-owned date.
    run_started_at = datetime.now(timezone.utc)

    def instructions(ctx: RunContext[Any]) -> str:
        active_ids = sorted(ctx.active_capability_ids)
        blocks = [
            base_instructions,
            "Integral conversation style: write for everyday people. Explain what "
            "happened, what is finished or still needs approval, and one useful "
            "next step. Say 'I couldn't finish' rather than describing tool calls, "
            "turns, receipts, contracts, scope, tokens or generation limits. "
            "Keep technical details in diagnostics unless the user asks for them. "
            "Do not blame the user for a generated request that failed validation. "
            "Never promise background work, saved changes or success without "
            "evidence. If only part is done, name that part plainly. Complete "
            "requested actions in this response using the authorized procedure; "
            "a final reply saying you will prepare a proposal later does not "
            "do the work. Present a saved approval card, the verified result, "
            "a necessary question, or a concrete reason you couldn't finish. "
            "After an approval, rejection, or simple status recheck, keep the reply to one or two short "
            "sentences: confirm only the verified outcome and any unresolved "
            "problem. Do not repeat the proposal, list completed steps, recap "
            "the workflow, or add unsolicited offers. Give more detail only "
            "when the user asks or needs it to resolve a problem.",
            "Integral callable-tool contract: skill identifiers name instructions, "
            "not functions. Never invoke a skill name as a tool or convert its "
            "hyphens to underscores. Activate a chosen skill with load_capability "
            "using its exact id. Invoke only a tool whose exact name and argument "
            "schema are disclosed for this request. If a needed tool is absent, "
            "call search_capabilities to discover it before invoking it.",
            "Integral trusted clock: this invocation started at "
            f"{run_started_at.isoformat()}; current UTC date is "
            f"{run_started_at.date().isoformat()}. Use this date for today's "
            "recorded actions unless the user specifies an event date or a "
            "verified timezone requires another local date. Historical record "
            "dates and model memory do not establish today's date. Do not "
            "invent a user timezone or shift the date without a verified basis.",
            "After creating or updating resources, include the canonical result_links "
            "in the completion response. Use an App link for a multi-Track App, "
            "its sole Track for a single-Track App, the specific dashboard or Home "
            "tab when changed, and an Entry link only for exactly one affected "
            "Entry; for several Entries link their containing Track(s). "
            "Integral navigation: resource IDs are opaque. When linking saved "
            "Apps, Tracks or Entries, copy the canonical url returned by Core "
            "tools exactly, as Markdown links with readable labels. Do not split an ID, replace its dots with slashes, "
            "or invent a route or deployment hostname. Keep returned relative "
            "paths relative. If no verified url is available, use a plain "
            "record label instead of a guessed link.",
            "Integral read recovery: when Core refuses a read and returns "
            "next_tool, search for that exact canonical tool name and follow "
            "its permitted contract. A refusal is not an empty result or zero "
            "count. Do not try other broad queries, schema dumps, or archive "
            "searches to bypass it. Use only a verified matching declared "
            "query or operation with read effects. If none exists, explain "
            "that the current App exposes no permitted read for this question.",
        ]
        blocks.append(
            "Integral evidence discipline: use the smallest scoped read that answers "
            "the question. Distinguish a record's modification time from evidence "
            "of who changed it. Do not infer an actor from recency. If the required "
            "capability is missing or refused, explain the precise evidence gap; "
            "do not enumerate unrelated records or keep rediscovering the same tools. "
            "Use a corrected argument or a genuinely different authorized approach "
            "after failure. When results suffice, answer immediately. "
            "When several authorized reads are independent and their arguments "
            "are already known, request them together rather than serially. Do "
            "not batch a read that depends on another result or bypass discovery. "
            "For several known related Entry IDs, use the available batch label "
            "resolver when only their readable titles are needed; resolve an "
            "individual Entry when its full details are needed. "
            "For a count question, give the count and relevant scope, not a roster or unsolicited "
            "analysis. Do not infer causes or intent from numeric values and statuses "
            "alone, or contradict explicit coverage flags in the returned evidence."
        )
        if turn_progress and turn_progress.evidence_review_due:
            blocks.append(
                "Integral evidence checkpoint: review the evidence already gathered "
                "against the user's question. If it supports an answer, respond now "
                "with relevant sources and limitations. If essential evidence is "
                "missing, identify the specific source or fact needed; use a further "
                "authorized read only when it can reasonably supply that evidence. "
                "Otherwise explain what is known and what is missing. Do not treat "
                "sparse search results, inaccessible data, or an incomplete page as "
                "proof of absence. Continue required pagination, verification, and "
                "authorized actions when needed; this checkpoint is not a tool limit."
            )
        if final_response_reserved(ctx) or (
            turn_progress and turn_progress.should_finalize
        ):
            if turn_progress and turn_progress.reason:
                blocks.append("Integral observed progress: " + turn_progress.reason)
            blocks.append(
                "Integral turn budget: this is the final available response. "
                "Do not call tools or promise further work in this turn. Give a "
                "concise handoff grounded only in observed receipts: what was "
                "verified, what is pending approval, and what remains unresolved. "
                "A staged proposal is not an applied change. Do not claim success "
                "without readback. Invite the user to continue in this chat; "
                "never instruct them to restart or repeat already applied work."
            )
        available = sorted(getattr(ctx, "available_tool_names", ()))
        if available:
            blocks.append(
                "Callable tool names for this request: " + ", ".join(available) + "."
            )
        if active_ids:
            blocks.append(
                "Integral runtime state: these capabilities are already loaded and "
                f"their instructions are active: {', '.join(active_ids)}. Do not call "
                "load_capability for them again. Continue the current workflow using "
                "the loaded instructions and their tools."
            )
        outcomes = {}
        for message in getattr(ctx, "messages", ()):
            if not isinstance(message, ModelRequest):
                continue
            for part in message.parts:
                if not isinstance(part, ToolReturnPart) or not isinstance(
                    part.content, dict
                ):
                    continue
                content = part.content
                if content.get("state_source") == "current_core_staging":
                    state = content.get("state")
                    if state in {"consumed", "revoked", "expired"}:
                        outcomes[content["token"]] = state
        if outcomes:
            blocks.append(
                "Current Core approval outcomes (authoritative, superseding old "
                "proposal text and skill instructions to wait): "
                + "; ".join(f"{token}: {state}" for token, state in outcomes.items())
                + ". Consumed changes have already been applied: read back their "
                "saved records and report the result. Revoked changes were rejected: "
                "acknowledge that they were not applied. Expired changes cannot be "
                "applied. None of these changes is awaiting approval. Do not replay "
                "them or ask for approval again."
            )
        return "\n\n".join(blocks)

    return instructions


_HOST_TURN_METADATA_KEY = "integral_host_turn_v1"


def build_integral_host_turn(
    content: str, *, run_id: str, scheduled_execution: bool = False
) -> ModelRequest:
    """Mark a Core-generated event boundary without fabricating a user turn."""
    if not run_id or run_id != run_id.strip():
        raise ValueError("host turn requires a canonical Core run ID")
    parts: list[ModelRequestPart] = [SystemPromptPart(content=content)]
    if scheduled_execution:
        # Ollama returns done_reason=load for system-only requests, even when
        # their text asks for execution. Use the SDK's public input part while
        # retaining the trusted event instructions and typed host boundary.
        # The wire-level user role is not a new human message or permission.
        parts.append(
            UserPromptPart(
                content="Integral scheduled execution trigger (system-generated, "
                "not a new human request). Perform only the current scheduled "
                "event described in the system context, under its existing authority."
            )
        )
    return ModelRequest(
        parts=parts,
        metadata={_HOST_TURN_METADATA_KEY: run_id},
    )


def _active_turn_start(messages) -> int | None:
    """Find a human turn or a typed Core event; prompt prose is never a marker."""
    return active_turn_start(messages)


@dataclass
class IntegralToolResultCompaction(ClearToolResults):
    """Bound read-only payloads in the active turn and completed history.

    The current task and recent read receipts remain available. Older read-only
    results can be fetched again if needed, while non-read tools (including
    staging and writes) and their receipts remain untouched. This prevents a
    long multi-step turn from repeatedly resending every prior read to the
    heavy model. Completed turns retain the library's bounded recent window.
    """

    clearable_tools: frozenset[str] | None = None
    active_keep_pairs: int = 2
    active_fact_pairs: int = 32
    active_fact_bytes: int = 16_384
    active_schema_pairs: int = 8
    active_schema_bytes: int = 32_768

    _navigation_tools = frozenset({"integral_list_apps", "integral_list_tracks"})
    _identity_tools = frozenset({"integral_resolve_entry"})
    _batch_identity_tools = frozenset({"integral_resolve_entry_labels"})
    _catalogue_tools = frozenset({"integral_list_workspace_tools"})
    _resource_lookup_tools = frozenset({"integral_find_workspace_resources"})
    _track_schema_tools = frozenset({"integral_get_track_schema"})

    def _track_schema_preview(self, part):
        """Retain bounded substrate schema hints, explicitly marking omissions."""
        content = part.content
        if not isinstance(content, dict) or content.get("error"):
            return replace(part, content=self.placeholder)
        if content.get("schema_preview_incomplete") is True:
            if len(json.dumps(content, default=str).encode("utf-8")) <= 6144:
                return part
            return replace(part, content=self.placeholder)
        track = content.get("track")
        entry_types = content.get("entry_types")
        if not isinstance(track, dict) or not isinstance(entry_types, list):
            return replace(part, content=self.placeholder)
        preview = {
            "track": {key: track.get(key) for key in ("id", "title") if key in track},
            "entry_types": [],
            "schema_preview_incomplete": True,
            "instruction": (
                "This is an incomplete discovery preview, not current authority or "
                "a complete schema. Re-read the schema when omitted details or "
                "changes since this read matter."
            ),
        }
        for entry_type in entry_types:
            if not isinstance(entry_type, dict):
                continue
            row = {
                key: entry_type.get(key)
                for key in ("id", "key", "name")
                if key in entry_type
            }
            form = entry_type.get("form_schema")
            fields = form.get("fields") if isinstance(form, dict) else None
            if isinstance(fields, list):
                row["fields"] = [
                    {
                        key: field.get(key)
                        for key in ("key", "name", "type")
                        if key in field
                    }
                    for field in fields
                    if isinstance(field, dict)
                ]
            candidate = {**preview, "entry_types": [*preview["entry_types"], row]}
            if len(json.dumps(candidate, default=str).encode("utf-8")) > 6144:
                break
            preview["entry_types"].append(row)
        return replace(part, content=preview)

    def _resource_lookup_preview(self, part):
        """Keep whole resource descriptors within a bounded active-turn window."""
        if not isinstance(part.content, dict) or not isinstance(
            part.content.get("results"), list
        ):
            return replace(part, content=self.placeholder)
        rows = part.content["results"]
        selected, used = [], 0
        for row in rows:
            if not isinstance(row, dict):
                continue
            size = len(json.dumps(row, default=str).encode("utf-8")) + 2
            if used + size > 7680:
                break
            selected.append(row)
            used += size
        return replace(
            part,
            content={
                "results": selected,
                "mode": part.content.get("mode"),
                "degraded": bool(part.content.get("degraded")),
                "next_offset": (
                    part.content.get("next_offset")
                    if len(selected) == len(rows)
                    else None
                ),
                "preview_incomplete": len(selected) != len(rows)
                or bool(part.content.get("has_more")),
                "instruction": "These are resource suggestions, not record evidence. Search again if additional resources are needed.",
            },
        )

    def _catalogue_preview(self, part):
        """Retain whole tool schemas within a fixed active-turn budget."""
        if not isinstance(part.content, dict) or not isinstance(
            part.content.get("tools"), list
        ):
            return replace(part, content=self.placeholder)
        rows = part.content["tools"]
        selected, used = [], 0
        for row in rows:
            if not isinstance(row, dict):
                continue
            size = len(json.dumps(row, default=str).encode("utf-8")) + 2
            if used + size > 7680:
                break
            selected.append(row)
            used += size
        truncated = len(selected) != len(rows)
        content = {
            "tools": selected,
            "preview_incomplete": truncated or bool(part.content.get("has_more")),
            "instruction": "These are discovered tool schemas, not records. Re-read the catalogue when another schema or page is needed.",
        }
        if not truncated:
            for key in ("count", "returned_count", "has_more", "next_offset"):
                if key in part.content:
                    content[key] = part.content[key]
        return replace(part, content=content)

    def _identity_preview(self, part):
        """Keep only already-authorized identity and label evidence for synthesis."""
        if not isinstance(part.content, dict):
            return replace(part, content=self.placeholder)
        entry = part.content.get("entry")
        if not isinstance(entry, dict):
            return replace(part, content=self.placeholder)
        identity = {
            key: entry[key][:512]
            for key in ("id", "title", "track_id", "action_url", "url")
            if isinstance(entry.get(key), str)
        }
        if type(entry.get("record_revision")) is int:
            identity["record_revision"] = entry["record_revision"]
        return replace(
            part,
            content={
                "entry": identity,
                "identity_preview": True,
                "preview_truncated": any(
                    isinstance(entry.get(key), str) and len(entry[key]) > 512
                    for key in ("id", "title", "track_id", "action_url", "url")
                ),
                "instruction": "Only identity and label are retained; other fields require a fresh authorized read.",
            },
        )

    def _batch_identity_preview(self, part):
        """Retain bounded authorized labels without implying a complete batch."""
        if not isinstance(part.content, dict) or not isinstance(
            part.content.get("entries"), list
        ):
            return replace(part, content=self.placeholder)
        rows = part.content["entries"]
        selected, used = [], 0
        for row in rows:
            if not isinstance(row, dict):
                continue
            item = {
                key: row[key]
                for key in ("id", "title", "track_id", "url")
                if isinstance(row.get(key), str) and len(row[key]) <= 512
            }
            size = len(json.dumps(item).encode("utf-8")) + 2
            if used + size > 7680:
                break
            selected.append(item)
            used += size
        incomplete = len(selected) != len(rows) or any(
            any(
                isinstance(row.get(key), str) and len(row[key]) > 512
                for key in ("id", "title", "track_id", "url")
            )
            for row in rows
            if isinstance(row, dict)
        )
        content = {
            "entries": selected,
            "identity_preview": True,
            "preview_incomplete": incomplete,
            "instruction": "Only authorized labels are retained; request a fresh read for omitted labels or other fields.",
        }
        if isinstance(part.content.get("unresolved_count"), int):
            content["unresolved_count"] = part.content["unresolved_count"]
        return replace(part, content=content)

    def _navigation_preview(self, part):
        """Retain exact addresses, not record bodies, for active read planning."""
        if not isinstance(part.content, dict):
            return part
        collection = "apps" if part.tool_name == "integral_list_apps" else "tracks"
        rows = part.content.get(collection)
        if not isinstance(rows, list):
            return part
        projected, used = [], 0
        for row in rows:
            if not isinstance(row, dict):
                continue
            item = {
                key: row[key]
                for key in ("id", "title", "name", "url")
                if isinstance(row.get(key), str)
            }
            if isinstance(row.get("purpose"), str):
                item["purpose"] = row["purpose"][:200]
            size = len(json.dumps(item).encode("utf-8")) + 2
            if used + size > 7680:
                break
            projected.append(item)
            used += size
        return replace(
            part,
            content={
                collection: projected,
                "navigation_preview": True,
                "preview_incomplete": len(projected) != len(rows)
                or bool(part.content.get("preview_incomplete"))
                or bool(part.content.get("has_more")),
                "instruction": "These are discovered resource addresses, not record data. Repeat the scoped navigation read if more resources are needed.",
            },
        )

    def _compact_classified_reads(self, messages):
        """Bound mixed-wrapper reads using Core's per-call effect evidence.

        A wrapper can return reads and mutations in one turn. Never promote
        its whole name into the clearable set. Legacy metadata fails closed.
        """
        turn_start = _active_turn_start(messages)
        boundary = len(messages) if turn_start is None else turn_start
        classified = [
            (index, part_index)
            for index, message in enumerate(messages)
            if isinstance(message, ModelRequest)
            for part_index, part in enumerate(message.parts)
            if type(part) is ToolReturnPart
            and (
                part.tool_name in (self.clearable_tools or ())
                or (
                    isinstance(part.metadata, dict)
                    and part.metadata.get("integral_effect_v1") == "read"
                    and part.tool_name
                    in {"integral_call_workspace_tool", "integral_invoke_app_operation"}
                )
            )
        ]
        history_reads = [key for key in classified if key[0] < boundary]
        active_reads = [key for key in classified if key[0] >= boundary]
        recent = set(
            (history_reads[-self.keep_pairs :] if self.keep_pairs else [])
            + (
                active_reads[-self.active_keep_pairs :]
                if self.active_keep_pairs
                else []
            )
        )
        eligible = set(classified)
        navigation = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._navigation_tools
        }
        retained_navigation = set(sorted(navigation)[-2:])
        identities = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._identity_tools
        }
        retained_identities = set(sorted(identities)[-16:])
        batch_identities = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._batch_identity_tools
        }
        retained_batch_identities = set(sorted(batch_identities)[-4:])
        catalogues = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._catalogue_tools
        }
        retained_catalogues = set(sorted(catalogues)[-2:])
        lookups = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._resource_lookup_tools
        }
        retained_lookups = set(sorted(lookups)[-2:])
        track_schemas = {
            key
            for key in active_reads
            if messages[key[0]].parts[key[1]].tool_name in self._track_schema_tools
        }
        # A subsequent effect can change the schema or access. Treat every
        # unknown effect as a barrier; framework discovery has no such effect.
        discovery_tools = {
            "search_capabilities",
            "search_tools",
            "load_capability",
            "search_conversation_history",
        }
        effects = [
            (index, part_index)
            for index, message in enumerate(messages[boundary:], start=boundary)
            if isinstance(message, ModelRequest)
            for part_index, part in enumerate(message.parts)
            if isinstance(part, ToolReturnPart)
            and (index, part_index) not in eligible
            and part.tool_name not in discovery_tools
        ]
        last_effect = max(effects, default=(-1, -1))
        # ClearToolResults supports name exclusions, not a bounded per-resource
        # window. Keep the latest complete schema for each Track here, then
        # protect that projection through its public exclude_tools facility.
        # Two incomplete previews made a three-Track filing request continually
        # re-read required enums and relation constraints. These are current-turn
        # observations only; every later dispatch still performs live admission.
        retained_track_schemas = {}
        schema_tracks = set()
        schema_bytes = 0
        for key in sorted(track_schemas, reverse=True):
            if key <= last_effect:
                continue
            part = messages[key[0]].parts[key[1]]
            content = part.content
            track = content.get("track") if isinstance(content, dict) else None
            track_id = track.get("id") if isinstance(track, dict) else None
            if not isinstance(track_id, str) or track_id in schema_tracks:
                continue
            schema_tracks.add(track_id)
            size = len(json.dumps(content, default=str).encode("utf-8"))
            projected_schema = (
                part if size <= 16_384 else self._track_schema_preview(part)
            )
            size = len(
                json.dumps(projected_schema.content, default=str).encode("utf-8")
            )
            if schema_bytes + size > self.active_schema_bytes:
                continue
            if len(retained_track_schemas) >= self.active_schema_pairs:
                break
            retained_track_schemas[key] = projected_schema
            schema_bytes += size
        # Small current-task facts share one byte/count budget across all read
        # transports. Per-call classification still protects mixed effects.
        from app.services.retrieval.history import RETRIEVAL_EVIDENCE

        retained_facts: set[tuple[int, int]] = set()
        seen_entries: set[str] = set()
        fact_bytes = 0
        for key in reversed(active_reads):
            part = messages[key[0]].parts[key[1]]
            if key in identities:
                # Full detail is useful only within the current task and with
                # a live-checkable receipt. Do not spend the fact budget on
                # repeated reads or evidence preceding a possible write.
                proof = (
                    part.metadata.get(RETRIEVAL_EVIDENCE)
                    if isinstance(part.metadata, dict)
                    else None
                )
                entry = (
                    part.content.get("entry")
                    if isinstance(part.content, dict)
                    else None
                )
                entry_id = entry.get("id") if isinstance(entry, dict) else None
                if (
                    key <= last_effect
                    or not proof
                    or not isinstance(entry_id, str)
                    or entry_id in seen_entries
                ):
                    continue
                seen_entries.add(entry_id)
            size = len(json.dumps(part.content, default=str).encode("utf-8"))
            if size > 4096 or fact_bytes + size > self.active_fact_bytes:
                continue
            if len(retained_facts) >= self.active_fact_pairs:
                break
            retained_facts.add(key)
            fact_bytes += size
        projected = []
        for index, message in enumerate(messages):
            if not isinstance(message, ModelRequest):
                projected.append(message)
                continue
            parts = []
            for part_index, part in enumerate(message.parts):
                key = (index, part_index)
                if key in eligible:
                    text = str(part.content)
                    if part.tool_name in self._track_schema_tools and index < boundary:
                        part = replace(part, content=self.placeholder)
                    elif key in retained_navigation:
                        part = self._navigation_preview(part)
                    elif key in retained_catalogues:
                        part = self._catalogue_preview(part)
                    elif key in catalogues:
                        part = replace(part, content=self.placeholder)
                    elif key in retained_lookups:
                        part = self._resource_lookup_preview(part)
                    elif key in lookups:
                        part = replace(part, content=self.placeholder)
                    elif key in retained_track_schemas:
                        part = retained_track_schemas[key]
                    elif key in track_schemas:
                        part = replace(part, content=self.placeholder)
                    elif key in retained_batch_identities:
                        part = self._batch_identity_preview(part)
                    elif key in batch_identities:
                        part = replace(part, content=self.placeholder)
                    elif key in retained_facts and key in identities:
                        pass
                    elif key in retained_identities and key not in recent:
                        part = self._identity_preview(part)
                    elif key in retained_facts:
                        pass
                    elif (
                        (key in identities and key not in retained_identities)
                        or key in navigation
                        or key not in recent
                    ):
                        part = replace(part, content=self.placeholder)
                    elif len(text) > 16_384:
                        part = replace(
                            part,
                            content=text[:16_384]
                            + "\n[Read preview truncated; request a narrower read for omitted values. This is not the complete result.]",
                        )
                parts.append(part)
            projected.append(replace(message, parts=parts))
        return projected

    async def before_model_request(self, ctx, request_context):
        # Request-only projection must also become the checkpoint working
        # history. Otherwise later runs resurrect the completed-turn payloads.
        before = list(request_context.messages)
        request_context.messages = self._compact_classified_reads(before)
        processed = await super().before_model_request(ctx, request_context)
        # The pinned upstream estimator includes instructions and schemas.
        # Also bound reads deterministically so even a misleading usage anchor
        # cannot conceal accumulation during a long active task.
        if self.clearable_tools:
            processed.messages = await self._compact_active_turn(
                list(processed.messages), ctx
            )
        if processed.messages != before:
            ctx.messages[:] = processed.messages
        return processed

    async def _compact_active_turn(self, messages, ctx):
        turn_start = _active_turn_start(messages)
        if turn_start is None:
            return messages
        active_turn = messages[turn_start:]
        if not self.clearable_tools:
            return messages

        # Fail closed for tools without an explicit read-only classification.
        # Generated skill tools, capability discovery, staging, and writes are
        # therefore protected by default; the caller supplies only Core tools
        # classified as reads in the authoritative tool catalogue.
        protected_tools = {
            part.tool_name
            for message in active_turn
            if isinstance(message, ModelResponse)
            for part in message.parts
            if isinstance(part, ToolCallPart)
            and part.tool_name not in self.clearable_tools
        }
        # The shared projection already bounds navigation to two small maps.
        # Clearing those a second time makes a discovered Track disappear while
        # the model is still preparing its read, causing guesses and retries.
        protected_tools |= self._navigation_tools
        # Identity previews were bounded above; keep their evidence together
        # through the subsequent upstream compaction pass.
        protected_tools |= self._identity_tools
        protected_tools |= self._batch_identity_tools
        protected_tools |= self._catalogue_tools
        protected_tools |= self._resource_lookup_tools
        protected_tools |= self._track_schema_tools
        # Native keep_pairs counts every pair, including protected receipts
        # and already-cleared reads. Keep the span containing Core's bounded
        # current facts; otherwise interleaved large reads evict smaller facts.
        returns = [
            part
            for message in active_turn
            if isinstance(message, ModelRequest)
            for part in message.parts
            if isinstance(part, ToolReturnPart)
        ]
        oldest_fact = next(
            (
                index
                for index, part in enumerate(returns)
                if part.tool_name in self.clearable_tools
                and part.content != self.placeholder
            ),
            len(returns),
        )
        active_compaction = ClearToolResults(
            max_tokens=8_192,
            keep_pairs=max(self.active_fact_pairs, len(returns) - oldest_fact),
            exclude_tools=self.exclude_tools | frozenset(protected_tools),
            # Retain read arguments so the model can repeat a query whose
            # earlier receipt was compacted.
            clear_tool_inputs=False,
            min_clear_tokens=256,
            placeholder=self.placeholder,
            tokenizer=self.tokenizer,
        )
        compacted = await active_compaction.compact(active_turn, ctx)
        # Even the recent read results need a size ceiling. Retain a
        # clearly marked preview, never imply that a truncated collection is
        # complete. Mutation/capability returns and accepted user input are exact.
        compacted = [
            (
                replace(
                    message,
                    parts=[
                        (
                            replace(
                                part,
                                content=(
                                    str(part.content)[:16_384]
                                    + "\n[Read preview truncated; request a narrower read for omitted values. This is not the complete result.]"
                                ),
                            )
                            if type(part) is ToolReturnPart
                            and part.tool_name in self.clearable_tools
                            and len(str(part.content)) > 16_384
                            else part
                        )
                        for part in message.parts
                    ],
                )
                if isinstance(message, ModelRequest)
                else message
            )
            for message in compacted
        ]
        return [*messages[:turn_start], *compacted]

    async def compact(self, messages, ctx):
        messages = self._compact_classified_reads(messages)
        if self.clearable_tools is not None:
            protected = {
                part.tool_name
                for message in messages
                for part in message.parts
                if isinstance(part, ToolCallPart)
                and part.tool_name not in self.clearable_tools
            }
            # Explicit read-only classification applies to completed history
            # too. Unknown tools and mutation receipts are never cheap-cleared.
            compactor = replace(
                self,
                exclude_tools=self.exclude_tools | protected | self._navigation_tools,
            )
        else:
            compactor = self
        turn_start = _active_turn_start(messages)
        if turn_start is None:
            return await ClearToolResults.compact(compactor, messages, ctx)
        history = await ClearToolResults.compact(compactor, messages[:turn_start], ctx)
        active_turn = await self._compact_active_turn(messages[turn_start:], ctx)
        return [*history, *active_turn]


def build_integral_context_compaction(
    *, clearable_tools: frozenset[str] = frozenset()
) -> ClearToolResults:
    """Bound old reads while preserving active task and effect receipts."""
    return IntegralToolResultCompaction(
        max_tokens=8_192,
        keep_pairs=5,
        exclude_tools=frozenset({"load_capability"}),
        clear_tool_inputs=True,
        clearable_tools=clearable_tools,
    )


@dataclass
class IntegralHistorySummary(SummarizingCompaction):
    """Keep typed disclosure evidence when the library summarizes prose.

    Capability activation is derived from completed typed load pairs, not from
    a summary saying a skill was loaded. Preserve one pair per current skill
    and a bounded tool-availability delta using public message types. The
    library still owns summarization, pairing, execution and checkpointing;
    current registration and the broker remain the authorization boundary.
    """

    retrieval_scope: HarnessExecutionScope | None = None
    max_history_bytes: int = 96_000
    _compacted_history_digest: str | None = None

    async def before_model_request(self, ctx, request_context):
        # Pydantic AI 2.54 treats replacement request history as request-only.
        # Persist through the documented RunContext.messages seam
        # so StepPersistence and later turns receive the same working history.
        before = list(request_context.messages)
        turn_start = _active_turn_start(before)
        history = before[:turn_start] if turn_start is not None else []
        history_bytes = ModelMessagesTypeAdapter.dump_json(history)
        digest = hashlib.sha256(history_bytes).hexdigest()
        # Only completed-turn history is eligible for summarization. A large
        # active build must not repeatedly summarize the same older history,
        # spend the closing-response allowance, or duplicate its receipts.
        if final_response_reserved(ctx) or digest == self._compacted_history_digest:
            return request_context
        if len(history_bytes) > self.max_history_bytes:
            request_context.messages = await self.compact(before, ctx)
            processed = request_context
        else:
            processed = await super().before_model_request(ctx, request_context)
        if processed.messages != before:
            ctx.messages[:] = processed.messages
        processed_start = _active_turn_start(processed.messages)
        retained_history = (
            processed.messages[:processed_start] if processed_start is not None else []
        )
        if processed.messages != before:
            self._compacted_history_digest = hashlib.sha256(
                ModelMessagesTypeAdapter.dump_json(retained_history)
            ).hexdigest()
        return processed

    async def compact(self, messages, ctx):
        # Keep the active user request and its tool sequence exact. Summarizing
        # it mid-batch can erase a queued effect receipt and provoke restaging.
        # ClearToolResults still bounds older payloads; the library usage limits
        # bound a long active turn. Summarization owns completed-turn history.
        turn_start = protected_work_start(messages)
        history, active_turn = messages[:turn_start], messages[turn_start:]
        history_digest = hashlib.sha256(
            ModelMessagesTypeAdapter.dump_json(history)
        ).hexdigest()
        # TieredCompaction invokes compact() directly, bypassing this class's
        # before_model_request hook. A large protected current task therefore
        # used to buy another summary of unchanged older prose on every step.
        if history_digest == self._compacted_history_digest:
            return messages
        if (
            len(history) <= self.keep_messages
            and len(ModelMessagesTypeAdapter.dump_json(history))
            <= self.max_history_bytes
        ):
            return messages
        from app.services.retrieval.history import (
            RETRIEVAL_EVIDENCE,
            retained_retrieval_evidence,
        )

        retrieval_evidence = retained_retrieval_evidence(history)
        # A summary request must not resend large completed-turn tool payloads.
        # Durable scoped checkpoints keep the full evidence searchable.
        history = await ClearToolResults(
            max_tokens=1,
            keep_pairs=0,
            exclude_tools=frozenset(
                part.tool_name
                for message in history
                for part in message.parts
                if isinstance(part, ToolCallPart)
                and (
                    part.tool_name == "load_capability"
                    or (
                        getattr(
                            getattr(ctx, "tools", {}).get(part.tool_name),
                            "metadata",
                            None,
                        )
                        or {}
                    ).get("integral_op_class")
                    != "read"
                )
            ),
            clear_tool_inputs=True,
        ).compact(history, ctx)
        # Native 0.59 keeps an indivisible recent message even when it exceeds
        # its retained-token floor. This history contains completed work only:
        # summarize an oversized message rather than retaining it beside its
        # summary. Current work and pending effects were separated above.
        summarizer = (
            replace(
                self,
                keep_tokens=None,
                keep_messages=0,
                keep_user_messages=False,
                preserve_first_user_message=True,
            )
            if any(
                len(ModelMessagesTypeAdapter.dump_json([message]))
                > self.max_history_bytes
                for message in history
            )
            else (
                replace(self, keep_tokens=None)
                if self.max_messages is not None and len(messages) > self.max_messages
                else self
            )
        )
        if self.retrieval_scope is not None:
            from app.services.retrieval.history import (
                assert_bound_model_retrieval_current,
                bind_model_request_retrieval,
            )

            with bind_model_request_retrieval(self.retrieval_scope, history):
                await assert_bound_model_retrieval_current(self.retrieval_scope)
                compacted = await SummarizingCompaction.compact(
                    summarizer, history, ctx
                )
        else:
            compacted = await SummarizingCompaction.compact(summarizer, history, ctx)
        # Native message-count cutoffs can retain a retry after summarizing its
        # original call. Remove only that settled historical validation pair's
        # orphan feedback; never synthesize a result or alter an open effect.
        settled_retries = {
            part.tool_call_id
            for message in history
            for part in message.parts
            if isinstance(part, RetryPromptPart) and part.tool_name is not None
        }
        retained_calls = {
            part.tool_call_id
            for message in compacted
            for part in message.parts
            if isinstance(part, ToolCallPart)
        }
        orphan_retries = settled_retries - retained_calls
        if orphan_retries:
            normalized = []
            for message in compacted:
                parts = [
                    part
                    for part in message.parts
                    if not (
                        isinstance(part, RetryPromptPart)
                        and part.tool_call_id in orphan_retries
                    )
                ]
                if parts or not message.parts:
                    normalized.append(replace(message, parts=parts))
            compacted = normalized
        if compacted == history:
            self._compacted_history_digest = history_digest
            return [*history, *active_turn]
        calls = {}
        pairs = {}
        names = set()
        for message in post_compaction_window(messages):
            for part in message.parts:
                if isinstance(part, LoadCapabilityCallPart):
                    calls[part.tool_call_id] = part
                elif isinstance(part, LoadCapabilityReturnPart):
                    call = calls.get(part.tool_call_id)
                    if call and call.capability_id in ctx.active_capability_ids:
                        pairs[call.capability_id] = (call, part)
                elif isinstance(part, ToolAvailabilityDeltaPart):
                    names.update(name for name in part.tools_added if name in ctx.tools)
        retained = {
            part.tool_call_id
            for message in [*compacted, *active_turn]
            for part in message.parts
            if isinstance(part, LoadCapabilityReturnPart)
        }
        evidence = []
        for call, result in pairs.values():
            if result.tool_call_id not in retained:
                evidence.extend(
                    [ModelResponse(parts=[call]), ModelRequest(parts=[result])]
                )
        if names:
            evidence.append(
                ModelRequest(
                    parts=[ToolAvailabilityDeltaPart(tools_added=sorted(names))]
                )
            )
        # A summary is a leading system request; attach state after it and
        # before the retained current task. No execution is replayed.
        summary = compacted[0]
        if retrieval_evidence is None or retrieval_evidence:
            summary = replace(
                summary,
                metadata={
                    **(summary.metadata or {}),
                    RETRIEVAL_EVIDENCE: (
                        [row.model_dump(mode="json") for row in retrieval_evidence]
                        if retrieval_evidence is not None
                        else None
                    ),
                },
            )
        retained_history = [summary, *evidence, *compacted[1:]]
        self._compacted_history_digest = hashlib.sha256(
            ModelMessagesTypeAdapter.dump_json(retained_history)
        ).hexdigest()
        return [*retained_history, *active_turn]


def build_integral_history_compaction(
    *, retrieval_scope: HarnessExecutionScope | None = None
) -> IntegralHistorySummary:
    """Summarize old prose after the separate cheap result-clearing pass.

    The populated browser chat retained 112k conversation characters after
    clearing. Provider usage anchors and heuristic reclaim can understate the
    remaining context when reasoning was not sent back to the provider. A
    library message-count trigger supplies an independent bound, alongside
    the token trigger. Preserve recent user constraints and task data; scoped
    checkpoints remain searchable. Summary requests share model accounting.
    """
    return IntegralHistorySummary(
        retrieval_scope=retrieval_scope,
        max_messages=40,
        max_tokens=24_576,
        # Only completed turns reach this strategy. Keeping 20 messages plus
        # an 8K-token floor retained most of a prior workflow on a 32K model.
        # Current work and unresolved effects are protected separately; older
        # detail remains in the scoped archive behind the summary receipt.
        keep_messages=4,
        keep_tokens=2_048,
        keep_user_messages=True,
        receipts=True,
        model_settings={"max_tokens": 2048},
        # Summaries run in a separate native Agent; outer request hooks do not
        # apply there. Use the public composition hook to bound that input too.
        summarization_capabilities=[IntegralContextAdmission()],
    )


@dataclass
class IntegralWorkingContext(TieredCompaction):
    """One budget pipeline with a cheap per-step read pass and native escalation."""

    policy: IntegralContextPolicy = IntegralContextPolicy()

    retrieval_scope: HarnessExecutionScope | None = None

    async def _assert_live_retrieval(self, messages):
        if self.retrieval_scope is None:
            return
        from app.services.retrieval.history import assert_retrieval_history_current

        await assert_retrieval_history_current(
            messages,
            principal_id=self.retrieval_scope.principal_id,
            workspace_id=self.retrieval_scope.workspace_id,
            allow_unproven_tool_results=True,
        )

    async def before_model_request(self, ctx, request_context):
        before = list(request_context.messages)
        await self._assert_live_retrieval(before)
        # Small read clearings happen without inference even below the history
        # trigger. Typed activation was already normalized before node prepare.
        request_context.messages = account_context_reclaim(
            before, await self.tiers[0].compact(before, ctx)
        )
        limit = self.policy.input_limit(
            request_context.model, request_context.model_settings
        )
        trigger = min(self.policy.trigger_tokens, limit)
        estimate = request_estimate(request_context)
        # Native 0.59 compaction reads the public working history. Make the
        # cheap projection authoritative before invoking its tier scheduler.
        ctx.messages[:] = request_context.messages
        if (
            estimate > trigger or len(request_context.messages) > 40
        ) and not final_response_reserved(ctx):
            # Message count is an independent trigger when provider usage is
            # absent or a reused anchor is optimistic. Force the native tier
            # chain to consider summarization even below the token target.
            target = (
                1
                if len(request_context.messages) > 40
                else min(self.policy.target_tokens, limit, max(1, estimate - 1))
            )
            pipeline = replace(self, target_tokens=target)
            tier_input = list(request_context.messages)
            request_context = await TieredCompaction.before_model_request(
                pipeline, ctx, request_context
            )
            request_context.messages = account_context_reclaim(
                tier_input, request_context.messages
            )
        if request_estimate(request_context) > limit:
            # Native estimates can stop tier escalation before Core's more
            # conservative wire/usage admission estimate is satisfied. Reclaim
            # older disposable reads once more, retaining the newest result.
            # This never touches unknown tools, effects, approvals or user input.
            tier = self.tiers[0]
            if isinstance(tier, IntegralToolResultCompaction):
                prior = list(request_context.messages)
                request_context.messages = account_context_reclaim(
                    prior,
                    await replace(
                        tier,
                        keep_pairs=0,
                        active_keep_pairs=1,
                        active_fact_pairs=1,
                        active_fact_bytes=4096,
                    ).compact(prior, ctx),
                )
        if request_context.messages != before:
            await self._assert_live_retrieval(request_context.messages)
            ctx.messages[:] = request_context.messages
        return request_context


def build_integral_working_context(
    *,
    clearable_tools: frozenset[str],
    retrieval_scope: HarnessExecutionScope | None = None,
):
    """Use native tier orchestration; Core supplies protection and lifecycle rules."""
    return IntegralWorkingContext(
        retrieval_scope=retrieval_scope,
        tiers=[
            build_integral_context_compaction(clearable_tools=clearable_tools),
            build_integral_history_compaction(retrieval_scope=retrieval_scope),
        ],
        target_tokens=16_384,
    )


def classify_integral_harness_exception(exc: BaseException) -> str | None:
    """Translate Pydantic AI failures to Integral's stable error categories."""
    from app.agentive.harness.model_errors import classified_model_error
    from app.services.retrieval.history import RetrievalEvidenceStale

    current: BaseException | None = exc
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, RetrievalEvidenceStale):
            return "harness_retrieval_history_stale"
        if isinstance(current, IntegralContextOverflow):
            return "harness_context_limit"
        if isinstance(current, UsageLimitExceeded):
            return "harness_usage_limit"
        current = current.__cause__ or current.__context__
    model_code = classified_model_error(exc)
    if model_code:
        return model_code
    from pydantic_ai.exceptions import UnexpectedModelBehavior

    # Provider classification is content-free; raw model/guard text stays private.
    current = exc
    seen.clear()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, UnexpectedModelBehavior):
            if str(current).startswith(
                "Model token limit ("
            ) and " exceeded before any response was generated." in str(current):
                return "model_output_limit"
            return "model_response_invalid"
        current = current.__cause__ or current.__context__
    if isinstance(exc, UsageLimitExceeded):
        return "harness_usage_limit"
    exception_text = str(getattr(exc, "message", exc)).lower()
    if "token limit" in exception_text or "context length" in exception_text:
        return "model_context_limit"
    return None


__all__ = [
    "AbstractCapability",
    "End",
    "EnqueuedMessagesEvent",
    "IntegralContextAdmission",
    "IntegralContextLifecycle",
    "IntegralContextOverflow",
    "IntegralContextPolicy",
    "build_integral_host_turn",
    "Agent",
    "AgentRunResultEvent",
    "BinaryContent",
    "Capability",
    "CancellationToken",
    "CallDeferred",
    "ClearToolResults",
    "build_integral_history_compaction",
    "ContinuableSnapshot",
    "ConversationSearch",
    "DeferredToolRequests",
    "DeferredToolResults",
    "FunctionToolCallEvent",
    "FunctionToolResultEvent",
    "Instrumentation",
    "LiteLLMProvider",
    "ModelMessagesTypeAdapter",
    "ModelRequest",
    "ModelResponse",
    "ModelRetry",
    "OpenAIChatModel",
    "PartDeltaEvent",
    "PartEndEvent",
    "PartStartEvent",
    "PlanItem",
    "PlanStore",
    "Planning",
    "IntegralToolDisclosure",
    "RetryPromptPart",
    "RunContext",
    "RunRecord",
    "SchemaValidator",
    "Skills",
    "LocalWorkspaceBackend",
    "SnapshotHistorySource",
    "StepEvent",
    "StepPersistence",
    "StepStore",
    "SystemPromptPart",
    "TaskStatus",
    "TextPart",
    "TextPartDelta",
    "ThinkingPart",
    "Tool",
    "ToolEffectRecord",
    "ToolReturn",
    "ToolCallPart",
    "ToolReturnPart",
    "ToolSearch",
    "TextOutput",
    "ToolOutput",
    "UsageLimitExceeded",
    "UsageLimits",
    "InstructionPart",
    "UserPromptPart",
    "build_integral_json_schema_tool",
    "build_integral_context_compaction",
    "build_integral_run_instructions",
    "classify_integral_harness_exception",
    "continue_run",
    "core_schema",
    "to_jsonable_python",
]


@dataclass
class InstructionDisclosureGuard(AbstractCapability[Any]):
    """Remove literal instruction copies before processing or checkpointing.

    Append last: the pinned framework runs after-model hooks in reverse order.
    Stream deltas remain private until the provider's settled-output buffer
    publishes the modified result. This does not detect semantic paraphrases.
    """

    protected_instructions: str

    async def after_model_request(self, ctx, *, request_context, response):
        """Replace unsafe text or tool arguments before any tool dispatch."""
        from app.agentive.harness.disclosure import instruction_output_validator

        inspect_output = instruction_output_validator(self.protected_instructions)
        text = "".join(
            part.content for part in response.parts if isinstance(part, TextPart)
        )
        candidates = [
            text,
            *(
                str(getattr(part, "args", ""))
                for part in response.parts
                if part.part_kind == "tool-call"
            ),
        ]
        for candidate in candidates:
            safe = inspect_output(candidate)
            if safe != candidate:
                return replace(response, parts=[TextPart(safe)])
        return response


class PublicConversationHistorySource:
    """Project scoped checkpoints to conversation search without host context.

    Private instructions/reasoning remain in the encrypted restore store; the
    searchable tool corpus contains human turns, safe answers and tool results.
    """

    def __init__(self, source: Any, *, protected_instructions: str):
        self._source = source
        self._protected = protected_instructions

    async def list_runs(self):
        """Retain the underlying scoped run inventory."""
        return await self._source.list_runs()

    async def run_history(self, *, run_id: str):
        """Remove host-only parts before the search tool can render them."""
        guard = InstructionDisclosureGuard(protected_instructions=self._protected)
        public = []
        for message in await self._source.run_history(run_id=run_id):
            if isinstance(message, ModelRequest):
                parts = [
                    part
                    for part in message.parts
                    if isinstance(part, (UserPromptPart, ToolReturnPart))
                ]
                if parts:
                    public.append(replace(message, parts=parts, instructions=None))
            elif isinstance(message, ModelResponse):
                response = await guard.after_model_request(
                    None, request_context=None, response=message
                )
                parts = [
                    part
                    for part in response.parts
                    if isinstance(part, TextPart) or part.part_kind == "tool-call"
                ]
                if parts:
                    public.append(replace(response, parts=parts))
        return public
