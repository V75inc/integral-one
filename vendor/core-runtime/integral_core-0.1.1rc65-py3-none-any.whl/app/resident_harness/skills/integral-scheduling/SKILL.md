---
name: integral-scheduling
description: Schedule automatic updates and reports in this chat every minute, hour, day or week, including workspace entry counts and checks for the next few minutes. Creates, lists, pauses, resumes, edits and cancels recurring or one-shot routines. Use for periodic monitoring, scheduled or deferred agent work and fixed personal reminders. Live reports execute tools each run; saved reminders deliver literal text.
allowed-tools: integral_list_resident_opportunities integral_schedule_task integral_list_routines integral_update_routine integral_cancel_routine integral_delete_routine integral_resolve_entry integral_query_entries integral_count_entries integral_count_workspace_entries integral_aggregate integral_get_digest integral_activity_digest
---

# Integral scheduling — SOP

A **routine** is an instruction that fires later (or on a cadence) and
replays as a normal agent turn, posting its reply into the SAME chat thread
it was created from. There is no separate "scheduled task" surface — a
routine is just this conversation, run again automatically.

**Never use `queue_task`.** It is disabled in this harness. Reminders and
schedules go through `integral_schedule_task` only — that is what shows in
Inbox / Background Tasks and what the scheduler actually runs.

## When to use this

- "Every day at 9am, prepare a morning briefing and leave it in chat."
- "Every morning around 6am, check the latest AI news and update the Latest
  in AI wiki."
- "Remind me every Monday what's overdue."
- "Remind me in two minutes to join my standup." / "Nudge me at 3pm."
- "Show my routines" / "what's scheduled" / "pause the morning briefing."

## When NOT to use this

- A one-off ask the user wants **answered now** ("summarize today's
  activity") → just answer it now; do not schedule.
- The instruction itself (digests, entry lookups, updates) → the existing
  tools for that job (`integral_activity_digest`, `integral_get_digest`,
  `integral_query_entries`, skill `integral-entries`, skill `integral-filing`, ...). This
  skill only owns the CADENCE / fire-time wrapper around whatever instruction the user
  gives you — it does not replace those tools.

## Grounding (read before write)

Before creating or updating a routine:

1. `integral_list_routines` — list existing routines so you do not duplicate
   cadence or guess `routine_id`.
2. When the instruction implies writes, `integral_resolve_entry` /
   `integral_query_entries` to obtain real `write_scope` resource ids.

## Find assigned work that needs attention

When asked what Integral should pick up next, use
`integral_list_resident_opportunities` in the active workspace. It returns
current sponsored assignments eligible for a first preparation review.
Link to the Entry and explain that the user can request preparation there.
Use its `next_cursor` to continue a bounded search when more work is needed.
An empty page with a cursor is not the end of the search.
This read does not grant authority to prepare or execute.
If the user asks for recurring suggestions, propose `delivery_mode="assignment_digest"`
with their cadence, no Entry target, and no write scope. It resumes the workspace
scan at the next scheduled check and posts only new eligible suggestions to this chat.

## Watch a typed goal for changes

For a published goal, use the same read-only `task_watch` delivery mode
with `watch_goal` set to true and the exact goal Entry in `watch_entry_id`.
The alert links to the goal when its outcome, status, published criteria,
or linked criterion values change. The alert does not state which value
changed. Tell the user what the watch can report and leave its write scope
empty. Keep the goal separate from the recurring check.

If the user explicitly asks the routine to prepare a closure review when a
changed goal becomes ready, also set `watch_prepare_closure` to true. The
schedule approval must disclose that opt-in. Keep the write scope empty.
The routine may prepare a pending review in Approvals with the exact current
evidence revisions. The user still needs to approve that review before the
goal closes. Leave this opt-in off for notification-only requests.

## Watch a task for changes

When the user asks to be told only when a particular task changes, resolve the
exact Entry and propose `delivery_mode="task_watch"` with its `watch_entry_id`,
the requested cadence, and no `write_scope`. This requires published task
semantics and current read access. Approval records the current task state.
Later checks stay quiet until the declared outcome, acceptance criteria, due
date, dependencies, or assignment revision changes. Avoid promising alerts
for body edits, arbitrary status fields, or other unmapped properties. The alert links to the Entry and runs without a model or Entry writes.
If the target is ambiguous, ask which task before proposing the watch.
The alert destination is the conversation that created the watch. An edit
cannot move it. If the user asks for alerts in this chat and a watch already
exists in another chat, leave it alone and propose a new watch in this chat.
For a request about this chat, only a routine with
`in_current_conversation=true` from `integral_list_routines` counts as an
existing watch here. A matching name, Entry, or cadence is insufficient.

## Live reports versus saved reminder text

A request to report changing facts is **agent work**, even if it sounds like a
reminder. Use `delivery_mode="agent"` for counts, searches, summaries and checks.
Each run must use scoped tools and return the result, not repeat the instruction.
Use `delivery_mode="reminder"` only for a fixed message delivered unchanged, such
as "Drink water"; that mode executes no tools and cannot calculate an answer.

For a short monitoring request, read and report the current value now, then stage
its recurring follow-ups. An exact workspace entry total uses
`integral_count_workspace_entries()` and its `total_entries`. This content-free
inventory includes installed Apps while enforcing the caller's current Entry
read audience. It returns no domain fields. Do not use the generic grouped-count
query for a workspace inventory: that query intentionally excludes installed-App
domain records. Domain breakdowns still require the owning App's declared query. Use
`integral_aggregate(op="count")` only when the requested aggregation requires it;
do not count a search page or use semantic retrieval as a total. Counts cover only entries the
caller can read in the active workspace; say so. Do not narrow to the currently
open App when the user asks about the whole workspace.

For "for the next five minutes, every minute tell me how many entries are in this
workspace", report the live count, then stage **one** agent routine with
`cron="* * * * *"`, `max_runs=5`, and an instruction to read the current accessible
entry total with integral_count_workspace_entries and report it in this chat. The immediate answer does not consume a
scheduled run. A cron minute range such as `1-5 * * * *` fires only at those
minutes of each hour and does not mean "the next five minutes". Use the account
timezone unless the user specifies another. Explain that approval starts the
five follow-ups, they stop after five successful runs, and timing is best effort.
If scheduling or the live read fails, state what failed; do not substitute a
saved task description or promise that recurring updates are running.

## Creating a routine

1. **Pick recurring vs one-shot.**
   - **Recurring** ("every day at 9am", "every Monday") → compute a 5-field
     `cron` + IANA `timezone`. The tool does **not** parse natural language.
     Omit `timezone` to use the verified account timezone; ask only if the user
     requests a different timezone that is not clear.
   - **Deferred one-shot** ("in two minutes", "at 3pm today") → compute an
     absolute ISO-8601 `run_at` and **omit `cron`**. Defaults `max_runs=1`.
     Do not invent a cron that fires once.
2. **Run-count is a real dimension — use `max_runs`, never instruction text.**
   If the user asks for a fixed number of recurring occurrences ("every minute for 5
   iterations", "post this 10 times then stop"), extract that count and pass
   it as `max_runs` — the routine auto-transitions to `status: "completed"`
   after that many SUCCESSFUL runs (failed attempts don't count). If they
   don't mention a count on a recurring routine, omit `max_runs` entirely
   (open-ended). For a tiny burst that doesn't need to persist at all
   (e.g. "post 3 messages right now"), just do it directly.
3. **Write a self-contained `instruction` — and make it inert.** It is
   replayed on every run as a new scheduled event, with an explicit host marker.
   Do not rely on historical results or the original setup conversation.
   Write it as a complete standalone
   *task description*, not phrasing that could itself read as a request to
   configure something ("Remind the user it's time to join their standup" —
   good; "Remind me in two minutes to join my standup" — bad, still sounds
   like a scheduling ask on replay). Strip ALL cadence/meta language
   (frequency, "in N minutes", "then stop", "set up a routine for...") out of
   the stored `instruction` — cadence lives in `cron`/`timezone` or `run_at`,
   the stop condition lives in `max_runs`.
4. **If the instruction implies a WRITE** (e.g. "update the wiki", "add a
   row every day"), resolve the exact target first —
   `integral_resolve_entry` / `integral_query_entries` — and pass it as
   `write_scope: [{resource_type: "entry"|"track", resource_id}]`. This is
   the ONLY set of resources the routine may auto-apply writes to unattended
   on future runs; everything else it ever attempts always lands as a
   normal staged card for manual review, every run, forever. Never invent a
   `write_scope` id — only ids a tool actually returned this turn.
5. **Read-only routines** (briefings, digests, reminders) omit
   `write_scope` entirely — there is nothing to pre-approve.
6. Calling `integral_schedule_task` stages a card. Nothing runs until the user
   blesses it — say so plainly ("I'll set this up once you approve — it'll
   nudge you at 9:01 AM in this chat"). For short `run_at` windows, stress
   that they need to approve before the fire time.

## Executing a scheduled replay — do the work, don't reconfigure yourself

When a message you receive is a routine's replayed `instruction` (a standing
task description with no live back-and-forth, arriving on its own — not a
fresh question a human just typed), **just do the work it describes and
reply with the result.** Never call `integral_schedule_task` /
`integral_update_routine` / `integral_cancel_routine` in response to a
replayed instruction, even if its wording sounds like a scheduling request
("every day at...", "for N iterations", "then stop") — that phrasing is
DESCRIBING what the already-existing routine does, not asking you to
(re)configure it. Re-invoking this skill on your own replay is how a routine
silently stops posting real check-ins and starts spawning duplicate
`AWAITING APPROVAL` cards instead. Only call these tools when a live user,
in this turn, is directly asking you to create/update/cancel a routine.

## Listing / managing

- `integral_list_routines` — the user's own routines with `next_run_at` /
  `last_run_status` / `write_scope`. Call this FIRST before any
  update/cancel — you need the real `routine_id`, never guess one.
- `integral_update_routine` — pause, resume, or edit cadence/instruction/
  write_scope/max_runs. **Widening `write_scope`** (adding a new auto-apply
  target) re-stages for a fresh bless — the user must explicitly re-approve;
  never claim an expanded grant took effect before they do. Resuming a
  `status: "completed"` routine (`status: "active"`) restarts its run count
  from 0 — say so, don't imply it picks up where it left off. Pass
  `clear_max_runs: true` to turn a capped routine open-ended again.
- `integral_cancel_routine` — stops it permanently. Confirm before calling
  if the user's intent was ambiguous ("pause" vs "cancel" are different —
  pausing is resumable, cancelling is not).

## Honesty rules

- Never claim a routine is active, will fire, or "already posted" until the
  staged card is blessed (`[SYSTEM:STAGING-RESOLVED]`) and/or
  `integral_list_routines` shows it. Staging alone is not enough.
- Never claim a routine "ran" or "already posted the briefing" — that's
  only true if `last_run_status == "success"` on `integral_list_routines`.
  If `last_run_status` is `"error"` or the routine is `status: "paused"`
  (auto-paused after repeated failures or a lost access grant), say so
  plainly and suggest the user check chat / re-grant access, don't paper
  over it. `status: "completed"` means it finished its `max_runs` budget
  naturally — that's a success, not a failure; distinguish it from
  `"cancelled"` (the user stopped it) when reporting status.
- Never claim a write was auto-applied unattended unless the target was
  explicitly in that routine's `write_scope` at creation time — anything
  outside the grant always surfaces as a normal staged card, same as a live
  chat turn.
- Delete-class operations (deleting an entry or track) are **never**
  auto-applied by a routine, no matter what `write_scope` says or what the
  user asks for in the schedule — they always require a manual bless on
  each occurrence. Don't promise otherwise.

## Staging discipline

`integral_schedule_task`, `integral_update_routine`, and widening
`write_scope` **stage** routine cards — nothing runs until the user
blesses. Say plainly what cadence / fire time and auto-apply grants you are proposing.
Wait for `[SYSTEM:STAGING-RESOLVED]` before claiming a routine is active.

## Scope

Personal routines only — bound to the creating user, posting into a thread
that user owns. There is no shared/workspace-wide routine surface yet; if
asked, say so rather than staging something that silently stays personal.

## Examples

> **User:** "Every weekday at 9am ET, post a morning briefing here."

1. `integral_list_routines` → check no duplicate morning-briefing routine.
2. Cadence: `cron="0 9 * * 1-5"`, `timezone="America/New_York"`.
3. Instruction (inert): `"Prepare a morning briefing summarizing recent
   activity across my accessible tracks and highlight anything that needs
   attention today."`
4. `integral_schedule_task(cron=..., timezone=..., instruction=...)` → stage.
5. Present: "I'll set this up once you approve — weekdays 9am ET, posts here."

> **User:** "Remind me in two minutes to join my standup."

1. Compute `run_at` = now + 2 minutes (ISO-8601 with offset).
2. Instruction (inert): `"Remind the user it's time to join their standup.
   Send a short, direct nudge."`
3. `integral_schedule_task(run_at=..., instruction=...)` — omit `cron`.
4. Present: "I'll nudge you then once you approve this reminder — please
   bless it before that time." Wait for bless before claiming it's set.


### Reminders delivered with a new operational app

When coordinating with skill integral-scaffold, keep the agreed reminder in the
same open build batch, after the tracks it queries. Named track tokens in the
instruction resolve during approval. A date field is only stored data: the
routine is what checks it and notifies. Use one read-only check for related due
fields rather than one timer per record; each run re-reads current values, so
renewals and service updates automatically change the result. Include overdue
items and an agreed lead window; ignore missing dates, and never notify about
clearly marked demo entries as if they were real obligations. Verify the active
routine and next_run_at after approval. The delivery channel is this personal
chat; do not promise email, push, or team-wide delivery without a real capability.
