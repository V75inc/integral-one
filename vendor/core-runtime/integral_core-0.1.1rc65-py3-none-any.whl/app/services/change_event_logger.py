"""Persist ChangeEvent records as DBLog rows in the logging database.

Mirrors jvspatial's INTERACTION / AUDIT pattern (see
``jvspatial.logging.service.BaseLoggingService.log_custom``): every change
event is stored as a single ``DBLog`` row whose ``log_level="CHANGE_EVENT"``
discriminates it from error logs and other custom-level rows that share the
same logging-database table.

Why this shape:
- No new Node type in the prime application graph (ChangeEvent rows do not
  pad the operational DB).
- One canonical storage shape for all audit-style logs (errors, interactions,
  change events) — DBLog with a log_level discriminator.
- jvspatial's logging API endpoints (``GET /api/logs``) work for free.

In-memory representation
------------------------
``ChangeEventEnvelope`` is the runtime shape passed through ``emit_change_event``
→ ``broadcast_change_event`` → WS subscribers + in-process consumer hooks. It is
NOT a jvspatial Node — it has no DB identity beyond the DBLog row it mirrors,
and consumers should treat the envelope as immutable once persisted.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from app.config import settings

logger = logging.getLogger(__name__)

CHANGE_EVENT_LOG_LEVEL = "CHANGE_EVENT"


def is_change_event_enabled() -> bool:
    """Master kill switch: ``settings.CHANGE_EVENT_ENABLED`` (default True)."""
    return bool(settings.CHANGE_EVENT_ENABLED)


@dataclass
class ChangeEventEnvelope:
    """In-memory shape of a ChangeEvent. Mirrors one DBLog row.

    ``id`` is populated by ``ChangeEventLogger.persist`` from the DBLog row's
    id once stored; on a disabled / unpersisted emit it stays empty.

    ``details`` (Phase 3 Plan 03-05) is an additive structured-metadata slot.
    Today it carries the {failed_action, decision_reason, matched_policy_id}
    payload of ``policy.deny`` denial events emitted by the policy engine. It
    is persisted on DBLog.log_data["details"] and survives the Phase 2 D-04
    TTL reclaim (only ``before``/``after`` snapshots are nulled by reclaim).
    Phase 2 callers continue to omit it — the default is None.
    """

    ts: str
    actor_kind: str
    actor_id: str
    action: str
    resource_type: str
    resource_id: str
    scope: str
    before: Optional[Dict[str, Any]] = None
    after: Optional[Dict[str, Any]] = None
    actor_capability: Optional[str] = None
    snapshot_reclaimed_at: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    id: str = ""
    workspace_id: Optional[str] = None
    delivery_ts: str = ""

    def to_wire(self) -> Dict[str, Any]:
        """Serialize for the WS broadcast — nested ``actor`` shape (ChangeEventResponse)."""
        return {
            "id": self.id,
            "ts": self.ts,
            "actor": {
                "kind": self.actor_kind,
                "id": self.actor_id,
                "capability": self.actor_capability,
            },
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "scope": self.scope,
            "before": self.before,
            "after": self.after,
            "details": self.details,
        }

    def to_wire_flat(self) -> Dict[str, Any]:
        """Serialize for the HTTP audit-log + events_polling endpoints.

        Flat actor fields (``actor_kind``, ``actor_id``, ``actor_capability``).
        Matches the previous Node-export shape so existing API consumers do not
        need to migrate.
        """
        return {
            "id": self.id,
            "ts": self.ts,
            "actor_kind": self.actor_kind,
            "actor_id": self.actor_id,
            "actor_capability": self.actor_capability,
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "scope": self.scope,
            "before": self.before,
            "after": self.after,
            "details": self.details,
        }


def envelope_from_dblog(log: Any) -> ChangeEventEnvelope:
    """Reconstruct a ChangeEventEnvelope from a stored DBLog row."""
    data = getattr(log, "log_data", None) or {}
    logged_at = getattr(log, "logged_at", None)
    if isinstance(logged_at, datetime):
        ts = logged_at.isoformat()
    elif isinstance(logged_at, str):
        ts = logged_at
    else:
        ts = ""
    return ChangeEventEnvelope(
        id=getattr(log, "id", "") or "",
        ts=data.get("ts") or ts,
        delivery_ts=ts,
        actor_kind=data.get("actor_kind", "system"),
        actor_id=data.get("actor_id", ""),
        actor_capability=data.get("actor_capability"),
        action=getattr(log, "event_code", "") or data.get("action", ""),
        resource_type=data.get("resource_type", ""),
        resource_id=data.get("resource_id", ""),
        scope=getattr(log, "path", "") or data.get("scope", ""),
        before=data.get("before"),
        after=data.get("after"),
        snapshot_reclaimed_at=data.get("snapshot_reclaimed_at"),
        # Phase 3 Plan 03-05 — additive metadata slot. Round-trips through
        # DBLog.log_data["details"]. None on pre-Plan-05 rows.
        details=data.get("details"),
        workspace_id=data.get("workspace_id"),
    )


def _envelope_log_data(envelope: ChangeEventEnvelope) -> Dict[str, Any]:
    """Build the ``log_data`` dict persisted on a DBLog row."""
    return {
        "message": envelope.action,
        "workspace_id": envelope.workspace_id,
        "log_level": CHANGE_EVENT_LOG_LEVEL,
        "ts": envelope.ts,
        "actor_kind": envelope.actor_kind,
        "actor_id": envelope.actor_id,
        "actor_capability": envelope.actor_capability,
        "resource_type": envelope.resource_type,
        "resource_id": envelope.resource_id,
        "scope": envelope.scope,
        "before": envelope.before,
        "after": envelope.after,
        "snapshot_reclaimed_at": envelope.snapshot_reclaimed_at,
        # Phase 3 Plan 03-05 — additive metadata slot. Persisted on every row;
        # None on the Phase 2 happy paths and populated only by policy.deny
        # denial events emitted from policy_engine.evaluate.
        "details": envelope.details,
    }


class ChangeEventLogger:
    """Persistence + query for ChangeEvent records stored as DBLog rows.

    Storage shape: ``DBLog`` with ``log_level="CHANGE_EVENT"``. The
    discriminator keeps change-event rows queryable independent of other log
    levels (ERROR, CRITICAL, INTERACTION, AUDIT, …) that share the table.
    """

    def __init__(self, database_name: Optional[str] = None) -> None:
        self._database_name = (
            database_name or settings.DB_LOGGING_DB_NAME or "logs"
        ).strip() or "logs"

    @property
    def database_name(self) -> str:
        """Name of the jvspatial logging database this logger targets."""
        return self._database_name

    def _get_log_db(self) -> Any:
        from jvspatial.db import get_database_manager

        try:
            manager = get_database_manager()
            registered = manager.list_databases()
        except Exception as e:
            logger.warning("change_event_logger: database manager unavailable: %s", e)
            return None
        if self._database_name not in registered:
            logger.warning(
                "change_event_logger: logging database %r not registered "
                "(registered=%s); ChangeEvent emits will not be persisted",
                self._database_name,
                list(registered),
            )
            return None
        return manager.get_database(self._database_name)

    def _get_log_context(self) -> Any:
        from jvspatial.core.context import GraphContext

        log_db = self._get_log_db()
        if log_db is None:
            return None
        return GraphContext(database=log_db)

    async def ensure_indexes(self) -> None:
        """Ensure DBLog indexes exist on the routed logging database."""
        from jvspatial.logging.models import DBLog

        from app.services.storage_indexes.runtime import managed

        if managed():
            return  # Provisioned and verified by the catalog lifecycle.
        ctx = self._get_log_context()
        if ctx is None:
            return
        try:
            await ctx.ensure_indexes(DBLog)
            await ctx.database.create_index(
                "object",
                [
                    ("context.log_level", 1),
                    ("context.log_data.workspace_id", 1),
                    ("context.logged_at", -1),
                    ("id", -1),
                ],
            )
            await ctx.database.create_index(
                "object",
                [
                    ("context.log_level", 1),
                    ("context.path", 1),
                    ("context.logged_at", -1),
                    ("id", -1),
                ],
            )
            # The event feed (/api/events) reads oldest first. jvspatial sorts
            # ascending keys NULLS LAST, which a backward scan of the newest-
            # first index above cannot serve, so it gets its own ordered index,
            # limited to DBLog rows.
            await ctx.database.create_index(
                "object",
                [
                    ("context.log_level", 1),
                    ("context.log_data.workspace_id", 1),
                    ("context.logged_at", 1),
                    ("id", 1),
                ],
                entity="DBLog",
                partial_by_entity=True,
            )
            # Legacy/null attribution has its own ordered stream, instead of
            # forcing a bitmap OR and sort of every workspace candidate.
            await ctx.database.create_index(
                "object",
                [("context.log_level", 1), ("context.logged_at", -1), ("id", -1)],
                entity="DBLog",
                partial_by_entity=True,
                index_partial_filter_expression={
                    "context.log_data.workspace_id": {"$exists": False}
                },
            )
            # Oldest-first twin of the unattributed stream, for the event feed.
            await ctx.database.create_index(
                "object",
                [("context.log_level", 1), ("context.logged_at", 1), ("id", 1)],
                entity="DBLog",
                partial_by_entity=True,
                index_partial_filter_expression={
                    "context.log_data.workspace_id": {"$exists": False}
                },
            )
        except Exception as e:
            logger.warning("change_event_logger: ensure_indexes failed: %s", e)

    async def persist(self, envelope: ChangeEventEnvelope) -> Any:
        """Persist the envelope as a DBLog row. Mutates ``envelope.id``."""
        from jvspatial.logging.models import DBLog

        ctx = self._get_log_context()
        if ctx is None:
            raise RuntimeError("Audit logging database unavailable")

        try:
            ts_dt = datetime.fromisoformat(envelope.ts)
            if ts_dt.tzinfo is None:
                ts_dt = ts_dt.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            ts_dt = datetime.now(timezone.utc)
            envelope.ts = ts_dt.isoformat()

        # Indexed attribution is a candidate filter, never authorization.
        # Legacy/deleted scope facts remain unattributed and need live read gates.
        from app.services.event_history import event_workspace_id

        if envelope.workspace_id is None:
            try:
                envelope.workspace_id = await event_workspace_id(envelope.scope)
            except Exception:
                logger.warning(
                    "change_event_logger: workspace attribution unavailable",
                    exc_info=True,
                )
                envelope.workspace_id = None
        import hashlib

        fact_id = (envelope.details or {}).get("event_fact_id")
        identity = (
            {"id": "o.DBLog." + hashlib.sha256(str(fact_id).encode()).hexdigest()}
            if fact_id
            else {}
        )
        log_entry = DBLog(
            **identity,
            status_code=None,
            event_code=envelope.action,
            log_level=CHANGE_EVENT_LOG_LEVEL,
            path=envelope.scope,
            method="",
            logged_at=ts_dt,
            log_data=_envelope_log_data(envelope),
        )
        await log_entry.set_context(ctx)
        # Serialize persistence order, not event occurrence order. Forward cursors
        # must see a late retry even after newer business events were delivered.
        from jvspatial.db.transaction import transaction_context

        from app.services.app_operations.transaction_scope import _transaction_database

        db = _transaction_database(ctx.database)
        if not getattr(db, "supports_transactions", False):
            if (envelope.details or {}).get("event_fact_id"):
                raise RuntimeError("Durable audit delivery requires transactions")
            await log_entry.save()
            envelope.id = log_entry.id
            envelope.delivery_ts = envelope.ts
            return log_entry
        async with transaction_context(db) as transaction:
            if transaction is None:
                raise RuntimeError("Audit transactions unavailable")
            clock_id = "o.EventDeliveryClock.global"
            await transaction.insert_if_absent(
                "object",
                {"id": clock_id, "entity": "EventDeliveryClock", "context": {"ts": ""}},
            )
            clock = await transaction.find_one_and_update(
                "object", {"id": clock_id}, {"$set": {"context.locked": True}}
            )
            existing = (
                await transaction.get("object", log_entry.id) if fact_id else None
            )
            if existing is not None:
                envelope.id = log_entry.id
                envelope.delivery_ts = existing["context"]["logged_at"]
                return DBLog(id=log_entry.id, **existing["context"])
            previous = clock["context"].get("ts") or ""
            if not previous:
                historical = await transaction.find(
                    "object",
                    {"entity": "DBLog", "context.log_level": CHANGE_EVENT_LOG_LEVEL},
                    limit=1,
                    sort=[("context.logged_at", -1), ("id", -1)],
                )
                if historical:
                    previous = historical[0]["context"].get("logged_at") or ""
            delivered_at = datetime.now(timezone.utc)
            if previous:
                delivered_at = max(
                    delivered_at,
                    datetime.fromisoformat(previous) + timedelta(microseconds=1),
                )
            log_entry.logged_at = delivered_at
            envelope.delivery_ts = delivered_at.isoformat()
            # Export stays bound to the logging context, never the prime graph.
            document = await log_entry.export()
            await transaction.save("object", document)
            await transaction.find_one_and_update(
                "object",
                {"id": clock_id},
                {"$set": {"context.ts": envelope.delivery_ts}},
            )
        envelope.id = log_entry.id
        return log_entry

    async def find_page(
        self,
        *,
        cursor: Optional[str],
        limit: int,
        descending: bool,
        scope: Optional[str] = None,
        scope_aliases: Optional[List[str]] = None,
        actor_kind: Optional[str] = None,
        workspace_id: Optional[str] = None,
        event_action: Optional[str] = None,
        resource_id: Optional[str] = None,
        resource_type: Optional[str] = None,
    ) -> List[Any]:
        """Read a bounded timestamp/id keyset window; never mask a store outage.

        Unattributed legacy rows remain candidates and must pass canonical
        workspace and resource checks before exposure. New rows are narrowed
        with an indexed server-derived workspace marker.
        """
        from jvspatial.logging.models import DBLog

        from app.api.errors import BadRequestError, QueryUnavailableError
        from app.services.pagination import _keyset_clause, decode_cursor

        ctx = self._get_log_context()
        if ctx is None:
            raise QueryUnavailableError(message="Event history is unavailable")
        direction = -1 if descending else 1
        sort = [("context.logged_at", direction), ("id", direction)]
        query: Dict[str, Any] = {
            "entity": "DBLog",
            "context.log_level": CHANGE_EVENT_LOG_LEVEL,
        }
        for field, value in (
            ("context.path", scope),
            ("context.log_data.actor_kind", actor_kind),
            ("context.event_code", event_action),
            ("context.log_data.resource_id", resource_id),
            ("context.log_data.resource_type", resource_type),
        ):
            if value:
                query[field] = value
        if scope_aliases:
            query["context.path"] = {"$in": scope_aliases}
        clauses = [query]
        if cursor:
            cursor_id, cursor_ts = decode_cursor(cursor)
            try:
                if (
                    not isinstance(cursor_id, str)
                    or not cursor_id
                    or len(cursor_id) > 512
                    or not isinstance(cursor_ts, str)
                    or len(cursor_ts) > 64
                ):
                    raise ValueError("Invalid cursor values")
                datetime.fromisoformat(cursor_ts)
            except (TypeError, ValueError) as exc:
                raise BadRequestError(message="Invalid event history cursor") from exc
            after = _keyset_clause(cursor, sort)
            if after:
                clauses.append(after)
        try:
            page_limit = min(max(1, limit), 200)
            if workspace_id:
                rows = []
                # Both directions use scalar equality so the native JSONB
                # ordering index can satisfy the fixed workspace prefix.
                attributed: Any = workspace_id
                for attribution in (
                    {"context.log_data.workspace_id": attributed},
                    {"context.log_data.workspace_id": {"$exists": False}},
                ):
                    stream_query = dict(clauses[0])
                    rows.extend(
                        await ctx.database.find(
                            "object",
                            {"$and": [stream_query, attribution, *clauses[1:]]},
                            limit=page_limit,
                            sort=sort,
                        )
                    )
                # Each disjoint stream contributes at most one page. Merging
                # at most 400 rows preserves the database's timestamp/id keyset.
                # Corrupt timestamps must fail rather than invent continuation.
                for row in rows:
                    if not isinstance((row.get("context") or {}).get("logged_at"), str):
                        raise ValueError("Invalid event timestamp")
                unique_rows = {row["id"]: row for row in rows}
                rows = sorted(
                    unique_rows.values(),
                    key=lambda row: (row["context"]["logged_at"], row["id"]),
                    reverse=descending,
                )[:page_limit]
            else:
                rows = await ctx.database.find(
                    "object",
                    {"$and": clauses},
                    limit=page_limit,
                    sort=sort,
                )
            results: List[DBLog] = []
            for row in rows:
                fields = dict(row.get("context") or {})
                # Corruption is not an empty history and cannot invent a cursor.
                entry = DBLog(id=row["id"], **fields)
                await entry.set_context(ctx)
                results.append(entry)
            return results
        except Exception as exc:
            logger.warning("change_event_logger: history read failed", exc_info=True)
            raise QueryUnavailableError(message="Event history is unavailable") from exc

    async def find_all(
        self,
        *,
        scope: Optional[str] = None,
        actor_kind: Optional[str] = None,
    ) -> List[Any]:
        """Return all DBLog rows with ``log_level=CHANGE_EVENT`` matching filters.

        ``scope`` filters by ``DBLog.path`` (where envelope.scope lives).
        ``actor_kind`` filters by the value stored in ``log_data.actor_kind``.
        """
        from jvspatial.logging.models import DBLog

        ctx = self._get_log_context()
        if ctx is None:
            return []
        query: Dict[str, Any] = {
            "entity": "DBLog",
            "context.log_level": CHANGE_EVENT_LOG_LEVEL,
        }
        if scope:
            query["context.path"] = scope
        if actor_kind:
            query["context.log_data.actor_kind"] = actor_kind

        try:
            raw = await ctx.database.find("object", query)
        except Exception as e:
            logger.warning("change_event_logger: find failed: %s", e)
            return []

        results: List[DBLog] = []
        for row in raw:
            try:
                context_data = row.get("context", {}).copy()
                row_id = row.get("id", "")
                if "logged_at" in context_data and isinstance(
                    context_data["logged_at"], str
                ):
                    try:
                        context_data["logged_at"] = datetime.fromisoformat(
                            context_data["logged_at"].replace("Z", "+00:00")
                        )
                    except (ValueError, AttributeError):
                        context_data["logged_at"] = datetime.now(timezone.utc)
                entry = DBLog(id=row_id, **context_data)
                await entry.set_context(ctx)
                results.append(entry)
            except Exception as e:
                logger.warning(
                    "change_event_logger: skipping unparseable DBLog row %s: %s",
                    row.get("id"),
                    e,
                )
        return results

    async def find_reclaimable(self, *, cutoff: datetime, limit: int) -> List[Any]:
        """Return up to ``limit`` CHANGE_EVENT rows older than ``cutoff`` whose
        snapshot is unreclaimed.

        Pushes both predicates into the database query so the TTL sweep
        does not deserialize every change-event row every pass:

        * ``context.logged_at < cutoff`` — ISO-8601 strings compare
          lexicographically (all rows are written UTC by ``persist``).
        * ``context.log_data.snapshot_reclaimed_at`` absent / null.

        ``limit`` is mandatory and bounds the hydration: the predicate alone
        bounds the STEADY state, but the first pass after the TTL is crossed
        (or lowered, or after an outage longer than the TTL window) can match
        an arbitrarily large backlog. Callers page by calling repeatedly —
        reclaimed rows drop out of the predicate, so successive calls make
        progress without a cursor. Rows are ordered by ``id`` so a page is
        deterministic.

        Callers should still re-check ``logged_at`` on the hydrated row —
        the string comparison is a coarse filter, not the authority.
        """
        from jvspatial.logging.models import DBLog

        ctx = self._get_log_context()
        if ctx is None:
            return []
        if limit <= 0:
            return []
        if cutoff.tzinfo is None:
            cutoff = cutoff.replace(tzinfo=timezone.utc)
        query: Dict[str, Any] = {
            "entity": "DBLog",
            "context.log_level": CHANGE_EVENT_LOG_LEVEL,
            "context.logged_at": {"$lt": cutoff.isoformat()},
            "context.log_data.snapshot_reclaimed_at": {"$exists": False},
        }
        try:
            raw = await ctx.database.find(
                "object", query, limit=limit, sort=[("id", 1)]
            )
        except Exception as e:
            logger.warning("change_event_logger: find_reclaimable failed: %s", e)
            return []

        results: List[DBLog] = []
        for row in raw:
            try:
                context_data = row.get("context", {}).copy()
                row_id = row.get("id", "")
                if "logged_at" in context_data and isinstance(
                    context_data["logged_at"], str
                ):
                    try:
                        context_data["logged_at"] = datetime.fromisoformat(
                            context_data["logged_at"].replace("Z", "+00:00")
                        )
                    except (ValueError, AttributeError):
                        context_data["logged_at"] = datetime.now(timezone.utc)
                entry = DBLog(id=row_id, **context_data)
                await entry.set_context(ctx)
                results.append(entry)
            except Exception as e:
                logger.warning(
                    "change_event_logger: skipping unparseable DBLog row %s: %s",
                    row.get("id"),
                    e,
                )
        return results

    async def get(self, event_id: str) -> Any:
        """Fetch a single DBLog row by id (returns None if absent or wrong level)."""
        from jvspatial.logging.models import DBLog

        ctx = self._get_log_context()
        if ctx is None or not event_id:
            return None
        try:
            entry = await ctx.get(DBLog, event_id)
        except Exception as e:
            logger.warning("change_event_logger: get(%s) failed: %s", event_id, e)
            return None
        if entry is None:
            return None
        if getattr(entry, "log_level", "") != CHANGE_EVENT_LOG_LEVEL:
            return None
        return entry

    async def find_by_staging_token(self, staging_token: str) -> List[Any]:
        """Return CHANGE_EVENT rows whose ``details.staging_token`` matches."""
        from jvspatial.logging.models import DBLog

        if not staging_token:
            return []
        ctx = self._get_log_context()
        if ctx is None:
            return []
        query: Dict[str, Any] = {
            "entity": "DBLog",
            "context.log_level": CHANGE_EVENT_LOG_LEVEL,
            "context.log_data.details.staging_token": staging_token,
        }
        try:
            raw = await ctx.database.find("object", query)
        except Exception as e:
            logger.warning("change_event_logger: find_by_staging_token failed: %s", e)
            return []

        results: List[DBLog] = []
        for row in raw:
            try:
                context_data = row.get("context", {}).copy()
                row_id = row.get("id", "")
                if "logged_at" in context_data and isinstance(
                    context_data["logged_at"], str
                ):
                    try:
                        context_data["logged_at"] = datetime.fromisoformat(
                            context_data["logged_at"].replace("Z", "+00:00")
                        )
                    except (ValueError, AttributeError):
                        context_data["logged_at"] = datetime.now(timezone.utc)
                entry = DBLog(id=row_id, **context_data)
                await entry.set_context(ctx)
                results.append(entry)
            except Exception as e:
                logger.warning(
                    "change_event_logger: skipping unparseable DBLog row %s: %s",
                    row.get("id"),
                    e,
                )
        results.sort(
            key=lambda r: (
                getattr(r, "logged_at", datetime.min.replace(tzinfo=timezone.utc)),
                getattr(r, "id", ""),
            )
        )
        return results

    async def find_after_checkpoint(
        self,
        *,
        last_logged_at: Optional[str] = None,
        last_event_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[Any]:
        """Return CHANGE_EVENT rows strictly after ``(last_logged_at, id)``.

        Ordering is ``logged_at`` then ``id``. When ``last_logged_at`` is empty,
        returns the earliest bounded page. Does not advance any checkpoint —
        the work-events consumer owns that.
        """
        from app.services.pagination import encode_cursor

        cursor = (
            encode_cursor(last_event_id or "0", last_logged_at)
            if last_logged_at
            else None
        )
        return await self.find_page(
            cursor=cursor, limit=min(limit, 100), descending=False
        )

    async def patch_event_details(self, event_id: str, patch: Dict[str, Any]) -> bool:
        """Merge ``patch`` into an existing row's ``log_data.details``."""
        row = await self.get(event_id)
        if row is None:
            return False
        data = dict(getattr(row, "log_data", None) or {})
        details = dict(data.get("details") or {})
        details.update(patch)
        data["details"] = details
        row.log_data = data
        await row.save()
        return True


_singleton: Optional[ChangeEventLogger] = None


def get_change_event_logger() -> ChangeEventLogger:
    """Process-wide singleton. ``reset_for_testing()`` drops the cache."""
    global _singleton
    if _singleton is None:
        _singleton = ChangeEventLogger()
    return _singleton


def reset_for_testing() -> None:
    """Drop the cached logger singleton. Test hygiene only."""
    global _singleton
    _singleton = None


__all__ = [
    "CHANGE_EVENT_LOG_LEVEL",
    "ChangeEventEnvelope",
    "ChangeEventLogger",
    "envelope_from_dblog",
    "get_change_event_logger",
    "is_change_event_enabled",
    "reset_for_testing",
]
