"""Shared single-file upload helpers used by both entry- and chat-scoped
attachment upload paths (``app/api/attachments.py`` and the chat-upload
endpoint, Slice B).

Extracted so the chat-upload path (Task B2) can reuse the same MIME
allow-list, streaming reader, and sniff-reconciliation logic without
duplicating it or importing module-private names across files.
"""

from __future__ import annotations

import hashlib
import os
from typing import List, Optional, Tuple

from fastapi import UploadFile

from app.api.errors import BadRequestError
from app.services.attachment_content_sniffer import sniff_bytes

UPLOAD_READ_CHUNK = 1024 * 1024

ALLOWED_MIME_PREFIXES = ("image/", "video/", "audio/")
ALLOWED_MIME_TYPES = frozenset(
    {
        "application/pdf",
        "text/plain",
        "text/csv",
        "text/markdown",
        "application/json",
        "application/zip",
        "application/x-zip-compressed",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.ms-excel",
        "application/vnd.ms-powerpoint",
        # Business documents beyond the basics. All are stored and served as
        # downloads or previews, never executed. Executables, scripts and
        # active web content (html, js, exe, sh, bat, dll ...) stay refused.
        "application/rtf",
        "text/rtf",
        "application/vnd.oasis.opendocument.text",
        "application/vnd.oasis.opendocument.spreadsheet",
        "application/vnd.oasis.opendocument.presentation",
        "application/vnd.oasis.opendocument.graphics",
        "application/epub+zip",
        "application/xml",
        "text/xml",
        "application/yaml",
        "text/tab-separated-values",
        "text/calendar",
        "text/vcard",
        "message/rfc822",
        "application/vnd.ms-outlook",
        "application/vnd.ms-project",
        "application/vnd.ms-publisher",
        "application/onenote",
        "application/vnd.visio",
        "application/vnd.ms-visio.drawing",
        "application/vnd.ms-word.document.macroenabled.12",
        "application/vnd.ms-excel.sheet.macroenabled.12",
        "application/vnd.ms-powerpoint.presentation.macroenabled.12",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
        "application/vnd.openxmlformats-officedocument.presentationml.template",
        "application/vnd.apple.pages",
        "application/vnd.apple.numbers",
        "application/vnd.apple.keynote",
        "application/postscript",
        "image/vnd.dwg",
        "image/vnd.dxf",
        "image/vnd.adobe.photoshop",
        "application/x-indesign",
        "application/x-tar",
        "application/gzip",
        "application/x-7z-compressed",
        "application/vnd.rar",
    }
)

FILENAME_EXT_TO_MIME = {
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".avif": "image/avif",
    ".heic": "image/heic",
    ".heif": "image/heif",
    ".svg": "image/svg+xml",
    ".txt": "text/plain",
    ".csv": "text/csv",
    ".md": "text/markdown",
    ".json": "application/json",
    ".zip": "application/zip",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".rtf": "application/rtf",
    ".odt": "application/vnd.oasis.opendocument.text",
    ".ods": "application/vnd.oasis.opendocument.spreadsheet",
    ".odp": "application/vnd.oasis.opendocument.presentation",
    ".odg": "application/vnd.oasis.opendocument.graphics",
    ".epub": "application/epub+zip",
    ".xml": "application/xml",
    ".yaml": "application/yaml",
    ".yml": "application/yaml",
    ".tsv": "text/tab-separated-values",
    ".log": "text/plain",
    ".ics": "text/calendar",
    ".vcf": "text/vcard",
    ".eml": "message/rfc822",
    ".msg": "application/vnd.ms-outlook",
    ".mpp": "application/vnd.ms-project",
    ".pub": "application/vnd.ms-publisher",
    ".one": "application/onenote",
    ".vsd": "application/vnd.visio",
    ".vsdx": "application/vnd.ms-visio.drawing",
    ".docm": "application/vnd.ms-word.document.macroenabled.12",
    ".xlsm": "application/vnd.ms-excel.sheet.macroenabled.12",
    ".pptm": "application/vnd.ms-powerpoint.presentation.macroenabled.12",
    ".dotx": "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
    ".xltx": "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
    ".potx": "application/vnd.openxmlformats-officedocument.presentationml.template",
    ".dot": "application/msword",
    ".xlt": "application/vnd.ms-excel",
    ".pot": "application/vnd.ms-powerpoint",
    ".pages": "application/vnd.apple.pages",
    ".numbers": "application/vnd.apple.numbers",
    ".key": "application/vnd.apple.keynote",
    ".ps": "application/postscript",
    ".eps": "application/postscript",
    ".dwg": "image/vnd.dwg",
    ".dxf": "image/vnd.dxf",
    ".psd": "image/vnd.adobe.photoshop",
    ".indd": "application/x-indesign",
    ".tar": "application/x-tar",
    ".gz": "application/gzip",
    ".7z": "application/x-7z-compressed",
    ".rar": "application/vnd.rar",
}

# libmagic reports these when it can name a container or no type at all but not
# the document inside (an OLE .msg / .vsd / .mpp, a zip-based .pages, a text
# .yaml). Only then may the file extension decide the type. A specific binary
# type (an executable) is never rescued by renaming the file.
_GENERIC_SNIFFS = frozenset(
    {
        "",
        "application/octet-stream",
        "application/zip",
        "application/x-zip-compressed",
        "application/x-ole-storage",
        "application/cdfv2",
        "application/x-cfb",
        "application/vnd.ms-office",
        "application/x-empty",
        "inode/x-empty",
        "text/plain",
        "text/xml",
        "application/xml",
        "application/gzip",
        "application/x-gzip",
    }
)


def is_mime_allowed(mime: str) -> bool:
    """Return True when ``mime`` matches the allow-list or an allowed prefix."""
    return (
        mime in ALLOWED_MIME_TYPES
        or mime in _extra_allowed_mimes()
        or any(mime.startswith(p) for p in ALLOWED_MIME_PREFIXES)
    )


def _extra_allowed_mimes() -> frozenset:
    """Deployment additions (``ATTACHMENT_EXTRA_ALLOWED_MIME_TYPES``, comma list)."""
    from app.config import settings

    raw = getattr(settings, "ATTACHMENT_EXTRA_ALLOWED_MIME_TYPES", "") or ""
    return frozenset(m.strip().lower() for m in raw.split(",") if m.strip())


def fallback_mime_from_filename(filename: str) -> Optional[str]:
    """Return the MIME type implied by ``filename``'s extension, if known."""
    ext = os.path.splitext(filename or "")[1].lower()
    return FILENAME_EXT_TO_MIME.get(ext)


def validate_image_upload_size(mime_type: str, size: int, limit: int) -> None:
    """Enforce the entry image limit after resolving the content type."""
    if mime_type.lower().startswith("image/") and size > limit:
        raise BadRequestError(
            message=f"Image too large (maximum {limit // (1024 * 1024)} MB)."
        )


def image_signature(head: bytes) -> bool:
    """Recognize common image headers even when optional libmagic is absent."""
    return (
        head.startswith((b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF87a", b"GIF89a"))
        or (head.startswith(b"RIFF") and head[8:12] == b"WEBP")
        or (
            head[4:8] == b"ftyp"
            and head[8:12]
            in (b"avif", b"avis", b"heic", b"heix", b"hevc", b"hevx", b"mif1", b"msf1")
        )
        or head.startswith((b"II*\x00", b"MM\x00*", b"BM"))
    )


async def read_upload_streaming(
    file: UploadFile, *, max_bytes: int, image_max_bytes: Optional[int] = None
) -> Tuple[bytes, str, str, bytes]:
    """Read a multipart upload chunk-by-chunk under ``max_bytes``.

    Returns:
        content: Full byte buffer of the upload.
        filename: Best-effort filename from the upload (sanitized later
            by the storage layer).
        sha256_hex: Incremental SHA-256 over the bytes, hex-encoded.
        head_bytes: First chunk (used downstream for MIME sniffing —
            avoids a second pass over the full buffer for large files).
    """
    chunks: List[bytes] = []
    head: Optional[bytes] = None
    total = 0
    hasher = hashlib.sha256()
    is_image = False
    while True:
        chunk = await file.read(UPLOAD_READ_CHUNK)
        if not chunk:
            break
        if head is None:
            head = chunk[:4096]
            if image_max_bytes is not None:
                mime = resolve_effective_mime(
                    head_bytes=head,
                    content_type_claim=file.content_type or "",
                    filename=file.filename or "unnamed",
                )
                is_image = mime.startswith("image/") or image_signature(head)
        total += len(chunk)
        if is_image and image_max_bytes is not None:
            validate_image_upload_size("image/", total, image_max_bytes)
        if total > max_bytes:
            raise BadRequestError(
                message=(
                    f"File too large (max {max_bytes // (1024 * 1024)}MB). "
                    "Use the chunked-upload endpoint for larger files."
                ),
            )
        hasher.update(chunk)
        chunks.append(chunk)
    content = b"".join(chunks)
    name = file.filename or "unnamed"
    return content, name, hasher.hexdigest(), head or b""


def resolve_effective_mime(
    *,
    head_bytes: bytes,
    content_type_claim: str,
    filename: str,
) -> str:
    """Sniff the file's MIME and reconcile with the client's claim.

    - When libmagic is available, the sniffed type is authoritative.
    - When the claim disagrees with the sniff, raise BadRequestError.
    - When neither claim nor sniff yields an allow-listed type but the
      filename extension does, use the extension-derived MIME (covers
      mobile clients that send ``application/octet-stream`` for safe
      file types).
    """
    claim = (content_type_claim or "").split(";", 1)[0].strip().lower()
    sniff = sniff_bytes(
        head_bytes,
        claimed_mime=claim,
        filename=filename,
    )
    if sniff.mismatch:
        raise BadRequestError(
            message=(
                "File type does not match its content. "
                f"Client claimed {claim or 'unknown'}; "
                f"server detected {sniff.sniffed_mime or 'unknown'}."
            ),
        )

    candidate = sniff.effective_mime or claim
    # A document whose container libmagic can name but not the format inside
    # (zip-based .pages, OLE .msg, plain-text .yaml): the extension decides,
    # so the stored type is the document's, not the container's.
    fallback = fallback_mime_from_filename(filename)
    if (
        fallback
        and is_mime_allowed(fallback)
        and (candidate or "").lower() in _GENERIC_SNIFFS
    ):
        return fallback
    if is_mime_allowed(candidate):
        return candidate

    # Generic octet-stream — try the filename extension as a last resort.
    # Same allow-list applies.
    if fallback and is_mime_allowed(fallback):
        return fallback

    raise BadRequestError(
        message="File type not allowed. Use common documents, images, audio, or video.",
    )
