"""Work-kernel boot probes, recovery, and background loops (Task 10)."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Any, List

log = logging.getLogger(__name__)

# The periodic recovery pass rechecks outbox facts only for work changed in this window; a full
# recheck of all history runs once per hour (the boot-time pass also does one).
_RECENT_RECONCILE_WINDOW_SECONDS = 15 * 60
_FULL_RECONCILE_SECONDS = 60 * 60


class WorkKernelBootError(RuntimeError):
    """Production fail-closed boot failure for the durable work kernel."""


def _is_dev_boot() -> bool:
    from app.config import settings

    return bool(
        settings.DEBUG or os.getenv("PYTEST_CURRENT_TEST") or os.getenv("TESTING")
    )


def _db_type() -> str:
    return (os.environ.get("JVSPATIAL_DB_TYPE") or "postgres").strip().lower()


async def probe_transaction_capabilities(db: Any = None) -> None:
    """Require public CAS + insert_if_absent on the Postgres transaction handle."""
    from jvspatial.db import get_prime_database

    database = db or get_prime_database()
    # Unwrap ObservableDatabase when present.
    inner = getattr(database, "_db", None) or getattr(database, "db", None) or database
    begin = getattr(inner, "begin_transaction", None)
    if begin is None:
        raise WorkKernelBootError("database missing begin_transaction")
    txn = await begin()
    try:
        for method in ("find_one_and_update", "insert_if_absent", "get"):
            if not hasattr(txn, method):
                raise WorkKernelBootError(
                    f"transaction handle missing public method {method}"
                )
    finally:
        rollback = getattr(inner, "rollback_transaction", None)
        if rollback is not None:
            try:
                await rollback(txn)
            except Exception:  # noqa: BLE001
                pass


async def assert_work_kernel_store_posture() -> None:
    """Fail closed for Mongo / multi-worker non-Postgres in production."""
    db_type = _db_type()
    if db_type == "mongo":
        raise WorkKernelBootError("Mongo is unsupported for the Phase B work kernel")
    if db_type != "postgres" and not _is_dev_boot():
        raise WorkKernelBootError(
            f"production work kernel requires postgres, found {db_type!r}"
        )
    if db_type == "postgres":
        await probe_transaction_capabilities()


async def run_startup_recovery() -> Any:
    """Reconcile durable work before starting API-side execution loops."""
    from app.agentive.services.work_recovery import run_recovery_pass

    return await run_recovery_pass(reclaim_worker_id="startup-recovery")


async def _app_schedule_loop(*, idle_sleep: float = 60.0) -> None:
    """Queue scheduled App tools on their cron slots (see app_schedules)."""
    from app.agentive.services.app_schedules import enqueue_due_app_schedules

    while True:
        try:
            await enqueue_due_app_schedules()
        except Exception:  # noqa: BLE001
            log.exception("App schedule pass failed")
        await asyncio.sleep(idle_sleep)


async def _recovery_loop(*, idle_sleep: float = 15.0) -> None:
    from app.agentive.services.work_model_receipts import (
        reconcile_retained_model_receipts,
    )
    from app.agentive.services.work_recovery import run_recovery_pass
    from app.services.app_operations.event_outbox import (
        deliver_pending_cleanup_events,
    )
    from app.services.resident_assignment_execution import (
        deliver_resident_assignment_approvals,
    )

    model_receipt_cursor: dict[str, str] = {}
    next_harness_retention = 0.0
    next_full_reconcile = 0.0
    next_draft_cleanup = 0.0
    while True:
        try:
            # Checking every work item ever created on each pass costs more with every
            # run, so the periodic pass only looks at recent changes and does a full
            # check once an hour. The boot-time reconcile already did one.
            since = None
            if time.monotonic() >= next_full_reconcile:
                next_full_reconcile = time.monotonic() + _FULL_RECONCILE_SECONDS
            else:
                since = (
                    datetime.now(timezone.utc)
                    - timedelta(seconds=_RECENT_RECONCILE_WINDOW_SECONDS)
                ).isoformat()
            await run_recovery_pass(
                reclaim_worker_id="periodic-recovery", reconcile_updated_since=since
            )
            await deliver_pending_cleanup_events()
            await deliver_resident_assignment_approvals()
            from app.services.email_delivery import purge_email_history

            await purge_email_history()
        except Exception:  # noqa: BLE001
            log.exception("work recovery loop failed")

        try:
            await reconcile_retained_model_receipts(model_receipt_cursor)
        except Exception:  # noqa: BLE001
            log.exception("Retained model receipt reconciliation failed")

        if time.monotonic() >= next_draft_cleanup:
            try:
                from app.services.document_draft_cleanup import (
                    reconcile_draft_blob_attempts,
                )

                await reconcile_draft_blob_attempts()
            except Exception:  # noqa: BLE001
                log.exception("Generated file cleanup pass failed")
            next_draft_cleanup = time.monotonic() + 60

        if time.monotonic() >= next_harness_retention:
            try:
                from app.agentive.harness.turn_input import (
                    purge_expired_turn_input_capsules,
                )
                from app.config import settings
                from app.services.harness_sessions import (
                    purge_expired_harness_sessions,
                )

                report = await purge_expired_harness_sessions(
                    retention_days=settings.INTEGRAL_HARNESS_SESSION_RETENTION_DAYS
                )
                log.info(
                    "Harness session retention: sessions_deleted=%s records_deleted=%s",
                    report["sessions_deleted"],
                    report["records_deleted"],
                )
                input_report = await purge_expired_turn_input_capsules(
                    retention_days=settings.INTEGRAL_HARNESS_SESSION_RETENTION_DAYS
                )
                log.info(
                    "Harness turn input retention: capsules_deleted=%s "
                    "active_work_skipped=%s",
                    input_report["capsules_deleted"],
                    input_report["active_work_skipped"],
                )
            except Exception:  # noqa: BLE001
                log.exception("Harness session retention pass failed")
            next_harness_retention = time.monotonic() + 6 * 60 * 60

        await asyncio.sleep(idle_sleep)


async def start_work_kernel_background(
    background_tasks: List[asyncio.Task],
) -> None:
    """Probe store, reconcile once, then spawn worker/recovery/event loops."""
    await assert_work_kernel_store_posture()
    try:
        from app.agentive.services.work_outbox import reconcile_missing_outbox_facts
        from app.services.app_operations.event_outbox import (
            deliver_pending_cleanup_events,
        )
        from app.services.resident_assignment_execution import (
            deliver_resident_assignment_approvals,
        )

        await reconcile_missing_outbox_facts()
        await deliver_pending_cleanup_events()
        await deliver_resident_assignment_approvals()
    except Exception:  # noqa: BLE001
        if not _is_dev_boot():
            raise
        log.warning("work outbox reconcile skipped", exc_info=True)

    try:
        report = await run_startup_recovery()
        log.info(
            "work kernel startup recovery: expired=%s reclaimed=%s "
            "retry_waited=%s terminalized=%s outbox_backfilled=%s",
            report.expired,
            report.reclaimed,
            report.retry_waited,
            report.terminalized,
            report.outbox_backfilled,
        )
    except Exception:  # noqa: BLE001
        if not _is_dev_boot():
            raise
        log.warning("work kernel startup recovery failed", exc_info=True)

    from app.agentive.services import work_worker

    background_tasks.append(
        asyncio.create_task(
            work_worker.worker_loop(
                worker_id="work-worker-0",
                exclude_kinds=work_worker.APP_JOB_KINDS | frozenset({"chat_turn"}),
            ),
            name="work-worker",
        )
    )
    from app.config import settings

    for index in range(settings.INTEGRAL_CHAT_WORKERS):
        background_tasks.append(
            asyncio.create_task(
                work_worker.worker_loop(
                    worker_id=f"chat-worker-{index}",
                    kinds=frozenset({"chat_turn"}),
                ),
                name=f"chat-worker-{index}",
            )
        )
    # App jobs can run for minutes; their own worker keeps chat turns and
    # lifecycle work from queueing behind them.
    background_tasks.append(
        asyncio.create_task(
            work_worker.worker_loop(
                worker_id="work-worker-apps", kinds=work_worker.APP_JOB_KINDS
            ),
            name="work-worker-apps",
        )
    )
    background_tasks.append(asyncio.create_task(_recovery_loop(), name="work-recovery"))
    background_tasks.append(
        asyncio.create_task(_app_schedule_loop(), name="app-schedules")
    )


__all__ = [
    "WorkKernelBootError",
    "assert_work_kernel_store_posture",
    "probe_transaction_capabilities",
    "run_startup_recovery",
    "start_work_kernel_background",
]
