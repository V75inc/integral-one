"""Durable coordination facts under I-GRAPH-02, owned by the work kernel."""

from typing import Any, Literal

from jvspatial.core import Object
from pydantic import Field

from app.models.indexing import attribute


class WorkBudgetReservation(Object):
    reservation_id: str = attribute(default="", indexed=True)
    root_work_item_id: str = attribute(default="", indexed=True)
    work_item_id: str = ""
    principal_id: str = ""
    workspace_id: str = ""
    thread_id: str = ""
    review_digest: str = ""
    request_fingerprint: str = ""
    request: dict[str, Any] = Field(default_factory=dict)
    status: Literal["reserved", "settled", "overrun", "released"] = "reserved"
    # Missing fields in old records mean unknown dispatch history, never proof
    # that a provider was not called.
    dispatch_state: Literal[
        "legacy_untracked",
        "not_started",
        "intent",
        "unknown",
        "completed",
        "not_dispatched",
    ] = "legacy_untracked"
    # Missing attribution in legacy marked holds is not exact model proof.
    model_dispatch_scope: dict[str, str] = Field(default_factory=dict)
    model_dispatch_attempt: int = Field(default=0, ge=0)
    dispatch_ref: str = ""
    dispatched_at: str = ""
    outcome_ref: str = ""
    upper_units: int = Field(default=0, ge=0)
    charged_units: int = Field(default=0, ge=0)
    receipt_ref: str = ""
    created_at: str = ""
    settled_at: str = ""
