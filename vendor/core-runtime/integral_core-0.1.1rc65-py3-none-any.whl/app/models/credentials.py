"""Per-user model credential storage (I-GRAPH-02 Object, not Node)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from jvspatial.core import Object
from pydantic import Field

from app.models.indexing import attribute, compound_index


@compound_index(
    [("user_id", 1)],
    name="user_model_cred_user_id",
    unique=True,
    partial_filter_expression={
        "entity": "UserModelCredential",
        "context.user_id": {"$gt": ""},
    },
)
class UserModelCredential(Object):
    """Encrypted BYOK model provider credential for one Integral user."""

    user_id: str = attribute(default="", indexed=True)
    provider: str = attribute(default="", indexed=True)  # default slot
    model: str = attribute(default="")
    # Custom OpenAI-compatible base URL (plaintext, not a secret). Only set
    # when ``provider == "custom_openai"``; passed as LiteLLM ``api_base``.
    base_url: str = attribute(default="")
    generation_settings: Dict[str, Any] = Field(default_factory=dict)
    active_profile_id: str = ""
    routing_mode: str = "single"
    light_profile_id: str = ""
    # Speech-to-text (voice input) slot. Opt-in: empty ``speech_model`` = off.
    speech_provider: str = attribute(default="")
    speech_model: str = attribute(default="")
    api_key_enc: str = attribute(default="")
    key_fingerprint: str = attribute(default="")
    speech_api_key_enc: str = attribute(default="")
    speech_key_fingerprint: str = attribute(default="")
    is_active: bool = attribute(default=True)
    validated_at: Optional[str] = attribute(default=None)
    last_used_at: Optional[str] = attribute(default=None)
    created_at: Optional[str] = attribute(default=None)
    updated_at: Optional[str] = attribute(default=None)


class UserModelConnection(Object):
    """Scalar-keyed private provider connection; never a graph participant."""

    user_id: str = attribute(default="", indexed=True)
    name: str = ""
    provider: str = ""
    base_url: str = ""
    api_key_enc: str = ""
    key_fingerprint: str = ""
    validated_at: str = ""
    last_test_ok: Optional[bool] = None
    last_tested_at: str = ""
    updated_at: str = ""


class UserModelProfile(Object):
    """Private model configuration referencing a same-user connection."""

    user_id: str = attribute(default="", indexed=True)
    connection_id: str = ""
    name: str = ""
    model: str = ""
    generation_settings: Dict[str, Any] = Field(default_factory=dict)
    updated_at: str = ""
