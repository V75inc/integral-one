"""Library and attached OperationalModel APIs.

Includes library package management (list/get/publish/update/deprecate/validate)
and attached-profile customization, detach/revert, and derivation endpoints.
"""

import asyncio
import base64
from typing import Any, Dict, List, Optional

from fastapi import Request
from jvspatial.api import endpoint
from pydantic import ValidationError

from app.api.errors import (
    BadRequestError,
    InsufficientPermissionsError,
    MissingAuthenticationError,
    ResourceNotFoundError,
)
from app.api.utils import export_node, resolve_principal_id
from app.api.validators_common import (
    compute_fold,
    non_empty_after_strip,
    validate_semver_ish,
)
from app.models.edges import CATALOGS, CONTAINS, HAS_OPERATIONAL_MODEL
from app.models.nodes import (
    OPERATIONAL_MODELS_REGISTRY_ID,
    App,
    Attachment,
    EntryType,
    OperationalModel,
    OperationalModels,
    Track,
)
from app.schemas.operational_models import (
    ImportOperationalModelOptions,
    ImportPreviewResponse,
    PackagePreviewItem,
)
from app.schemas.policy import Resource, Subject
from app.services.app_graph import (
    create_track_view,
    get_app_attached_operational_model,
    get_track_attached_operational_model,
)
from app.services.change_event import emit_change_event
from app.services.library_package_visibility import visible_library_model
from app.services.model_authority import admitted_model_draft, get_current_model
from app.services.operational_model_runtime import (
    compile_canonical_manifest,
    normalize_entry_type_form_schema,
    normalize_view_config,
    sync_attached_manifest,
)
from app.services.permissions import (
    can_publish_operational_models_under_workspace,
    get_user_node,
)
from app.services.policy_engine import evaluate as policy_evaluate
from app.services.resource_location import MANAGEMENT_APP_STATES
from app.services.view_scope import get_scoped_view, list_scoped_track_views
from app.utils.time import utc_now_iso


async def _require_workspace_scope(
    request: Request, user_id: str, workspace_id: Optional[str]
) -> None:
    """Bind a supplied request scope to a workspace-scoped model effect."""
    if request is None or request.headers.get("x-integral-scope") is None:
        return
    from app.services.request_scope import require_effect_target_scope

    await require_effect_target_scope(request, user_id, workspace_id)


async def _bind_create_workspace_scope(
    request: Request, user_id: str, workspace_id: Optional[str]
) -> Optional[str]:
    """Resolve a supplied scope for a workspace-private model creation."""
    from app.services.request_scope import resolve_create_workspace_id

    return await resolve_create_workspace_id(request, user_id, workspace_id)


async def _require_operational_model_scope(
    request: Request, user_id: str, cp: OperationalModel
) -> None:
    """Bind request scope to the Model's current complete named provenance."""
    from app.services.model_authority import resolve_model_authority

    authority = await resolve_model_authority(
        cp.id, allowed_app_states=MANAGEMENT_APP_STATES
    )
    if authority is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if authority.platform:
        if request is not None and request.headers.get("x-integral-scope") is not None:
            await _resolve_active_workspace_for_library_list(request, user_id)
        return
    await _require_workspace_scope(request, user_id, authority.workspace_id)


# These packages were merged/retired, but older development databases can
# still contain their library rows. Keep the rows recoverable for existing
# installs while preventing new UI or agent installs from selecting them.
_RETIRED_LIBRARY_SLUGS = frozenset({"payroll_filings", "guyana-payroll-hr"})
_RETIRED_LIBRARY_NAMES = frozenset({"Payroll Filings", "Guyana Payroll (HR-linked)"})


def _is_visible_library_profile(profile: OperationalModel) -> bool:
    metadata = getattr(profile, "metadata", None) or {}
    package = (getattr(profile, "manifest", None) or {}).get("package") or {}
    slug = str(metadata.get("slug") or package.get("name") or "").strip()
    name = str(getattr(profile, "name", "") or "").strip()
    return slug not in _RETIRED_LIBRARY_SLUGS and name not in _RETIRED_LIBRARY_NAMES


async def _resolve_active_workspace_for_library_list(
    request: Request, user_id: str
) -> Optional[str]:
    from app.services.request_scope import resolve_workspace_id_from_request

    return await resolve_workspace_id_from_request(request, user_id)


@endpoint(
    "/operational-models", methods=["GET"], auth=True, tags=["Operational Models"]
)
async def list_library_operational_models(
    request: Request,
    type_hint: Optional[str] = None,
) -> Dict[str, Any]:
    """List cataloged library content packages (Phase 6 MCP-04 — ``integral_list_models``).

    Optional ``type_hint`` ranks library packages by token-intersection score
    over ``package.name + package.description + cp.name``. Per
    locked-post-research §Q7 + §Q8, the helper is called inline (no MCP
    re-dispatch — Pitfall 6). Response gains ``_type_hint_matches`` (sorted
    descending) when ``type_hint`` is supplied.

    Workspace-private library packages (``workspace_id`` set) are visible only
    when the active request scope matches that workspace. Platform/seeded
    packages (no ``workspace_id``) remain visible in every workspace.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    active_ws = await _resolve_active_workspace_for_library_list(request, user_id)
    reg = await OperationalModels.get(OPERATIONAL_MODELS_REGISTRY_ID)
    if not reg:
        result: Dict[str, Any] = {"operational_models": [], "total": 0}
        if type_hint:
            result["_type_hint_matches"] = []
        return result
    packages, _next = await reg.nodes_page(
        edge=[CATALOGS],
        node=["OperationalModel"],
        limit=500,
    )
    lib_only = []
    for candidate in packages:
        current = await visible_library_model(candidate.id, active_ws, user_id=user_id)
        if current is not None and _is_visible_library_profile(current):
            lib_only.append(current)
    items = [await export_node(p) for p in lib_only]
    response: Dict[str, Any] = {"operational_models": items, "total": len(items)}
    if type_hint:
        response["_type_hint_matches"] = await resolve_type_hint(
            type_hint, workspace_id=active_ws, user_id=user_id
        )
    return response


@endpoint(
    "/operational-models/{operational_model_id}",
    methods=["GET"],
    auth=True,
    tags=["Operational Models"],
)
async def get_library_operational_model(
    request: Request, operational_model_id: str
) -> Dict[str, Any]:
    """Get a library package by id (must be cataloged as library)."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if not cp or not getattr(cp, "library_package", False):
        raise ResourceNotFoundError(message="Operational Model not found")
    active_ws = await _resolve_active_workspace_for_library_list(request, user_id)
    cp = await visible_library_model(operational_model_id, active_ws, user_id=user_id)
    if cp is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    await _require_operational_model_scope(request, user_id, cp)
    record = await export_node(cp)
    record["can_delete"] = await _resolve_cp_edit_permission(
        user_id=user_id,
        cp=cp,
        request=request,
        action="operational_model.delete",
        dry_run=True,
    )
    return {"operational_model": record}


@endpoint(
    "/workspaces/{workspace_id}/operational-models",
    methods=["GET"],
    auth=True,
    tags=["Operational Models"],
)
async def list_workspace_operational_models(
    request: Request,
    workspace_id: str,
) -> Dict[str, Any]:
    """List workspace-private library packages for one workspace."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    user = await get_user_node(user_id)
    if not user:
        raise InsufficientPermissionsError(message="Access denied")
    await _require_workspace_scope(request, user_id, workspace_id)
    if not await can_publish_operational_models_under_workspace(user_id, workspace_id):
        raise InsufficientPermissionsError(message="Access denied")
    cps = await OperationalModel.find(
        {"context.library_package": True, "context.workspace_id": workspace_id}
    )
    admitted = []
    for candidate in cps:
        current = await visible_library_model(
            candidate.id, workspace_id, user_id=user_id, include_drafts=True
        )
        if current is not None:
            admitted.append(current)
    return {
        "operational_models": [await export_node(cp) for cp in admitted],
        "total": len(admitted),
        "workspace_id": workspace_id,
    }


@endpoint(
    "/operational-models", methods=["POST"], auth=True, tags=["Operational Models"]
)
async def publish_operational_model(
    request: Request,
    name: str,
    description: str = "",
    version: Optional[str] = None,
    workspace_id: Optional[str] = None,
    manifest: Optional[Dict[str, Any]] = None,
    manifest_yaml: Optional[str] = None,
    scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Publish a new workspace-private library operational model package."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    if not workspace_id:
        raise BadRequestError(message="workspace_id is required for publishing")
    workspace_id = (
        await _bind_create_workspace_scope(request, user_id, workspace_id) or ""
    )
    if not await can_publish_operational_models_under_workspace(user_id, workspace_id):
        raise InsufficientPermissionsError(message="Access denied")
    safe_name = non_empty_after_strip(name, "name")
    if len(safe_name) > 120:
        raise BadRequestError(message="name must be 120 characters or fewer")
    name_fold = compute_fold(safe_name)
    safe_version = validate_semver_ish(version, allow_empty=True) or None
    canonical = await asyncio.to_thread(
        compile_canonical_manifest,
        manifest=manifest,
        manifest_yaml=manifest_yaml,
        scope_hint=scope,
    )
    from app.services.uniqueness import assert_unique

    await assert_unique(
        OperationalModel,
        {
            "context.library_package": True,
            "context.workspace_id": workspace_id,
            "context.name_fold": name_fold,
            "context.version": safe_version,
        },
        entity="operational_model",
        field_label="name+version",
        value=f"{safe_name} {safe_version or '(no version)'}",
        scope_label="in this workspace",
    )
    reg = await OperationalModels.get(OPERATIONAL_MODELS_REGISTRY_ID)
    if not reg:
        raise ResourceNotFoundError(message="Operational Models registry missing")
    now = utc_now_iso()
    from app.services.library_model_creation import create_private_library_model

    cp = await create_private_library_model(
        user_id=user_id,
        name=safe_name,
        name_fold=name_fold,
        description=description or "",
        version=safe_version,
        workspace_id=workspace_id,
        manifest=canonical,
        scope=str(canonical.get("scope") or ""),
        created_at=now,
        updated_at=now,
    )

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.create",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=None,
        after=await export_node(cp),
        scope=f"user:{user_id}",
    )

    return {
        "operational_model": await export_node(cp),
        "message": "Operational Model published",
    }


@endpoint(
    "/operational-models/{operational_model_id}",
    methods=["PUT"],
    auth=True,
    tags=["Operational Models"],
)
async def update_library_operational_model(
    request: Request,
    operational_model_id: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    version: Optional[str] = None,
    manifest: Optional[Dict[str, Any]] = None,
    manifest_yaml: Optional[str] = None,
    scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Update a workspace-private library package, or mutate a draft CP.

    Drafts (``status == "draft"``) are not library packages but go through
    this same endpoint so the PUT contract stays uniform. Permission is
    delegated to ``_resolve_cp_edit_permission`` against the draft's
    published parent.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if not cp:
        raise ResourceNotFoundError(message="Operational Model not found")

    if not cp.library_package and cp.status != "draft":
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    prior_snapshot = await export_node(cp)  # D-03 before-snapshot
    if name is not None:
        cp.name = name
    if description is not None:
        cp.description = description
    if version is not None:
        cp.version = version
    if manifest is not None or manifest_yaml is not None:
        canonical = await asyncio.to_thread(
            compile_canonical_manifest,
            manifest=manifest,
            manifest_yaml=manifest_yaml,
            scope_hint=scope,
        )
        cp.manifest = canonical
        cp.scope = str(canonical.get("scope") or cp.scope or "")
    cp.updated_at = utc_now_iso()
    await cp.save()

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_snapshot,
        after=await export_node(cp),
        scope=f"user:{user_id}",
    )

    return {
        "operational_model": await export_node(cp),
        "message": "Operational Model updated",
    }


@endpoint(
    "/operational-models/{operational_model_id}",
    methods=["DELETE"],
    auth=True,
    tags=["Operational Models"],
)
async def deprecate_library_operational_model(
    request: Request,
    operational_model_id: str,
) -> Dict[str, Any]:
    """Deprecate a library package by deleting it from the catalog."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if not cp or not getattr(cp, "library_package", False):
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(
        user_id=user_id, cp=cp, request=request, action="operational_model.delete"
    ):
        raise InsufficientPermissionsError(message="Access denied")
    if await cp.nodes(
        edge=[HAS_OPERATIONAL_MODEL], direction="in", node=["Track", "App"]
    ):
        raise BadRequestError(
            message="This model is attached by reference. Detach or copy it before deleting the library model."
        )
    prior_snapshot = await export_node(cp)  # D-03 before-snapshot
    await cp.delete()

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.delete",
        resource_type="OperationalModel",
        resource_id=operational_model_id,
        before=prior_snapshot,
        after=None,
        scope=f"user:{user_id}",
    )

    return {
        "message": "Operational Model deprecated",
        "operational_model_id": operational_model_id,
    }


@endpoint(
    "/operational-models/validate",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def validate_operational_model_manifest(
    request: Request,
    manifest: Optional[Dict[str, Any]] = None,
    manifest_yaml: Optional[str] = None,
    scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Validate and normalize canonical v1 manifest payloads for agent workflows."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    try:
        canonical = await asyncio.to_thread(
            compile_canonical_manifest,
            manifest=manifest,
            manifest_yaml=manifest_yaml,
            scope_hint=scope,
        )
    except BadRequestError as exc:
        return {
            "valid": False,
            "canonical_manifest": None,
            "issues": [{"code": "manifest_validation_error", "message": str(exc)}],
        }
    return {"valid": True, "canonical_manifest": canonical, "issues": []}


# ---------------------------------------------------------------------------
# In-Place Customization: attached-profile entry types
# ---------------------------------------------------------------------------


@endpoint(
    "/tracks/{track_id}/operational-model/entry-types",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def add_entry_type_to_track_profile(
    request: Request,
    track_id: str,
    name: str,
    icon: str = "document",
    form_schema: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Add an EntryType to the track-attached OperationalModel (updates manifest + creates node)."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    safe_name = (name or "").strip()
    if not safe_name:
        raise BadRequestError(message="name is required")
    name_fold = compute_fold(safe_name)
    from app.services.uniqueness import assert_unique

    await assert_unique(
        EntryType,
        {"context.track_id": track_id, "context.name_fold": name_fold},
        entity="entry_type",
        field_label="name",
        value=safe_name,
        scope_label="in this track",
    )

    now = utc_now_iso()
    entry_type = await EntryType.create(
        name=safe_name,
        name_fold=name_fold,
        icon=icon,
        form_schema=normalize_entry_type_form_schema(form_schema),
        track_id=track_id,
        is_template=False,
        created_at=now,
        updated_at=now,
    )
    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot for parent CP
    try:
        await cp.connect(entry_type, edge=CONTAINS, added_at=now)
    except Exception:
        try:
            await entry_type.delete()
        except Exception:
            pass
        raise
    await sync_attached_manifest(cp)

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"track:{track_id}",
    )

    return {
        "entry_type": await export_node(entry_type),
        "message": "Entry type added to profile",
    }


@endpoint(
    "/tracks/{track_id}/operational-model/entry-types/{entry_type_id}",
    methods=["DELETE"],
    auth=True,
    tags=["Operational Models"],
)
async def remove_entry_type_from_track_profile(
    request: Request,
    track_id: str,
    entry_type_id: str,
) -> Dict[str, Any]:
    """Remove an EntryType from the track-attached OperationalModel (updates manifest + deletes node)."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    et = await EntryType.get(entry_type_id)
    if not et or et.track_id != track_id:
        raise ResourceNotFoundError(message="Entry type not found in this track")

    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot
    await et.delete()
    await sync_attached_manifest(cp)

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"track:{track_id}",
    )

    return {
        "message": "Entry type removed from profile",
        "deleted_entry_type_id": entry_type_id,
    }


# ---------------------------------------------------------------------------
# In-Place Customization: attached-profile views
# ---------------------------------------------------------------------------


@endpoint(
    "/tracks/{track_id}/operational-model/views",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def add_view_to_track_profile(
    request: Request,
    track_id: str,
    name: str,
    type: str = "feed",
    view_type: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    is_default: bool = False,
) -> Dict[str, Any]:
    """Add a View to the track-attached OperationalModel (updates manifest + creates node)."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    resolved_type = view_type or type
    from app.views import operational_model_view_types as _vtr

    valid_types = set(_vtr.allowed_keys())
    if resolved_type not in valid_types:
        raise BadRequestError(
            message=f"type must be one of: {', '.join(sorted(valid_types))}"
        )

    from app.api.entries import _slugify_entry_type_key
    from app.services.app_graph import catalog_view_under_track

    now = utc_now_iso()
    normalized_config = normalize_view_config(resolved_type, config or {})

    default_entry_type_key = ""
    entry_types_on_track = await EntryType.find({"context.track_id": track_id})
    if entry_types_on_track:
        default_entry_type_key = _slugify_entry_type_key(
            str(getattr(entry_types_on_track[0], "name", "") or "")
        )

    if is_default:
        for v in await list_scoped_track_views(track.id):
            if v.is_default:
                v.is_default = False
                await v.save()

    view = await create_track_view(
        track,
        name=name,
        type=resolved_type,
        config=normalized_config,
        track_id=track_id,
        operational_model_id=cp.id,
        default_entry_type_key=default_entry_type_key,
        is_default=is_default,
        created_by=user_id,
        created_at=now,
        updated_at=now,
    )
    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot
    await catalog_view_under_track(track, view)
    await sync_attached_manifest(cp)

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"track:{track_id}",
    )

    return {
        "view": await export_node(view),
        "message": "View added to profile",
    }


@endpoint(
    "/tracks/{track_id}/operational-model/views/{view_id}",
    methods=["DELETE"],
    auth=True,
    tags=["Operational Models"],
)
async def remove_view_from_track_profile(
    request: Request,
    track_id: str,
    view_id: str,
) -> Dict[str, Any]:
    """Remove a View from the track-attached OperationalModel (updates manifest + deletes node)."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    view = await get_scoped_view(view_id, allowed_app_states=MANAGEMENT_APP_STATES)
    if view is None or view.track_id != track_id or view.operational_model_id != cp.id:
        raise ResourceNotFoundError(message="View not found in this track")

    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot
    await view.delete()
    await sync_attached_manifest(cp)

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"track:{track_id}",
    )

    return {
        "message": "View removed from profile",
        "deleted_view_id": view_id,
    }


# ---------------------------------------------------------------------------
# Profile Detach and Revert
# ---------------------------------------------------------------------------


@endpoint(
    "/tracks/{track_id}/operational-model/detach-library",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def detach_library_from_track_profile(
    request: Request,
    track_id: str,
) -> Dict[str, Any]:
    """Remove library provenance from a track-attached OperationalModel without removing materialized elements.

    Clears ``libraryMergeSourceId`` on the Track so that future re-merge checks
    won't reference the old library package.  The EntryType/Tag/View nodes that
    were materialized from the library merge remain in place.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    if not getattr(track, "library_merge_source_id", None):
        # No-op return — also emit so the audit log records the attempt with no diff.
        await emit_change_event(
            actor_kind="human",
            actor_id=user_id,
            action="operational_model.update",
            resource_type="Track",
            resource_id=track.id,
            before=await export_node(track),
            after=await export_node(track),
            scope=f"track:{track_id}",
        )
        return {
            "message": "Track has no library provenance to detach",
            "track_id": track_id,
        }

    prior_track_snapshot = await export_node(track)  # D-03 before-snapshot
    track.library_merge_source_id = None
    track.updated_at = utc_now_iso()
    await track.save()

    # Also clear provenance in the manifest's package section
    cp = await get_track_attached_operational_model(track)
    if cp and cp.manifest:
        manifest = dict(cp.manifest)
        pkg = dict(manifest.get("package", {}))
        pkg.pop("source_library_id", None)
        pkg.pop("source_library_name", None)
        manifest["package"] = pkg
        cp.manifest = manifest
        cp.updated_at = utc_now_iso()
        await cp.save()

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="Track",
        resource_id=track.id,
        before=prior_track_snapshot,
        after=await export_node(track),
        scope=f"track:{track_id}",
    )

    return {"message": "Library provenance detached", "track_id": track_id}


@endpoint(
    "/tracks/{track_id}/operational-model/revert-customizations",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def revert_track_profile_customizations(
    request: Request,
    track_id: str,
    force: bool = False,
) -> Dict[str, Any]:
    """Revert local customizations on a track-attached OperationalModel back to the last merged library state.

    This re-applies the library manifest from the ``libraryMergeSourceId``,
    removing any locally added EntryTypes, Tags, or Views that weren't in the
    original library merge. Requires that ``libraryMergeSourceId`` is still set
    on the Track.

    Plan 07-02 / I-LIB-05 reject-gate — when
    ``compute_entry_impact_for_attached`` reports any track with
    ``would_fail_validation > 0`` the endpoint raises ``BadRequestError``
    unless ``force=true`` is passed. Mirrors Phase 5
    ``migrations/reject_gate.detect_unhandled_breaks``.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)

    lib_id = getattr(track, "library_merge_source_id", None)
    if not lib_id:
        raise BadRequestError(
            message="Track has no library provenance — cannot revert customizations"
        )

    lib_cp = await get_current_model(lib_id)
    if not lib_cp or not getattr(lib_cp, "library_package", False):
        raise ResourceNotFoundError(
            message="Referenced library Operational Model not found"
        )

    # Remove all current materialized nodes under the attached operational model
    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    from app.services.library_dependencies import admitted_library_dependency_chain

    chain = await admitted_library_dependency_chain(
        lib_cp.id, track.workspace_id, user_id=user_id
    )
    lib_cp = chain[-1]

    # Plan 07-02 / I-LIB-05 reject-gate — consult Phase 5 impact helper BEFORE
    # the destructive re-apply. force=true is the only escape past a blocking
    # impact set (mirror of Phase 5 reject_gate.detect_unhandled_breaks).
    from app.services.operational_model_diff import compute_entry_impact_for_attached

    impacts = await compute_entry_impact_for_attached(
        cp=cp, candidate_manifest=lib_cp.manifest or {}
    )
    blocking = [i for i in impacts if int(i.get("would_fail_validation", 0)) > 0]
    if blocking and not force:
        raise BadRequestError(
            message=(
                "Revert would invalidate existing entries; pass force=true to "
                "proceed"
            ),
            details={"blocking_impacts": blocking},
        )

    # Delete current EntryTypes, Tags, and Views concurrently
    import asyncio

    from app.models.edges import Edge

    entry_types = await cp.nodes(edge=[CONTAINS], node=["EntryType"])
    tags = await cp.nodes(edge=[CONTAINS], node=["Tag"])
    vregs = await cp.nodes(edge=[Edge], node=["Views"])

    deletions = [et.delete() for et in entry_types]
    deletions.extend(tag.delete() for tag in tags)
    vreg_views = []
    for vreg in vregs or []:
        views = await vreg.nodes(edge=[CATALOGS], node=["View"])
        deletions.extend(v.delete() for v in views)
        vreg_views.append(vreg)

    if deletions:
        await asyncio.gather(*deletions)
    if vreg_views:
        await asyncio.gather(*(vr.delete() for vr in vreg_views))

    # Re-apply the library manifest
    from app.services.operational_model_merge import (
        merge_library_manifest_into_operational_model,
    )

    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot
    await merge_library_manifest_into_operational_model(
        lib_cp, cp, track, user_id=user_id
    )

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    # Plan 07-02 — switch to operational_model.update action + details.revert so
    # the audit log distinguishes revert from a fresh merge_library.
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"track:{track_id}",
        details={"revert": True, "force": bool(force), "impacts": impacts},
    )

    return {
        "message": "Customizations reverted to library state",
        "track_id": track_id,
        "library_operational_model_id": lib_id,
        "force": bool(force),
        "impacts": impacts,
    }


# ---------------------------------------------------------------------------
# Derive Library Profile from Track/App
# ---------------------------------------------------------------------------


@endpoint(
    "/operational-models/from-track/{track_id}",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def derive_library_profile_from_track(
    request: Request,
    track_id: str,
    name: Optional[str] = None,
    description: str = "",
    version: Optional[str] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Derive a new library OperationalModel from a Track's attached operational model.

    The attached operational model's manifest is used as the basis for the new library
    package.  This enables users to share their customizations back to the
    library.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")

    track = await Track.get(track_id)
    if not track:
        raise ResourceNotFoundError(message="Track not found")
    await _require_workspace_scope(request, user_id, track.workspace_id)
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.update",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    workspace_id = (
        await _bind_create_workspace_scope(request, user_id, workspace_id) or ""
    )

    cp = await get_track_attached_operational_model(track)
    if not cp:
        raise ResourceNotFoundError(message="Track has no attached operational model")

    await sync_attached_manifest(cp)

    manifest = dict(cp.manifest or {})
    manifest["scope"] = "track"

    # Plan 07-02 / I-LIB-03 — stamp package.provenance before persistence so the
    # derived library package records its source. Round-trip merge into a fresh
    # Track regenerates an equivalent manifest modulo this block. ROADMAP AC#2.
    from app.utils.time import utc_now_iso

    pkg = dict(manifest.get("package") or {})
    pkg["provenance"] = {
        "source": "track",
        "source_id": track_id,
        "derived_at": utc_now_iso(),
        "derived_by": user_id,
    }
    manifest["package"] = pkg

    now = utc_now_iso()
    derived_name = name or f"{track.title} Profile"
    from app.services.library_model_creation import create_private_library_model

    derived = await create_private_library_model(
        user_id=user_id,
        name=derived_name,
        description=description or f"Derived from track: {track.title}",
        version=version or "1.0.0",
        workspace_id=workspace_id,
        manifest=manifest,
        scope="platform" if not workspace_id else "organization",
        created_at=now,
        updated_at=now,
    )

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.create",
        resource_type="OperationalModel",
        resource_id=derived.id,
        before=None,
        after=await export_node(derived),
        scope=f"track:{track_id}",
    )

    return {
        "operational_model": await export_node(derived),
        "message": "Library profile derived from track",
        "source_track_id": track_id,
    }


@endpoint(
    "/operational-models/from-app/{app_id}",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def derive_library_profile_from_space(
    request: Request,
    app_id: str,
    name: Optional[str] = None,
    description: str = "",
    version: Optional[str] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Derive a new library OperationalModel from an App's attached operational model.

    The attached operational model's manifest is used as the basis for the new library
    package.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")

    app_node = await App.get(app_id)
    if not app_node:
        raise ResourceNotFoundError(message="App not found")
    await _require_workspace_scope(request, user_id, app_node.workspace_id)
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="app.update",
        resource=Resource(kind="app", id=app_id, scope=f"app:{app_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")
    workspace_id = str(getattr(app_node, "workspace_id", "") or "")
    if not workspace_id or not await can_publish_operational_models_under_workspace(
        user_id, workspace_id
    ):
        raise InsufficientPermissionsError(
            message="You cannot save templates in this workspace"
        )

    cp = await get_app_attached_operational_model(app_node)
    if not cp:
        raise ResourceNotFoundError(message="App has no attached operational model")

    await sync_attached_manifest(cp)

    manifest = dict(cp.manifest or {})
    manifest["scope"] = "app"

    # A derived App template must contain the App's actual structure and
    # content. The attached Operational Model only describes the schema; it
    # does not contain the live Tracks or Entries. Snapshot those into the
    # existing declarative app.tracks/app.seeds install contract.
    from app.models.edges import HAS_ATTACHMENT
    from app.services.attachment_storage import get_attachment_storage_service
    from app.services.operational_model_runtime import slug_manifest_key

    app_section = dict(manifest.get("app") or {})
    track_specs = list(app_section.get("tracks") or [])
    seed_groups = list(app_section.get("seeds") or [])
    track_spec_by_key = {
        str(item.get("key") or "").casefold(): item
        for item in track_specs
        if isinstance(item, dict) and item.get("key")
    }
    storage = get_attachment_storage_service()
    total_attachment_bytes = 0
    max_snapshot_bytes = 25 * 1024 * 1024
    tracks = await app_node.nodes(edge=[CONTAINS], node=["Track"])
    for source_track in tracks:
        key = str(getattr(source_track, "template_id", None) or "").strip()
        key = key or slug_manifest_key(source_track.title) or str(source_track.id)
        track_cp = await get_track_attached_operational_model(source_track)
        track_manifest = dict(getattr(track_cp, "manifest", None) or {})
        track_definition = dict(track_manifest.get("track") or {})
        spec = dict(track_spec_by_key.get(key.casefold()) or {})
        spec.update(
            {
                "key": key,
                "name": source_track.title,
                "description": source_track.purpose or spec.get("description", ""),
                "provision_on_create": True,
            }
        )
        for field in ("entry_types", "views", "taxonomy", "defaults", "skills"):
            if field in track_definition:
                spec[field] = track_definition[field]
        if not any(
            str(item.get("key") or "").casefold() == key.casefold()
            for item in track_specs
            if isinstance(item, dict)
        ):
            track_specs.append(spec)
        else:
            track_specs = [
                (
                    spec
                    if isinstance(item, dict)
                    and str(item.get("key") or "").casefold() == key.casefold()
                    else item
                )
                for item in track_specs
            ]

        entries = await source_track.nodes(edge=[CONTAINS], node=["Entry"])
        seed_entries: List[Dict[str, Any]] = []
        for source_entry in entries:
            entry_type = (
                await EntryType.get(source_entry.type_id)
                if source_entry.type_id
                else None
            )
            seed_entry: Dict[str, Any] = {
                "id": f"saved-{source_entry.id}",
                "title": source_entry.title,
                "body": source_entry.body,
                "tags": list(source_entry.tags or []),
                "custom_fields": dict(source_entry.custom_fields or {}),
            }
            if entry_type is not None:
                seed_entry["entry_type"] = entry_type.name
            portable_attachments: List[Dict[str, Any]] = []
            for attachment in await source_entry.nodes(
                edge=[HAS_ATTACHMENT], direction="out"
            ):
                if (
                    not isinstance(attachment, Attachment)
                    or getattr(attachment, "scan_status", "") == "blocked"
                ):
                    continue
                item: Dict[str, Any] = {
                    "filename": attachment.filename,
                    "mime_type": attachment.mime_type,
                    "source_type": attachment.source_type,
                    "external_url": attachment.external_url,
                }
                if attachment.source_type == "file":
                    content = await storage.read_attachment(attachment.storage_key)
                    if content is None:
                        raise BadRequestError(
                            message=f"Could not read template attachment {attachment.filename!r}"
                        )
                    total_attachment_bytes += len(content)
                    if total_attachment_bytes > max_snapshot_bytes:
                        raise BadRequestError(
                            message="Template attachments exceed the 25 MiB portable-template limit"
                        )
                    item["content_base64"] = base64.b64encode(content).decode("ascii")
                elif attachment.source_type != "url":
                    continue
                portable_attachments.append(item)
            if portable_attachments:
                seed_entry["attachments"] = portable_attachments
            seed_entries.append(seed_entry)
        if seed_entries:
            seed_groups = [
                group
                for group in seed_groups
                if not (
                    isinstance(group, dict)
                    and str(group.get("track") or "").casefold() == key.casefold()
                )
            ]
            seed_groups.append({"track": key, "entries": seed_entries})
    app_section["tracks"] = track_specs
    app_section["seeds"] = seed_groups
    manifest["app"] = app_section

    # Plan 07-02 / I-LIB-03 — stamp package.provenance before persistence (mirror
    # of from-track block). ROADMAP AC#2.
    from app.utils.time import utc_now_iso

    derived_name = name or f"{app_node.name} Profile"
    pkg = dict(manifest.get("package") or {})
    # A saved copy is its own installable package. Reusing the source
    # package slug makes Manage Apps treat the template as already installed
    # and can cause unrelated derived templates to collide.
    pkg["name"] = f"{slug_manifest_key(derived_name)}-{app_id[-8:]}"
    pkg["provenance"] = {
        "source": "app",
        "source_id": app_id,
        "derived_at": utc_now_iso(),
        "derived_by": user_id,
    }
    manifest["package"] = pkg

    now = utc_now_iso()
    from app.services.library_model_creation import create_private_library_model

    derived = await create_private_library_model(
        user_id=user_id,
        name=derived_name,
        description=description or f"Derived from App: {app_node.name}",
        version=version or "1.0.0",
        workspace_id=workspace_id,
        manifest=manifest,
        scope="platform" if not workspace_id else "organization",
        created_at=now,
        updated_at=now,
    )

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.create",
        resource_type="OperationalModel",
        resource_id=derived.id,
        before=None,
        after=await export_node(derived),
        scope=f"app:{app_id}",
    )

    return {
        "operational_model": await export_node(derived),
        "message": "Library profile derived from app",
        "source_app_id": app_id,
    }


# ---------------------------------------------------------------------------
# App-attached Profile Detach and Revert (Plan 07-02, LIB-03)
# ---------------------------------------------------------------------------
#
# Mirror of the track-side handlers at L665-842 for App-attached
# OperationalModels. Per Phase 7 CONTEXT post-research lock #12, BOTH
# endpoints are NON-CASCADING: they only mutate the App's directly-
# attached OperationalModel and the App.library_merge_source_id field.
# Track-template OperationalModel rows reachable via the DEFINES_TRACK_PROFILE
# edge from the App-attached CP survive untouched (I-LIB-04).
#
# Authorization: both gates on the existing ``app_node.update`` PolicyAction
# (mirrors the track-side ``track.update`` gate). ZERO new PolicyAction
# literals are added by Plan 07-02 (CONTEXT lock #1 + #14).


@endpoint(
    "/apps/{app_id}/operational-model/detach-library",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def detach_library_from_space_profile(
    request: Request,
    app_id: str,
) -> Dict[str, Any]:
    """Remove library provenance from an App-attached OperationalModel.

    Drops ``library_merge_source_id`` on the App and clears
    ``manifest.package.source_library_{id,name}`` on the attached
    OperationalModel while preserving every materialized EntryType / Tag /
    View / track-template OperationalModel (I-LIB-04, non-cascading).

    Idempotent: an App with no prior library merge returns 200 with a
    "no library provenance" message (matches track-side L709-711).
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="app.update",
        resource=Resource(kind="app", id=app_id, scope=f"app:{app_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    app_node = await App.get(app_id)
    if not app_node:
        raise ResourceNotFoundError(message="App not found")
    await _require_workspace_scope(request, user_id, app_node.workspace_id)

    if not getattr(app_node, "library_merge_source_id", None):
        # No-op return — also emit so the audit log records the attempt with
        # no diff. Mirrors track-side L697-707.
        await emit_change_event(
            actor_kind="human",
            actor_id=user_id,
            action="operational_model.update",
            resource_type="App",
            resource_id=app_node.id,
            before=await export_node(app_node),
            after=await export_node(app_node),
            scope=f"app:{app_id}",
        )
        return {
            "message": "App has no library provenance to detach",
            "app_id": app_id,
        }

    prior_space_snapshot = await export_node(app_node)  # D-03 before-snapshot
    app_node.library_merge_source_id = None
    app_node.updated_at = utc_now_iso()
    await app_node.save()

    # Also clear provenance in the manifest's package section.
    cp = await get_app_attached_operational_model(app_node)
    if cp and cp.manifest:
        manifest = dict(cp.manifest)
        pkg = dict(manifest.get("package", {}))
        pkg.pop("source_library_id", None)
        pkg.pop("source_library_name", None)
        manifest["package"] = pkg
        cp.manifest = manifest
        cp.updated_at = utc_now_iso()
        await cp.save()

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="App",
        resource_id=app_node.id,
        before=prior_space_snapshot,
        after=await export_node(app_node),
        scope=f"app:{app_id}",
    )

    return {"message": "Library provenance detached", "app_id": app_id}


@endpoint(
    "/apps/{app_id}/operational-model/revert-customizations",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def revert_space_profile_customizations(
    request: Request,
    app_id: str,
    force: bool = False,
) -> Dict[str, Any]:
    """Revert local customizations on an App-attached OperationalModel.

    Re-applies the library manifest from ``library_merge_source_id``,
    removing locally added EntryTypes/Tags/Views that weren't part of the
    original library merge. Per I-LIB-04 the revert is NON-CASCADING:
    track-template OperationalModel rows reachable from the App CP via
    ``DEFINES_TRACK_PROFILE`` are PRESERVED. Child Tracks created from
    those templates keep their independent track-attached operational models.

    I-LIB-05 reject-gate: when ``compute_entry_impact_for_attached`` reports
    any track with ``would_fail_validation > 0`` the endpoint raises
    ``BadRequestError`` unless ``force=true`` is passed. Mirrors the Phase 5
    ``migrations/reject_gate.detect_unhandled_breaks`` pattern.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    _decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="app.update",
        resource=Resource(kind="app", id=app_id, scope=f"app:{app_id}"),
    )
    if not _decision.allowed:
        raise InsufficientPermissionsError(message="Access denied")

    app_node = await App.get(app_id)
    if not app_node:
        raise ResourceNotFoundError(message="App not found")
    await _require_workspace_scope(request, user_id, app_node.workspace_id)

    lib_id = getattr(app_node, "library_merge_source_id", None)
    if not lib_id:
        raise BadRequestError(
            message=("App has no library provenance — cannot revert customizations")
        )

    lib_cp = await get_current_model(lib_id)
    if not lib_cp or not getattr(lib_cp, "library_package", False):
        raise ResourceNotFoundError(
            message="Referenced library Operational Model not found"
        )

    cp = await get_app_attached_operational_model(app_node)
    if not cp:
        raise ResourceNotFoundError(message="App has no attached operational model")

    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    from app.services.library_dependencies import admitted_library_dependency_chain

    chain = await admitted_library_dependency_chain(
        lib_cp.id, app_node.workspace_id, user_id=user_id
    )
    lib_cp = chain[-1]

    # I-LIB-05 reject-gate — consults the Phase 5 impact helper BEFORE the
    # destructive re-apply. Phase 5 force-flag escape hatch is the ONLY way
    # past a blocking impact set.
    from app.services.operational_model_diff import compute_entry_impact_for_attached

    impacts = await compute_entry_impact_for_attached(
        cp=cp, candidate_manifest=lib_cp.manifest or {}
    )
    blocking = [i for i in impacts if int(i.get("would_fail_validation", 0)) > 0]
    if blocking and not force:
        raise BadRequestError(
            message=(
                "Revert would invalidate existing entries; pass force=true to "
                "proceed"
            ),
            details={"blocking_impacts": blocking},
        )

    # Delete current EntryTypes, Tags, and Views under the App-attached CP.
    # I-LIB-04 — we do NOT touch DEFINES_TRACK_PROFILE edges / track-template
    # CPs. Only the materialized track-tier nodes hanging off the App CP
    # are reset.
    import asyncio

    from app.models.edges import Edge

    entry_types = await cp.nodes(edge=[CONTAINS], node=["EntryType"])
    tags = await cp.nodes(edge=[CONTAINS], node=["Tag"])
    vregs = await cp.nodes(edge=[Edge], node=["Views"])

    deletions = [et.delete() for et in entry_types]
    deletions.extend(tag.delete() for tag in tags)
    vreg_views = []
    for vreg in vregs or []:
        views = await vreg.nodes(edge=[CATALOGS], node=["View"])
        deletions.extend(v.delete() for v in views)
        vreg_views.append(vreg)

    if deletions:
        await asyncio.gather(*deletions)
    if vreg_views:
        await asyncio.gather(*(vr.delete() for vr in vreg_views))

    # Re-apply the library manifest (for_space=True path).
    from app.services.operational_model_merge import (
        merge_library_manifest_into_operational_model,
    )

    prior_cp_snapshot = await export_node(cp)  # D-03 before-snapshot
    await merge_library_manifest_into_operational_model(
        lib_cp, cp, track=None, for_space=True, user_id=user_id
    )

    # D-05 single emission path. Sync inline emit before HTTP response (D-06).
    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.update",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=prior_cp_snapshot,
        after=await export_node(cp),
        scope=f"app:{app_id}",
        details={"revert": True, "force": bool(force), "impacts": impacts},
    )

    return {
        "message": "Customizations reverted to library state",
        "app_id": app_id,
        "library_operational_model_id": lib_id,
        "force": bool(force),
        "impacts": impacts,
    }


# ---------------------------------------------------------------------------
# Draft / publish / diff / discard / substrate (Pillars 2 + 3)
# ---------------------------------------------------------------------------


async def _resolve_cp_edit_permission(
    *,
    user_id: str,
    cp: OperationalModel,
    request: Optional[Request] = None,
    action: str = "operational_model.update",
    dry_run: bool = False,
) -> bool:
    """Require configuration rights on the exact Model and every affected parent."""
    from app.middleware.permissions_cache import isolated_permissions_cache

    if request is not None:
        await _require_operational_model_scope(request, user_id, cp)
    with isolated_permissions_cache():
        return (
            await policy_evaluate(
                subject=Subject(kind="human", id=user_id),
                action=action,
                _dry_run=dry_run,
                resource=Resource(
                    kind="operational_model",
                    id=cp.id,
                    scope=f"operational_model:{cp.id}",
                ),
            )
        ).allowed


@endpoint(
    "/operational-models/{operational_model_id}/migration-status",
    methods=["GET"],
    auth=True,
    tags=["Operational Models"],
)
async def get_operational_model_migration_status(
    request: Request,
    operational_model_id: str,
) -> Dict[str, Any]:
    """Return durable migration progress and failed-record diagnostics."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if cp is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    from app.services.migrations.runner import migration_status_snapshot

    return await migration_status_snapshot(cp)


@endpoint(
    "/operational-models/{operational_model_id}/retry-migration",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def retry_operational_model_migration(
    request: Request,
    operational_model_id: str,
) -> Dict[str, Any]:
    """Retry a restart-interrupted or failed declarative migration.

    The migration DSL operations are idempotent by contract, so retry always
    reuses the one canonical runner rather than creating a special recovery
    executor.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if cp is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    current_status = str(getattr(cp, "migration_status", "complete") or "complete")
    if current_status == "in_progress":
        raise BadRequestError(message="Migration is already in progress")
    if current_status != "failed":
        raise BadRequestError(
            message="Only a failed migration can be retried",
            details={"migration_status": current_status},
        )
    manifest = await asyncio.to_thread(
        compile_canonical_manifest, manifest=dict(cp.manifest or {})
    )
    declared_ops = [
        op
        for migration in list(manifest.get("migrations") or [])
        for op in list((migration or {}).get("ops") or [])
        if isinstance(op, dict) and op.get("op")
    ]
    if not declared_ops:
        raise BadRequestError(
            message="Operational Model declares no migration operations"
        )
    from app.agentive.work_models import WorkItem
    from app.services.migrations.runner import (
        _manifest_fingerprint,
        run_migration_async,
    )

    # Keep terminal work immutable for auditability.  A recovery item names
    # the latest matching failed attempt as its parent, so it has a fresh
    # idempotency identity and can be claimed by the worker.
    fingerprint = _manifest_fingerprint(manifest)
    failed_attempts = [
        item
        for item in await WorkItem.find({"context.kind": "migration"})
        if str(
            (getattr(item, "input_payload", None) or {}).get("operational_model_id")
            or ""
        )
        == cp.id
        and str(
            (getattr(item, "input_payload", None) or {}).get("manifest_fingerprint")
            or ""
        )
        == fingerprint
        and str(getattr(item, "status", "") or "") == "failed"
    ]
    latest_failed_attempt = max(
        failed_attempts,
        key=lambda item: str(getattr(item, "updated_at", "") or ""),
        default=None,
    )

    tracker = await run_migration_async(
        published_cp=cp,
        compiled_manifest=manifest,
        actor_id=user_id,
        # Empty sentinel distinguishes legacy failures from a standard
        # publication enqueue, whose idempotency key must remain stable.
        retry_of_work_item_id=(
            str(getattr(latest_failed_attempt, "work_item_id", "") or "")
            if latest_failed_attempt is not None
            else ""
        ),
    )
    return {"retried": True, "migration_tracker": {"executed": True, **tracker}}


@endpoint(
    "/operational-models/{operational_model_id}/draft",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def fork_operational_model_draft(
    request: Request,
    operational_model_id: str,
) -> Dict[str, Any]:
    """Fork a draft from a published OperationalModel."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    cp = await get_current_model(operational_model_id)
    if cp is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")
    from app.services.operational_model_atomic_swap import fork_draft

    draft = await admitted_model_draft(
        user_id, cp.id, action="operational_model.update"
    )
    if draft is None:
        draft = await fork_draft(published=cp, actor_id=user_id)
    return {
        "draft": await export_node(draft),
        "from_id": cp.id,
    }


@endpoint(
    "/operational-models/{operational_model_id}/publish",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def publish_operational_model_draft(
    request: Request,
    operational_model_id: str,
    run_migrations: bool = True,
    abort_on_migration_failure: bool = True,
    force: bool = False,
) -> Dict[str, Any]:
    """Publish a draft, swapping its manifest onto the published parent.

    Phase 5 Plan 05-02:
      - ``force=true`` query param bypasses the no-migration-path reject
        gate. Forced publishes do NOT migrate existing entries — they
        remain on the prior schema until manually fixed. Documented
        destructive escape (I-MIG-03).
      - Policy gate evaluates ``migration.publish`` (default) or
        ``migration.force_publish`` (when ``force=true``) so a Policy can
        allow normal publish but DENY force (security hardening per
        STRIDE Tampering threat T-05-02-01).
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    draft = await get_current_model(operational_model_id)
    if draft is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if draft.status != "draft":
        raise BadRequestError(message="Only draft CPs can be published")
    if not draft.draft_of_id:
        if not await _resolve_cp_edit_permission(
            user_id=user_id, cp=draft, request=request
        ):
            raise InsufficientPermissionsError(message="Access denied")
        if force:
            raise BadRequestError(
                message="Initial library publication does not use forced migration"
            )
        from app.services.library_model_publication import publish_initial_library_draft

        return await publish_initial_library_draft(model_id=draft.id, user_id=user_id)
    parent = await get_current_model(draft.draft_of_id)
    if parent is None:
        raise BadRequestError(message="Draft's published parent has been deleted")
    if not await _resolve_cp_edit_permission(
        user_id=user_id, cp=draft, request=request
    ):
        raise InsufficientPermissionsError(message="Access denied")

    # Phase 5 Plan 05-02 — policy gate (separate actions for normal vs force).
    # ``migration.publish`` / ``migration.force_publish`` are added to
    # PolicyAction by Plan 05-01 (Wave 1 sibling). Until 05-01 merges,
    # ``evaluate`` accepts arbitrary action strings — no runtime breakage.
    action_str = "migration.force_publish" if force else "migration.publish"
    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action=action_str,  # type: ignore[arg-type]
        resource=Resource(
            kind="operational_model",
            id=operational_model_id,
            scope=f"operational_model:{operational_model_id}",
        ),
    )
    if not decision.allowed:
        raise InsufficientPermissionsError(message=f"Policy denied {action_str}")

    from app.services.operational_model_atomic_swap import publish_draft

    result = await publish_draft(
        draft=draft,
        published=parent,
        actor_id=user_id,
        run_migrations=run_migrations,
        abort_on_migration_failure=abort_on_migration_failure,
        force=force,
    )
    return result


@endpoint(
    "/operational-models/{operational_model_id}/diff",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def diff_operational_model(
    request: Request,
    operational_model_id: str,
    against: Optional[str] = None,
    include_entry_impact: bool = True,
    sample_limit: int = 20,
) -> Dict[str, Any]:
    """Structural diff + optional entry-impact for a candidate CP.

    ``against`` defaults to ``"published"`` and resolves to the draft's
    ``draft_of_id`` parent. Pass another CP id to diff arbitrary pairs.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    candidate = await get_current_model(operational_model_id)
    if candidate is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(
        user_id=user_id, cp=candidate, request=request
    ):
        # Drafts also need edit permission on their published parent.
        if candidate.draft_of_id:
            parent = await get_current_model(candidate.draft_of_id)
            if parent is None or not await _resolve_cp_edit_permission(
                user_id=user_id, cp=parent, request=request
            ):
                raise InsufficientPermissionsError(message="Access denied")
        else:
            raise InsufficientPermissionsError(message="Access denied")

    against_id: Optional[str]
    if against in (None, "", "published"):
        against_id = candidate.draft_of_id or candidate.published_id
    else:
        against_id = against
    if not against_id:
        raise BadRequestError(
            message="No reference CP to diff against (provide ?against=<id>)"
        )
    reference = await get_current_model(against_id)
    if reference is None:
        raise ResourceNotFoundError(message="Reference operational model not found")

    await _require_operational_model_scope(request, user_id, reference)
    from app.services.model_authority import model_action_authorized

    if not await model_action_authorized(
        user_id,
        "operational_model.read",
        Resource(
            kind="operational_model",
            id=reference.id,
            scope=f"operational_model:{reference.id}",
        ),
    ):
        raise ResourceNotFoundError(message="Reference operational model not found")
    if include_entry_impact and not await _resolve_cp_edit_permission(
        user_id=user_id, cp=reference, request=request
    ):
        raise InsufficientPermissionsError(
            message="Configuration authority required for entry impact"
        )

    from app.services.operational_model_diff import compute_manifest_diff

    diff = compute_manifest_diff(
        before=reference.manifest or {},
        after=candidate.manifest or {},
    )
    payload: Dict[str, Any] = {
        "candidate_id": candidate.id,
        "reference_id": reference.id,
        "diff": diff,
    }
    if include_entry_impact:
        # Impact is measured against the published parent — that's the CP
        # actually attached to live tracks/apps.
        impact_target = reference if reference.status == "published" else candidate
        # NOTE: dotted attribute access (not ``from … import``) so monkeypatch
        # on ``app.services.operational_model_diff.compute_entry_impact_for_attached``
        # is honoured by tests that inject synthetic impact lists.
        from app.services import operational_model_diff as _cpd

        impacts = await _cpd.compute_entry_impact_for_attached(
            cp=impact_target,
            candidate_manifest=candidate.manifest or {},
            sample_limit=sample_limit,
        )
        payload["entry_impact"] = impacts

        # Phase 5 Plan 05-04 — MIG-04 payload extensions.
        # Top-level ``would_need_migration`` boolean rollup over the per-track
        # impact list (each impact carries an int count; True iff any > 0 or
        # any track has ``would_fail_validation > 0``). Top-level
        # ``unhandled_breaks`` plumbs the same Plan 05-02 reject_gate verdict
        # the publish endpoint would 422 on, so authors can preview-then-fix.
        payload["would_need_migration"] = any(
            int((i or {}).get("would_need_migration") or 0) > 0
            or int((i or {}).get("would_fail_validation") or 0) > 0
            for i in (impacts or [])
        )
        try:
            from app.services.migrations.reject_gate import detect_unhandled_breaks

            payload["unhandled_breaks"] = detect_unhandled_breaks(
                impacts=impacts,
                migrations=(candidate.manifest or {}).get("migrations") or [],
            )
        except ImportError:
            # Plan 05-02's reject_gate normally lands before 05-04. If the
            # module is somehow missing at import time the preview is still
            # useful for the structural diff + entry_impact list; surface an
            # empty break list and log so the gap is visible.
            import logging

            logging.getLogger(__name__).warning(
                "preview-update: app.services.migrations.reject_gate "
                "unavailable; unhandled_breaks defaulting to []"
            )
            payload["unhandled_breaks"] = []
    return payload


# Phase 5 Plan 05-04 — MIG-04 alias.
#
# ``POST /api/operational-models/{id}/preview-update`` is a thin wrapper that
# delegates to ``diff_operational_model`` (locked decision #3, CONTEXT
# <locked_post_research>). The jvspatial @endpoint decorator stores config
# on the target function (single ``_jvspatial_endpoint_config`` slot per
# callable), so decorator stacking is not supported — Option B (wrapper
# function) is the only viable path. The wrapper inherits auth gate, CP
# edit-permission gate, query-param contract, and the full payload
# (including the would_need_migration + unhandled_breaks extensions added
# above) via plain function delegation.
@endpoint(
    "/operational-models/{operational_model_id}/preview-update",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def preview_update_operational_model(
    request: Request,
    operational_model_id: str,
    against: Optional[str] = None,
    include_entry_impact: bool = True,
    sample_limit: int = 20,
) -> Dict[str, Any]:
    """MIG-04 — alias to ``diff_operational_model``.

    Returns the structural diff + entry_impact + would_need_migration +
    unhandled_breaks payload so authors can preview both the schema delta
    AND the publish-gate verdict before invoking ``/publish``.
    """
    return await diff_operational_model(
        request=request,
        operational_model_id=operational_model_id,
        against=against,
        include_entry_impact=include_entry_impact,
        sample_limit=sample_limit,
    )


@endpoint(
    "/operational-models/{operational_model_id}/discard-draft",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def discard_operational_model_draft(
    request: Request,
    operational_model_id: str,
) -> Dict[str, Any]:
    """Delete a draft without publishing."""
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    draft = await get_current_model(operational_model_id)
    if draft is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if draft.status != "draft":
        raise BadRequestError(message="Only drafts can be discarded")
    if not await _resolve_cp_edit_permission(
        user_id=user_id, cp=draft, request=request, action="operational_model.delete"
    ):
        raise InsufficientPermissionsError(message="Access denied")
    from app.services.operational_model_atomic_swap import discard_draft

    return await discard_draft(draft=draft, actor_id=user_id)


@endpoint(
    "/operational-model-substrate",
    methods=["GET"],
    auth=True,
    tags=["Operational Models"],
)
async def get_operational_model_substrate(request: Request) -> Dict[str, Any]:
    """Root introspection for the agent + frontend.

    Returns the full set of registered field types, view types (incl. meta-
    widgets), and any code plugins discovered at startup. The agent calls
    this first when authoring a profile so it can compose against what's
    actually installed.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    compact = str(getattr(request, "query_params", {}).get("compact") or "") in {
        "1",
        "true",
    }
    from app.services import operational_model_field_types as ftr
    from app.services.agent_profile_patches import supported_ops
    from app.services.operational_model_plugins import discovered_plugins
    from app.services.retrieval import semantic_retrieval_available
    from app.services.template_var_resolvers import get_registered_tokens
    from app.views import operational_model_view_types as vtr

    def _field_payload(spec: Any) -> Dict[str, Any]:
        return {
            "type": spec.type,
            "base": spec.base,
            "label": spec.label,
            "description": spec.description,
            "config_schema": spec.config_schema,
            "source": spec.source,
            "signed": spec.signed,
        }

    def _view_payload(spec: Any) -> Dict[str, Any]:
        return {
            "type": spec.type,
            "base": spec.base,
            "label": spec.label,
            "description": spec.description,
            "config_schema": spec.config_schema,
            "source": spec.source,
            "signed": spec.signed,
            "supported_platforms": list(getattr(spec, "supported_platforms", ["web"])),
            "default_always_on": bool(getattr(spec, "default_always_on", False)),
            "palette_group": str(getattr(spec, "palette_group", "general")),
            "configurable": bool(getattr(spec, "configurable", True)),
            "hot_loadable": bool(getattr(spec, "hot_loadable", False)),
        }

    # Live retrieval capability — lets the agent (and frontend) know up
    # front which search modes this deployment actually supports, so it can
    # phrase queries appropriately instead of discovering degradation only
    # after a ``mode=hybrid`` request returns ``degraded: true``.
    sem = semantic_retrieval_available()
    if compact:
        # The resident only needs the installed type names. Full config
        # schemas are what blew the first scaffold turn past the token budget.
        view_hints = {
            "table": ["columns"],
            "kanban": ["group_by", "kanban_columns"],
            "calendar": ["calendar_mapping.dateField"],
            "wiki": ["parent_field", "title_field", "body_field"],
        }
        return {
            "patch_operations": supported_ops(),
            "field_types": [
                {"type": spec.type, "label": spec.label} for spec in ftr.iter_specs()
            ],
            "view_types": [
                {
                    "type": spec.type,
                    "label": spec.label,
                    "config_keys": view_hints.get(spec.type, []),
                }
                for spec in vtr.iter_specs()
            ],
            "retrieval": {"semantic_available": sem},
        }

    return {
        "patch_operations": supported_ops(),
        "field_types": [_field_payload(s) for s in ftr.iter_specs()],
        "view_types": [_view_payload(s) for s in vtr.iter_specs()],
        "plugins": discovered_plugins(),
        "registry_versions": {
            "field_types": ftr.registry_version(),
            "view_types": vtr.registry_version(),
        },
        # Phase 3.1 Plan 03.1-04 (ANC-07 + ANC-09) — resolver vocabulary
        # surfaced to non-agent introspection callers (frontend manifest UI,
        # docs tooling). Mirrors the same key in ``describe_substrate``.
        "template_var_resolvers": get_registered_tokens(),
        "retrieval": {
            "semantic_available": sem,
            "modes": (["lexical", "semantic", "hybrid"] if sem else ["lexical"]),
            "default_mode": "hybrid",
            "note": (
                "Semantic concept search is active."
                if sem
                else "Semantic search is OFF (no vector store); queries fall "
                "back to keyword/graph matching — use concise keywords, not "
                "value rankings."
            ),
        },
    }


# ---------------------------------------------------------------------------
# Phase 6 Plan 06-04 — Profile-aware MCP tools (MCP-04)
#
# Three new tools, wired to locked names via MCP_TOOL_NAME_OVERRIDES at
# ``backend/app/agentive/tooling/name_overrides.py``:
#   - POST /api/operational-models/author          → integral_author_model
#   - POST /api/operational-models/{id}/modify     → integral_modify_model
#   - GET  /api/operational-models?type_hint=<str> → integral_list_models
#
# See I-PROFILE-01..02 in docs/INVARIANTS.md.
# ---------------------------------------------------------------------------


async def resolve_type_hint(
    hint: str, *, workspace_id: Optional[str] = None, user_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Resolve a free-text type_hint to ranked library packages.

    Per locked-post-research §Q7 + §Q8 (CONTEXT lock §"Locked: type_hint
    resolution"):

      * Tokenize ``hint`` on whitespace + hyphens (lowercased).
      * For each ``library_package=True`` OperationalModel, build a haystack
        from ``package.name + package.description + cp.name``; tokenize it
        the same way.
      * ``score = len(hint_tokens & haystack_tokens) / len(hint_tokens)``.
      * Filter out score==0; sort descending.

    When ``workspace_id`` is supplied, workspace-private packages belonging
    to other workspaces are excluded (same rule as ``GET /operational-models``).

    Caller is responsible for the disambiguation policy (zero-match warning,
    single best-match adoption, tied-top-score 400). Pitfall 6: this is a
    plain async helper — NOT a separate ``@endpoint`` — so callers
    (``list_library_operational_models`` + ``create_track`` + ``create_app``)
    invoke it directly without an MCP round-trip.
    """
    hint_tokens = {tok for tok in hint.lower().replace("-", " ").split() if tok}
    if not hint_tokens:
        return []
    raw = await OperationalModel.find({"context.library_package": True})
    if raw is None:
        rows: list = []
    elif isinstance(raw, (list, tuple)):
        rows = list(raw)
    else:
        rows = [raw]
    scored: List[Dict[str, Any]] = []
    for cp in rows:
        # Drafts are not "listable" via integral_list_models — they
        # surface only after explicit publish (preserves the draft/publish
        # lifecycle semantic gap documented in Test 1a).
        if getattr(cp, "status", "published") != "published":
            continue
        if not _is_visible_library_profile(cp):
            continue
        cp = await visible_library_model(cp.id, workspace_id, user_id=user_id)
        if cp is None:
            continue
        pkg = (cp.manifest or {}).get("package") or {}
        # Plan 07-01 / I-LIB-01 — include manifest.package.tags in the
        # haystack so MCP-04 keyword resolution catches domain terms
        # absent from the slug/description (e.g. 'zettelkasten' under a
        # personal knowledge-base profile). Tags are free-form domain
        # keywords — see I-LIB-02 for back-compat / no-frontend semantics.
        raw_tags = pkg.get("tags") or []
        tag_blob = " ".join(t for t in raw_tags if isinstance(t, str))
        haystack = (
            f"{pkg.get('name', '')} {pkg.get('description', '')} "
            f"{cp.name or ''} {tag_blob}"
        ).lower()
        haystack_tokens = {tok for tok in haystack.replace("-", " ").split() if tok}
        overlap = hint_tokens & haystack_tokens
        if not overlap:
            continue
        score = len(overlap) / max(len(hint_tokens), 1)
        scored.append(
            {
                "operational_model_id": cp.id,
                "name": cp.name,
                "score": score,
                "package_name": pkg.get("name", ""),
            }
        )
    scored.sort(key=lambda x: -x["score"])
    return scored


@endpoint(
    "/operational-models/author",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def author_operational_model(
    request: Request,
    description: str = "",
    target_scope: str = "track",
    workspace_id: str = "",
    fields: Optional[List[Dict[str, Any]]] = None,
    as_draft: bool = True,
) -> Dict[str, Any]:
    """integral_author_model (MCP-04 — Phase 6 Plan 06-04 AC#3).

    v1 deterministic NL → manifest template-fill. NO inline LLM call
    (CONTEXT lock; v2 swaps LLM in via the SAME handler signature).
    Authored profiles land in the library (``library_package=True``).

    Body:

      * ``description`` (str)         — natural-language hint; tokenized
                                        for 7-keyword library-match.
      * ``target_scope`` (str)        — ``"track"`` | ``"app"``.
      * ``workspace_id`` (str)        — EXPLICIT (locked-post-research #4);
                                        never derived from caller state.
      * ``fields`` (Optional[List])   — caller-supplied field payload merged
                                        into the matched package's first
                                        entry_type, or used as the entire
                                        schema for the fallback ``post`` ET.
      * ``as_draft`` (bool, default=True) — when True, the CP lands as a
                                        draft (not yet listable via
                                        ``integral_list_models``); when
                                        False, lands published.

    Two-tier gate (Pitfall 5):

      1. ``policy_engine.evaluate(action="operational_model.author", scope=workspace)``
      2. ``can_publish_operational_models_under_workspace(user_id, workspace_id)``

    Both must pass. Tier 1 differentiates agent vs human (default-human
    delegates to Tier 2; agent must have a Policy granting
    ``operational_model.author``).
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")

    if not description or not str(description).strip():
        raise BadRequestError(message="description is required")
    if target_scope not in ("track", "app"):
        raise BadRequestError(message="target_scope must be 'track' or 'app'")
    if not workspace_id:
        raise BadRequestError(
            message="workspace_id is required (no implicit derivation)"
        )
    workspace_id = (
        await _bind_create_workspace_scope(request, user_id, workspace_id) or ""
    )

    # Tier 1 — operational_model.author policy gate (agent vs human dispatch).
    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="operational_model.author",
        resource=Resource(
            kind="operational_model",
            id="*",
            scope=f"workspace:{workspace_id}",
        ),
    )
    if not decision.allowed:
        raise InsufficientPermissionsError(message="operational_model.author denied")

    # Tier 2 — existing workspace publish gate.
    if not await can_publish_operational_models_under_workspace(user_id, workspace_id):
        raise InsufficientPermissionsError(
            message="No publish rights under workspace",
        )

    from app.services.operational_model_author import (
        author_operational_model_from_template,
    )

    manifest = await author_operational_model_from_template(
        description=description,
        target_scope=target_scope,
        fields=fields,
    )

    # Persist as draft or published library package.
    cp_status = "draft" if as_draft else "published"
    now = utc_now_iso()
    name = (manifest.get("package") or {}).get("name") or "authored-profile"
    name_fold = compute_fold(name)
    from app.services.library_model_creation import create_private_library_model

    cp = await create_private_library_model(
        user_id=user_id,
        name=name,
        name_fold=name_fold,
        scope=target_scope,
        workspace_id=workspace_id,
        manifest=manifest,
        status=cp_status,
        published_at=now if cp_status == "published" else None,
        created_at=now,
        updated_at=now,
        description=(manifest.get("package") or {}).get("description", "") or "",
    )
    # Catalog under OperationalModels registry so list_library_operational_models
    # surfaces it (only when published — drafts stay invisible until
    # explicitly published via the publish endpoint).

    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.create",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=None,
        after=await export_node(cp),
        scope=f"workspace:{workspace_id}",
    )

    return {
        "operational_model_id": cp.id,
        "manifest": manifest,
        "status": cp_status,
    }


@endpoint(
    "/operational-models/{operational_model_id}/modify",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def modify_operational_model(
    request: Request,
    operational_model_id: str,
    operations: Optional[List[Dict[str, Any]]] = None,
    force: bool = False,
) -> Dict[str, Any]:
    """integral_modify_model (MCP-04 — Phase 6 Plan 06-04 AC#4).

    Routes through Phase 3.1 ``agent_profile_patches.apply_operations``
    (declarative DSL; no eval/exec — I-MIG-04 invariant) + Phase 3.1
    ``publish_draft(force=force)`` which fires the Phase 5 reject_gate
    automatically.

    ``force=true`` bypasses the reject_gate (destructive escape per
    Phase 5 I-MIG-03; the underlying ``migration.force_publish`` policy
    gate enforces authorization for forced publishes).

    Per locked-post-research #5 — both paths supported:

      * Library package: publish materializes new version, existing
        attached instances NOT auto-migrated (librarian path).
      * Attached instance (track/app scope): publish triggers Phase 5
        migration runtime over in-flight Entries.

    See I-PROFILE-02 in docs/INVARIANTS.md.
    """
    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    if not operations or not isinstance(operations, list):
        raise BadRequestError(message="operations must be a non-empty list")

    cp = await get_current_model(operational_model_id)
    if cp is None:
        raise ResourceNotFoundError(message="Operational Model not found")
    if not await _resolve_cp_edit_permission(user_id=user_id, cp=cp, request=request):
        raise InsufficientPermissionsError(message="Access denied")

    from app.services.agent_profile_patches import apply_operations
    from app.services.operational_model_atomic_swap import fork_draft, publish_draft

    # 1. Fork draft (Phase 3.1).
    draft = await fork_draft(published=cp, actor_id=user_id)

    # 2. Apply patch DSL (Phase 3.1).
    new_manifest = apply_operations(draft.manifest or {}, operations)
    draft.manifest = new_manifest
    await draft.save()

    # 3. Publish (Phase 3.1 + Phase 5 migration runner + reject_gate).
    result = await publish_draft(
        draft=draft,
        published=cp,
        actor_id=user_id,
        force=force,
    )
    return result


def _manifest_preview_stats(canonical: Dict[str, Any]) -> Dict[str, int]:
    """Extract entry_type_count, view_count, tag_count from a canonical manifest."""
    scope = str(canonical.get("scope") or "")
    if scope == "track":
        section = canonical.get("track") or {}
    elif scope == "app":
        section = canonical.get("app") or {}
    else:
        section = {}
    entry_type_count = len(section.get("entry_types") or [])
    view_count = len(section.get("views") or [])
    taxonomy = section.get("taxonomy") or {}
    tag_groups = taxonomy.get("tag_groups") or []
    tag_count = sum(
        len(grp.get("tags") or []) for grp in tag_groups if isinstance(grp, dict)
    )
    return {
        "entry_type_count": entry_type_count,
        "view_count": view_count,
        "tag_count": tag_count,
    }


def _build_package_preview_item(
    canonical: Dict[str, Any],
    validation_errors: Optional[List[str]] = None,
) -> "PackagePreviewItem":
    """Build a ``PackagePreviewItem`` from a compiled canonical manifest."""
    pkg = canonical.get("package") or {}
    package_name: str = str(pkg.get("name") or "")
    package_description: Optional[str] = (
        str(pkg.get("description")) if pkg.get("description") else None
    )
    stats = _manifest_preview_stats(canonical)
    return PackagePreviewItem(
        package_name=package_name,
        package_description=package_description,
        scope_kind=str(canonical.get("scope") or "") or None,
        entry_type_count=stats["entry_type_count"],
        view_count=stats["view_count"],
        tag_count=stats["tag_count"],
        validation_errors=validation_errors or [],
    )


async def _publish_single_manifest(
    manifest_dict: Dict[str, Any],
    workspace_id: str,
    user_id: str,
    reg: Any,
    now: str,
) -> Any:
    """Persist one manifest as a library OperationalModel node.

    Returns the created OperationalModel node.
    """
    canonical = await asyncio.to_thread(
        compile_canonical_manifest, manifest=manifest_dict
    )
    pkg = canonical.get("package") or {}
    package_name: str = str(pkg.get("name") or "")
    package_description: Optional[str] = (
        str(pkg.get("description")) if pkg.get("description") else None
    )
    if not package_name:
        raise BadRequestError(
            message="manifest.package.name is required when publishing"
        )
    safe_name = non_empty_after_strip(package_name, "package.name")
    if len(safe_name) > 120:
        raise BadRequestError(message="package.name must be 120 characters or fewer")
    name_fold = compute_fold(safe_name)
    safe_version = (
        validate_semver_ish(str(pkg.get("version") or ""), allow_empty=True) or None
    )

    from app.services.uniqueness import assert_unique

    await assert_unique(
        OperationalModel,
        {
            "context.library_package": True,
            "context.workspace_id": workspace_id,
            "context.name_fold": name_fold,
            "context.version": safe_version,
        },
        entity="operational_model",
        field_label="name+version",
        value=f"{safe_name} {safe_version or '(no version)'}",
        scope_label="in this workspace",
    )

    from app.services.library_model_creation import create_private_library_model

    cp = await create_private_library_model(
        user_id=user_id,
        name=safe_name,
        name_fold=name_fold,
        description=package_description or "",
        version=safe_version,
        workspace_id=workspace_id,
        manifest=canonical,
        scope=str(canonical.get("scope") or ""),
        created_at=now,
        updated_at=now,
    )

    await emit_change_event(
        actor_kind="human",
        actor_id=user_id,
        action="operational_model.create",
        resource_type="OperationalModel",
        resource_id=cp.id,
        before=None,
        after=await export_node(cp),
        scope=f"user:{user_id}",
    )
    return cp


@endpoint(
    "/operational-models/import",
    methods=["POST"],
    auth=True,
    tags=["Operational Models"],
)
async def import_operational_model(
    request: Request,
) -> Dict[str, Any]:
    """Import OperationalModel manifests from a YAML/JSON file, or a ZIP archive.

    Accepts:
    - ``multipart/form-data`` with a ``file`` field (.yaml, .json, or .zip).
    - ``application/json`` body with a ``manifest`` key (single manifest only).

    ZIP archives must contain one or more ``<package-name>/operational-model.yaml``
    bundles (one level deep). Maximum ZIP size is 50 MB.

    When ``?preview=true`` the manifest(s) are validated and stats returned
    without persisting anything. In publish mode new library ``OperationalModel``
    nodes are created and cataloged.

    Preview response shape (always):
      ``{"packages": [...], "archive_type": "single" | "archive"}``

    Publish response shape:
      - Single file: ``{"operational_model": {...}, "message": "..."}``
      - ZIP archive:  ``{"published": N, "operational_models": [...], "message": "..."}``
    """
    from app.services.operational_model_import import (
        MAX_UPLOAD_BYTES,
        parse_archive_manifests,
        parse_manifest_bytes,
        validate_manifest_budget,
    )

    user_id = resolve_principal_id(request)
    if not user_id:
        raise MissingAuthenticationError(message="Authentication required")
    # Request-only binding keeps multipart uploads out of jvspatial's JSON
    # parameter model. Validate options explicitly for both supported transports.
    content_type = request.headers.get("content-type", "")
    body: Dict[str, Any] = {}
    if "application/json" in content_type:
        try:
            parsed = await request.json()
        except Exception as exc:
            raise BadRequestError(message=f"Could not parse JSON body: {exc}")
        if not isinstance(parsed, dict) or "manifest" not in parsed:
            raise BadRequestError(message="JSON body must have a 'manifest' key")
        body = parsed
    option_values = dict(body)
    for key in ("workspace_id", "preview"):
        if key in request.query_params:
            option_values[key] = request.query_params[key]
    try:
        options = ImportOperationalModelOptions.model_validate(option_values)
    except ValidationError:
        raise BadRequestError(message="Invalid import options or manifest")
    workspace_id = options.workspace_id
    preview = options.preview
    if not workspace_id:
        raise BadRequestError(message="workspace_id is required")
    workspace_id = (
        await _bind_create_workspace_scope(request, user_id, workspace_id) or ""
    )
    if not await can_publish_operational_models_under_workspace(user_id, workspace_id):
        raise InsufficientPermissionsError(message="Access denied")

    content_type = request.headers.get("content-type", "")

    # ------------------------------------------------------------------ #
    # 1. Read the uploaded bytes / manifest dict
    # ------------------------------------------------------------------ #
    manifest_dict: Optional[Dict[str, Any]] = None
    raw_bytes: Optional[bytes] = None
    filename: str = ""

    if "multipart/form-data" in content_type:
        # jvspatial @endpoint does not bind UploadFile params — read form directly.
        try:
            form = await request.form()
        except Exception as e:  # noqa: BLE001
            raise BadRequestError(message=f"Could not parse multipart body: {e}")

        file_parts = form.getlist("file")
        if not file_parts:
            raise BadRequestError(message="multipart body must include a 'file' field")

        upload = file_parts[0]
        filename = getattr(upload, "filename", "") or ""
        is_yaml = filename.lower().endswith((".yaml", ".yml"))
        is_json = filename.endswith(".json")
        is_zip = filename.endswith(".zip")

        if not (is_yaml or is_json or is_zip):
            raise BadRequestError(
                message="Only .yaml, .yml, .json, and .zip files are accepted"
            )

        raw_bytes = await upload.read(MAX_UPLOAD_BYTES + 1)  # type: ignore[union-attr]

        if len(raw_bytes) > MAX_UPLOAD_BYTES:
            raise BadRequestError(message="Upload exceeds the 50 MB limit")
        if not is_zip:
            manifest_dict = await asyncio.to_thread(
                parse_manifest_bytes, raw_bytes, is_yaml=is_yaml
            )

    elif "application/json" in content_type:
        manifest_dict = options.manifest
        if manifest_dict is None:
            raise BadRequestError(message="'manifest' must be an object")

    else:
        raise BadRequestError(
            message="Content-Type must be multipart/form-data or application/json"
        )

    # ------------------------------------------------------------------ #
    # 2. ZIP archive path
    # ------------------------------------------------------------------ #
    if filename.endswith(".zip") and raw_bytes is not None:
        sources = await asyncio.to_thread(parse_archive_manifests, raw_bytes)
        if preview:
            items: List[PackagePreviewItem] = []
            for package_name, raw, error in sources:
                try:
                    if error:
                        raise BadRequestError(message=error)
                    canonical = await asyncio.to_thread(
                        compile_canonical_manifest, manifest=raw
                    )
                    items.append(_build_package_preview_item(canonical))
                except Exception as exc:
                    items.append(
                        PackagePreviewItem(
                            package_name=package_name,
                            package_description=None,
                            entry_type_count=0,
                            view_count=0,
                            tag_count=0,
                            validation_errors=[str(exc)],
                        )
                    )
            return ImportPreviewResponse(
                packages=items, archive_type="archive"
            ).model_dump()

        reg = await OperationalModels.get(OPERATIONAL_MODELS_REGISTRY_ID)
        if not reg:
            raise ResourceNotFoundError(message="Operational Models registry missing")
        now = utc_now_iso()
        published_nodes = []
        for package_name, raw, error in sources:
            try:
                if error:
                    raise BadRequestError(message=error)
                assert raw is not None
                cp = await _publish_single_manifest(
                    manifest_dict=raw,
                    workspace_id=workspace_id,
                    user_id=user_id,
                    reg=reg,
                    now=now,
                )
                published_nodes.append(await export_node(cp))
            except Exception as exc:
                raise BadRequestError(
                    message=f"Failed to publish '{package_name}': {exc}"
                )
        return {
            "published": len(published_nodes),
            "operational_models": published_nodes,
            "message": f"{len(published_nodes)} operational model(s) imported",
        }

    # ------------------------------------------------------------------ #
    # 3. Single YAML / JSON file path (existing behaviour, preserved)
    # ------------------------------------------------------------------ #
    assert manifest_dict is not None  # guaranteed by branches above
    await asyncio.to_thread(validate_manifest_budget, manifest_dict)

    # Validate via the canonical compile path — raises on failure.
    canonical = await asyncio.to_thread(
        compile_canonical_manifest, manifest=manifest_dict
    )

    if preview:
        return ImportPreviewResponse(
            packages=[_build_package_preview_item(canonical)],
            archive_type="single",
        ).model_dump()

    # Publish path
    reg = await OperationalModels.get(OPERATIONAL_MODELS_REGISTRY_ID)
    if not reg:
        raise ResourceNotFoundError(message="Operational Models registry missing")
    now = utc_now_iso()
    cp = await _publish_single_manifest(
        manifest_dict=manifest_dict,
        workspace_id=workspace_id,
        user_id=user_id,
        reg=reg,
        now=now,
    )

    return {
        "operational_model": await export_node(cp),
        "message": "Operational Model imported",
    }
