"""Server-owned deployment capabilities, independent of Apps and licensing."""

from __future__ import annotations

from app.config import settings


def desktop_mode() -> bool:
    """Whether trusted startup selected the single-owner desktop profile."""
    return settings.INTEGRAL_DEPLOYMENT_PROFILE == "desktop_single_user"


def owner_ids() -> tuple[str, str]:
    """Return installation-bound auth and graph owner identities."""
    identity = settings.INTEGRAL_DESKTOP_INSTALLATION_ID
    if (
        not identity
        or len(identity) != 32
        or any(c not in "0123456789abcdef" for c in identity)
    ):
        raise RuntimeError("Desktop installation identity is missing or invalid")
    return f"o.User.desktop-{identity}", f"n.User.desktop-{identity}"


def require_collaboration() -> None:
    """Reject collaboration before any resource or authority is materialized."""
    if desktop_mode():
        from app.api.errors import InsufficientPermissionsError

        raise InsufficientPermissionsError(
            message="Collaboration is unavailable in this single-user installation.",
            details={"deployment_profile": "desktop_single_user"},
        )


def action_disabled(action: str) -> bool:
    """Apply deployment restrictions before human, agent or system policy grants."""
    if not desktop_mode():
        return False
    parts = action.split(".")
    return action in {"user.create", "user.delete"} or any(
        part.startswith(("collaborator_", "exclusion_", "invitation_", "member_"))
        or part in {"share_link", "public_share", "ownership", "transfer_ownership"}
        for part in parts
    )


def capabilities() -> dict:
    """Describe supported capabilities without granting resource authority."""
    local = desktop_mode()
    return {
        "profile": settings.INTEGRAL_DEPLOYMENT_PROFILE,
        "identity": "local_owner" if local else "account",
        "features": {
            "collaboration": not local,
            "public_sharing": not local,
            "organization_workspaces": not local,
            "app_extensions": True,
            "app_authoring": True,
            "manual_records": True,
        },
    }
