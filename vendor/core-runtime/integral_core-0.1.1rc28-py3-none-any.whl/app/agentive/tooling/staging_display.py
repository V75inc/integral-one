"""Human-readable labels for agent staging diffs (approval cards).

Ported from the retired ``integral_tools.py`` prepare handlers so manifest
stagers in ``bindings.py`` can resolve entry/track titles instead of raw
node ids in ``summary`` / ``diff_human``.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

_TITLE_LIKE_FIELD_KEYS = ("name", "title", "subject", "label")


def truncate(value: Any, limit: int = 80) -> str:
    """Coerce *value* to string and ellipsize beyond *limit* characters."""
    text = "" if value is None else str(value)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def derive_title(text: str, *, limit: int = 80) -> str:
    """Use the first non-empty line of *text* as a display title."""
    for line in text.splitlines():
        candidate = line.strip()
        if candidate:
            return (
                candidate if len(candidate) <= limit else candidate[: limit - 1] + "…"
            )
    return "Untitled note"


def short_node_id(node_id: str) -> str:
    """Abbreviate a graph node id for inline display."""
    s = (node_id or "").strip()
    if not s:
        return "?"
    if len(s) <= 12:
        return s
    return f"…{s[-8:]}"


def unwrap_handler_record(resp: Any, *keys: str) -> Optional[Dict[str, Any]]:
    """Return inner record from ``{entry|track|app: ...}`` handlers; None on errors."""
    if not isinstance(resp, dict) or resp.get("error"):
        return None
    for key in keys:
        inner = resp.get(key)
        if isinstance(inner, dict):
            return inner
    if any(k in resp for k in ("title", "name", "id", "track_id", "body")):
        return resp
    return None


def entry_display_label(entry: Dict[str, Any], fallback_id: str) -> str:
    """Resolve a human-readable entry label from exported entry data."""
    title = (entry.get("title") or "").strip()
    if title:
        return title
    body = entry.get("body")
    if isinstance(body, str) and body.strip():
        return derive_title(body)
    cf = entry.get("custom_fields") or entry.get("fields") or {}
    if isinstance(cf, dict):
        for key in _TITLE_LIKE_FIELD_KEYS:
            val = cf.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
    return f"Entry {short_node_id(fallback_id)}"


def track_display_label(track: Dict[str, Any], fallback_id: str) -> str:
    """Resolve a human-readable track label from exported track data."""
    title = (track.get("title") or "").strip()
    if title:
        return title
    return f"Track {short_node_id(fallback_id)}"


def app_display_label(app: Dict[str, Any], fallback_id: str) -> str:
    """Resolve a human-readable app label from exported app data."""
    name = (app.get("name") or app.get("title") or "").strip()
    if name:
        return name
    return f"App {short_node_id(fallback_id)}"


async def resolve_track_label(track_id: str) -> str:
    """Load a track and return its user-facing title (or a short fallback)."""
    current = await load_track_record(track_id)
    if current:
        return track_display_label(current, track_id)
    return f"Track {short_node_id(track_id)}"


async def resolve_app_label(app_id: str) -> str:
    """Load an app and return its user-facing name (or a short fallback)."""
    current = await load_app_record(app_id)
    if current:
        return app_display_label(current, app_id)
    return f"App {short_node_id(app_id)}"


async def resolve_container_label(
    *,
    track_id: Optional[str] = None,
    app_id: Optional[str] = None,
) -> str:
    """Resolve a track or app id to a user-facing container label."""
    if track_id:
        return await resolve_track_label(track_id)
    if app_id:
        return await resolve_app_label(app_id)
    return "?"


def _collect_node_ids_in_value(value: Any) -> Tuple[List[str], List[str], List[str]]:
    tag_ids: List[str] = []
    entry_ids: List[str] = []
    track_ids: List[str] = []
    seen_t: set[str] = set()
    seen_e: set[str] = set()
    seen_tr: set[str] = set()

    def visit(item: Any) -> None:
        if isinstance(item, str):
            s = item.strip()
            if s.startswith("n.Tag.") and s not in seen_t:
                seen_t.add(s)
                tag_ids.append(s)
            elif s.startswith("n.Entry.") and s not in seen_e:
                seen_e.add(s)
                entry_ids.append(s)
            elif s.startswith("n.Track.") and s not in seen_tr:
                seen_tr.add(s)
                track_ids.append(s)
        elif isinstance(item, dict):
            tid = item.get("id")
            if isinstance(tid, str):
                visit(tid)
            name = item.get("name") or item.get("title") or ""
            if isinstance(name, str) and name.strip():
                return
            for v in item.values():
                visit(v)
        elif isinstance(item, list):
            for sub in item:
                visit(sub)

    visit(value)
    return tag_ids, entry_ids, track_ids


def _tag_name_from_export(tag_data: Dict[str, Any]) -> str:
    name = (tag_data.get("name") or "").strip()
    if name:
        return name
    ctx = tag_data.get("context")
    if isinstance(ctx, dict):
        ctx_name = str(ctx.get("name") or "").strip()
        if ctx_name:
            return ctx_name
    return ""


async def resolve_node_labels_for_diff(
    fields: Dict[str, Any],
    *,
    user_id: str,
    workspace_id: Optional[str] = None,
) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, str]]:
    """Resolve relation labels only from records visible to the acting user."""
    all_tag_ids: List[str] = []
    all_entry_ids: List[str] = []
    all_track_ids: List[str] = []
    for value in fields.values():
        tids, eids, trids = _collect_node_ids_in_value(value)
        all_tag_ids.extend(tids)
        all_entry_ids.extend(eids)
        all_track_ids.extend(trids)
    tag_names: Dict[str, str] = {}
    entry_names: Dict[str, str] = {}
    track_names: Dict[str, str] = {}
    if not all_tag_ids and not all_entry_ids and not all_track_ids:
        return tag_names, entry_names, track_names
    try:
        from app.services.permissions import (
            get_user_accessible_entries,
            get_user_accessible_tracks,
        )
        from app.services.request_scope import matches_workspace

        if all_entry_ids:
            entries = await get_user_accessible_entries(
                user_id,
                workspace_id=workspace_id,
                strict=True,
                candidate_query={"id": {"$in": list(dict.fromkeys(all_entry_ids))}},
            )
            for entry in entries:
                eid = getattr(entry, "id", None)
                title = (getattr(entry, "title", None) or "").strip()
                if eid and title:
                    entry_names[eid] = title

        visible_tracks = await get_user_accessible_tracks(user_id)
        if workspace_id:
            visible_tracks = [
                track
                for track in visible_tracks
                if matches_workspace(track, workspace_id)
            ]
        track_ids = set(all_track_ids)
        tag_ids = set(all_tag_ids)
        for track in visible_tracks:
            tid = getattr(track, "id", None)
            title = (getattr(track, "title", None) or "").strip()
            if tid in track_ids and title:
                track_names[tid] = title
            if tag_ids:
                for tag in await track.nodes(edge=["CONTAINS"], node=["Tag"]):
                    tag_id = getattr(tag, "id", None)
                    tag_name = (getattr(tag, "name", None) or "").strip()
                    if tag_id in tag_ids and tag_name:
                        tag_names[tag_id] = tag_name
    except Exception:  # noqa: BLE001 - unresolved labels remain abbreviated ids
        pass

    return tag_names, entry_names, track_names


def format_scalar_for_diff(
    value: Any,
    *,
    tag_names: Dict[str, str],
    entry_names: Dict[str, str],
    track_names: Optional[Dict[str, str]] = None,
) -> str:
    """Render a field value for diff display, resolving tag/entry/track ids to names."""
    track_names = track_names or {}

    def fmt_one(item: Any) -> str:
        if isinstance(item, dict):
            name = (item.get("name") or item.get("title") or "").strip()
            if name:
                return name
            iid = item.get("id")
            if isinstance(iid, str):
                item = iid
            else:
                return truncate(item, 40)

        if not isinstance(item, str):
            return truncate(item, 40)

        s = item.strip()
        if s in tag_names:
            return f"{tag_names[s]} *({truncate(s, 24)})*"
        if s in entry_names:
            return f"{entry_names[s]} *({truncate(s, 24)})*"
        if s in track_names:
            return track_names[s]
        if (
            s.startswith("n.Tag.")
            or s.startswith("n.Entry.")
            or s.startswith("n.Track.")
        ):
            return truncate(s, 40)
        # Approval must expose the actual proposed text. Ellipsizing here
        # destroys URL targets and hides qualifiers the reviewer must assess.
        # The approval sheet already provides a scrollable review region.
        return item

    if isinstance(value, list):
        parts = [fmt_one(v) for v in value]
        return ", ".join(parts) if parts else "—"
    return fmt_one(value)


async def format_fields_patch_for_diff(
    fields: Dict[str, Any], *, user_id: str, workspace_id: Optional[str] = None
) -> str:
    """Format a fields patch as ``key = value`` pairs for approval-card diffs."""
    tag_names, entry_names, track_names = await resolve_node_labels_for_diff(
        fields, user_id=user_id, workspace_id=workspace_id
    )
    parts = [
        f"`{k}` = {format_scalar_for_diff(v, tag_names=tag_names, entry_names=entry_names, track_names=track_names)}"
        for k, v in fields.items()
    ]
    return ", ".join(parts)


async def load_entry_record(entry_id: str) -> Optional[Dict[str, Any]]:
    """Best-effort entry export for staging labels (no permission gate)."""
    try:
        from app.api.utils import export_node
        from app.models.nodes import Entry

        entry = await Entry.get(entry_id)
        if not entry:
            return None
        return await export_node(entry)
    except Exception:  # noqa: BLE001
        return None


async def load_track_record(track_id: str) -> Optional[Dict[str, Any]]:
    """Best-effort track export for staging labels (no permission gate)."""
    try:
        from app.api.utils import export_node
        from app.models.nodes import Track

        track = await Track.get(track_id)
        if not track:
            return None
        return await export_node(track)
    except Exception:  # noqa: BLE001
        return None


async def load_app_record(app_id: str) -> Optional[Dict[str, Any]]:
    """Best-effort app export for staging labels (no permission gate)."""
    try:
        from app.api.utils import export_node
        from app.models.nodes import App

        app = await App.get(app_id)
        if not app:
            return None
        return await export_node(app)
    except Exception:  # noqa: BLE001
        return None


def format_review_text(value: str) -> str:
    """Show complete literal content without letting embedded Markdown alter review."""
    # A longer fence keeps even embedded code fences inside the literal preview.
    longest = max((len(run) for run in re.findall(r"`+", value)), default=0)
    fence = "`" * max(3, longest + 1)
    return f"{fence}text\n{value}\n{fence}"


async def format_scalar_change_line(
    key: str,
    new_val: Any,
    old_val: Any,
    *,
    tag_names: Optional[Dict[str, str]] = None,
    entry_names: Optional[Dict[str, str]] = None,
    track_names: Optional[Dict[str, str]] = None,
) -> str:
    """Build a markdown bullet for one scalar field change (old → new when present)."""
    tag_names = tag_names or {}
    entry_names = entry_names or {}
    track_names = track_names or {}
    new_rendered = format_scalar_for_diff(
        new_val,
        tag_names=tag_names,
        entry_names=entry_names,
        track_names=track_names,
    )
    if old_val is not None and old_val != new_val:
        old_rendered = format_scalar_for_diff(
            old_val,
            tag_names=tag_names,
            entry_names=entry_names,
            track_names=track_names,
        )
        if any(
            len(text) > 80 or "\n" in text or "`" in text
            for text in (old_rendered, new_rendered)
        ):
            return (
                f"- **{key}:**\n\n**Previous:**\n\n{format_review_text(old_rendered)}"
                f"\n\n**Proposed:**\n\n{format_review_text(new_rendered)}"
            )
        return f"- **{key}:** `{old_rendered}` → `{new_rendered}`"
    if len(new_rendered) > 80 or "\n" in new_rendered or "`" in new_rendered:
        return f"- **{key}:**\n\n{format_review_text(new_rendered)}"
    return f"- **{key}:** `{new_rendered}`"
