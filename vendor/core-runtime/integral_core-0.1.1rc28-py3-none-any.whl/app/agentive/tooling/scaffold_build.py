"""One bounded, approved scaffold plan through the normal staged-write seam."""

from __future__ import annotations

import json
import re
from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.agentive.staging import (
    cancel_batch,
    is_batch_open,
    open_batch,
    peek_open_batch,
)
from app.agentive.tooling.dispatch import ToolResult
from app.services.chat_threads import (
    design_chat_affirmed_for_build,
    get_thread_by_session,
    record_design_partial_build,
)
from app.services.design_blueprint import tag_ref_name as _tag_ref_name
from app.services.operational_model_authoring import normalize_inline_taxonomy
from app.services.operational_model_runtime import slug_manifest_key
from app.services.relative_date_filters import normalize_relative_date

_PLAN_TOOLS = frozenset(
    {
        "integral_create_app",
        "integral_create_app_track",
        "integral_create_tag",
        "integral_register_track_template",
        "integral_save_view",
        "integral_create_entry",
        "integral_create_dashboard",
        "integral_author_skill",
        "integral_schedule_task",
    }
)
_FLAT_RELATION_KEYS = (
    "target",
    "target_track_template",
    "target_entry_types",
    "target_track_types",
    "target_track_name",
    "target_track",
    "allow_cross_track",
    "many",
)
_MAX_OPERATIONS = 64
_MAX_RAW_OPERATIONS = 128
_FIELDS_ASSERTION = re.compile(r"^(.+?)\s+track with fields:\s*(.+)$", re.IGNORECASE)
_QUOTED_FIELDS_ASSERTION = re.compile(
    r'^Track\s+"([^"]+)"\s+with fields:\s*(.+)$', re.IGNORECASE
)
_TRACK_HEADING = re.compile(r"^#{3,4}\s*\d+\.\s*(.+?)(?:\s+Track)?\s*$", re.IGNORECASE)
_NAMED_TRACK_HEADING = re.compile(r"^#{2,4}\s*(.+?)\s+Track\s*$", re.IGNORECASE)
_TRACK_COLON_HEADING = re.compile(r"^#{2,4}\s+Track:\s*(.+?)\s*$", re.IGNORECASE)
_QUOTED_TRACK_LINE = re.compile(r'^#{0,4}\s*Track\s+"([^"]+)"\s*$', re.IGNORECASE)
_NEW_TRACK_LABEL = re.compile(r"^\*\*New Track:\*\*\s*(.+?)\s*$", re.IGNORECASE)
_DESIGN_FIELD = re.compile(
    r"^(\s*)-\s+(?:\*\*)?(.+?)(?:\*\*)?\s*\(\s*([A-Za-z][\w-]*)",
)
_FIELDS_BULLET = re.compile(r"^(\s*)-\s+(?:\*\*)?fields:(?:\*\*)?\s*$", re.IGNORECASE)
_FIELD_TYPES = frozenset(
    {
        "text",
        "number",
        "boolean",
        "date",
        "datetime",
        "markdown",
        "json",
        "select",
        "multi_select",
        "relation",
        "computed",
        "file",
        "files",
        "member",
    }
)
_OPERATOR_ALIASES = {
    "=": "eq",
    "==": "eq",
    "!=": "neq",
    ">": "gt",
    "<": "lt",
    ">=": "gte",
    "<=": "lte",
}


def _canonical_operator(value: Any) -> str:
    raw = str(value or "eq").strip()
    return _OPERATOR_ALIASES.get(raw, raw)


def _expanded_filter(
    item: Dict[str, Any], *, operator_key: str
) -> list[Dict[str, Any]]:
    """Compile negative membership to supported conjunctive comparisons."""
    op = _canonical_operator(
        item.get(operator_key) or item.get("op") or item.get("operator")
    )
    base = {key: value for key, value in item.items() if key not in {"op", "operator"}}
    if op in {"not_in", "nin", "$nin"}:
        values = item.get("value")
        if not isinstance(values, list) or not values:
            raise ValueError("not_in filter needs a non-empty list of values")
        return [{**base, operator_key: "neq", "value": value} for value in values]
    return [{**base, operator_key: op}]


def _coalesce_plan_operations(raw: list[Any]) -> list[Any]:
    """Remove repeated view writes and compatible staged seed refinements."""
    if len(raw) > _MAX_RAW_OPERATIONS:
        raise ValueError(f"Plan exceeds {_MAX_RAW_OPERATIONS} submitted operations.")
    result: list[Any] = []
    fingerprints: set[str] = set()
    seed_positions: Dict[tuple[str, str], int] = {}
    for item in raw:
        if not isinstance(item, dict):
            result.append(item)
            continue
        fingerprint = json.dumps(item, sort_keys=True, default=str)
        if fingerprint in fingerprints:
            continue
        fingerprints.add(fingerprint)
        args = item.get("args")
        if item.get("tool") == "integral_create_entry" and isinstance(args, dict):
            identity = (
                str(args.get("track_id") or "").casefold(),
                str(args.get("title") or "").casefold(),
            )
            prior_index = seed_positions.get(identity)
            if prior_index is not None:
                prior = result[prior_index]
                prior_args = prior.get("args") or {}
                old_fields = prior_args.get("fields") or {}
                new_fields = args.get("fields") or {}
                if not isinstance(old_fields, dict) or not isinstance(new_fields, dict):
                    raise ValueError(f"Conflicting seed for {identity[1]!r}.")
                if any(
                    key in new_fields and new_fields[key] != value
                    for key, value in old_fields.items()
                ):
                    raise ValueError(f"Conflicting seed fields for {identity[1]!r}.")
                if {
                    key: value
                    for key, value in prior_args.items()
                    if key not in {"fields", "text"}
                } != {
                    key: value
                    for key, value in args.items()
                    if key not in {"fields", "text"}
                }:
                    raise ValueError(f"Conflicting seed shape for {identity[1]!r}.")
                result[prior_index] = None
                merged = {**old_fields, **new_fields}
                item = {**item, "args": {**args, "fields": merged}}
            seed_positions[identity] = len(result)
        result.append(item)
    return [item for item in result if item is not None]


def _checklist_field_names(blob: str) -> set[str]:
    names: set[str] = set()
    for label in blob.split(","):
        cleaned = re.sub(r"\s*\([^)]*\)", "", label).strip().strip("*").strip("\"'")
        if cleaned:
            names.add(cleaned.casefold())
    return names


def _typed_field_name(line: str) -> Optional[str]:
    """Label before the first parenthesis, when that parenthesis is a field type."""
    match = _DESIGN_FIELD.match(line)
    if not match:
        return None
    type_name = match.group(3).casefold().replace("-", "_")
    if type_name not in _FIELD_TYPES:
        return None
    label = match.group(2).strip().strip("*").strip()
    return label.casefold() if label else None


def _track_heading_name(line: str) -> Optional[str]:
    stripped = line.strip()
    match = (
        _TRACK_HEADING.match(stripped)
        or _NAMED_TRACK_HEADING.match(stripped)
        or _TRACK_COLON_HEADING.match(stripped)
        or _QUOTED_TRACK_LINE.match(stripped)
        or _NEW_TRACK_LABEL.match(stripped)
    )
    if not match:
        return None
    name = match.group(1).strip().strip("*").strip("\"'")
    return name.casefold() if name else None


def _approved_field_requirements(marker: Dict[str, Any]) -> Dict[str, set[str]]:
    """Read concrete field promises from the checklist, then from typed prose.

    Typed field lines in the proposal replace the checklist for that track.
    A checklist is the backup when the prose names no typed fields.
    """
    required: Dict[str, set[str]] = {}
    for assertion in marker.get("acceptance_assertions") or []:
        text = str(assertion).strip()
        match = _QUOTED_FIELDS_ASSERTION.match(text) or _FIELDS_ASSERTION.match(text)
        if not match:
            continue
        required[match.group(1).strip().casefold()] = _checklist_field_names(
            match.group(2)
        )
    proposal_fields: Dict[str, set[str]] = {}
    track_name: str | None = None
    in_fields = False
    fields_indent = 0
    for line in str(marker.get("proposal") or "").splitlines():
        heading = _track_heading_name(line)
        if heading:
            track_name = heading
            in_fields = False
            continue
        if line.lstrip().startswith("#"):
            in_fields = False
            track_name = None
            continue
        fields_bullet = _FIELDS_BULLET.match(line)
        if fields_bullet and track_name:
            in_fields = True
            fields_indent = len(fields_bullet.group(1))
            continue
        if not in_fields or not track_name:
            continue
        if re.match(r"^\s*-\s+(?:\*\*)?views:(?:\*\*)?", line, re.IGNORECASE):
            in_fields = False
            continue
        bullet = re.match(r"^(\s*)-\s+", line)
        if bullet and len(bullet.group(1)) <= fields_indent:
            in_fields = False
            continue
        field_name = _typed_field_name(line)
        if field_name:
            proposal_fields.setdefault(track_name, set()).add(field_name)
    # Prose assertions may compress several concrete fields ("last/next
    # service", "rental start/end"). Where the approved proposal spells out
    # the fields, its exact labels replace that compressed set.
    required.update(proposal_fields)
    return required


def _track_declared_field_names(params: Dict[str, Any]) -> set[str]:
    field_sets = [params.get("fields") or []]
    field_sets.extend(
        entry_type.get("fields") or []
        for entry_type in (params.get("entry_types") or [])
        if isinstance(entry_type, dict)
    )
    return {
        str(field.get("name") or field.get("key") or "").strip().casefold()
        for fields in field_sets
        for field in fields
        if isinstance(field, dict)
    }


def _is_unlabelled_title_line(line: str, labels: Dict[str, Any]) -> bool:
    """True when ``line`` names a record and is not a broken ``Field: value`` row.

    A line that begins with a declared field name but omits the colon stays
    invalid. A name such as ``Berghotel Grosse Scheidegg`` does not.
    """
    if ":" in line:
        return False
    folded = line.strip().casefold()
    if not folded:
        return False
    for label in labels:
        if not label:
            continue
        if folded == label or folded.startswith(f"{label} "):
            return False
    return True


def _structured_seed(
    params: Dict[str, Any],
    track_fields: Dict[str, list[Dict[str, Any]]],
    seed_titles: Dict[str, str],
) -> Dict[str, Any]:
    """Turn labelled demo text into typed fields; never silently file empty rows."""
    entry = dict(params)
    track_ref = str(entry.get("track_id") or "")
    specs = track_fields.get(track_ref)
    if not specs or entry.get("fields"):
        if specs and isinstance(entry.get("fields"), dict):
            relation_keys = {
                str(field.get("key"))
                for field in specs
                if isinstance(field, dict) and field.get("type") == "relation"
            }
            fields = dict(entry["fields"])
            for key, value in fields.items():
                if (
                    key in relation_keys
                    and isinstance(value, str)
                    and value.strip().casefold() in seed_titles
                ):
                    fields[key] = (
                        f"{{{{entry.id:{seed_titles[value.strip().casefold()]}}}}}"
                    )
            entry["fields"] = fields
            entry["strict_fields"] = True
        return entry
    text = str(entry.get("text") or "").strip()
    if not text:
        if str(entry.get("title") or "").strip():
            # A named record with no supplied optional values is the same
            # seed as an unlabelled title below. Do not force the planner to
            # invent field values. Required-field validation still belongs to
            # the normal typed entry operation and blueprint fidelity checks.
            return entry
        raise ValueError("A typed seed entry needs structured fields.")
    labels = {
        str(field.get("name") or field.get("key") or "").strip().casefold(): field
        for field in specs
        if isinstance(field, dict) and field.get("key")
    }
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) == 1 and _is_unlabelled_title_line(lines[0], labels):
        # The user named the record and supplied no field labels. File the
        # line as the title instead of rejecting it as a malformed field row.
        if not str(entry.get("title") or "").strip():
            entry["title"] = lines[0]
        entry.pop("text", None)
        return entry
    values: Dict[str, Any] = {}
    for line in text.splitlines():
        label, separator, raw_value = line.partition(":")
        field = labels.get(label.strip().casefold())
        if not separator or field is None or not raw_value.strip():
            raise ValueError(f"Seed line {line!r} does not match a declared field.")
        value = raw_value.strip()
        if field.get("type") == "relation":
            if value.casefold() not in seed_titles:
                raise ValueError(f"Relation target {value!r} is not a planned seed.")
            value = f"{{{{entry.id:{seed_titles[value.casefold()]}}}}}"
        elif field.get("type") == "member" and value.casefold() in seed_titles:
            raise ValueError(
                f"Member field {field['key']!r} cannot point to planned entry {value!r}; "
                "use a relation field for a Technician record."
            )
        values[str(field["key"])] = value
    if not values:
        raise ValueError("A typed seed entry needs structured fields.")
    entry["fields"] = values
    entry["strict_fields"] = True
    entry.pop("text", None)
    return entry


def _field_path(key: str) -> str:
    return key if key.startswith("custom_fields.") else f"custom_fields.{key}"


def _expand_track(
    params: Dict[str, Any], *, include_default_view: bool = False
) -> list[tuple[str, Dict[str, Any]]]:
    """Compile common design shorthand into the published track/view tools."""
    track = dict(params)
    fields = track.pop("fields", None)
    if fields and not track.get("entry_types"):
        name = str(track.get("name") or "Record")
        singular = name[:-1] if name.endswith("s") else name
        track["entry_types"] = [{"name": singular, "fields": fields}]
    views = track.pop("views", None)
    # A table is added only when the caller already decided the plan or the
    # approved design asked for one. Feed is a substrate default elsewhere.
    if views is None:
        views = (
            [{"name": f"All {track.get('name')}", "type": "table"}]
            if include_default_view
            else []
        )
    operations: list[tuple[str, Dict[str, Any]]] = [
        ("integral_create_app_track", track)
    ]
    for view in views:
        if not isinstance(view, dict):
            raise ValueError("each track view must be an object")
        view_type = view.get("type") or view.get("view_type") or "table"
        config = dict(view.get("config") or {})
        if view_type == "table" and not config.get("columns"):
            source_fields = fields or (
                (track.get("entry_types") or [{}])[0].get("fields") or []
            )
            config["columns"] = [
                _field_path(str(field["key"]))
                for field in source_fields
                if isinstance(field, dict) and field.get("key")
            ]
        if view_type == "kanban":
            group = view.get("group_by") or config.get("group_by")
            if group:
                config["group_by"] = _field_path(str(group))
                source_fields = fields or (
                    (track.get("entry_types") or [{}])[0].get("fields") or []
                )
                selected = next(
                    (field for field in source_fields if field.get("key") == group),
                    None,
                )
                if selected and selected.get("enum"):
                    config["kanban_columns"] = list(selected["enum"])
        if view_type == "calendar":
            date_field = view.get("date_field") or config.get("date_field")
            if date_field:
                config["calendar_mapping"] = {"dateField": _field_path(str(date_field))}
        if view_type == "wiki":
            parent_field = view.get("parent_field") or config.get("parent_field")
            if parent_field:
                config["parent_field"] = str(parent_field).removeprefix(
                    "custom_fields."
                )
        operations.append(
            (
                "integral_save_view",
                {
                    "track_id": f"{{{{track.id:{track['name']}}}}}",
                    "name": view.get("name") or f"All {track['name']}",
                    "view_type": view_type,
                    "config": config,
                    "is_default": bool(view.get("is_default")),
                },
            )
        )
    return operations


def _normalize_dashboard(params: Dict[str, Any]) -> Dict[str, Any]:
    dashboard = dict(params)
    widgets = []
    operators = {
        "$eq": "eq",
        "$ne": "neq",
        "$gt": "gt",
        "$lt": "lt",
        "$gte": "gte",
        "$lte": "lte",
        "$nin": "not_in",
    }
    for raw in dashboard.get("widgets") or []:
        if not isinstance(raw, dict):
            widgets.append(raw)
            continue
        widget = dict(raw)
        if widget.get("type") == "list":
            widget["type"] = "recent_entries"
        widget.setdefault("title", widget.pop("name", ""))
        source = dict(widget.get("data_source") or {})
        if widget.get("track_id") and not source.get("track_id"):
            source["track_id"] = widget.pop("track_id")
        filters = widget.pop("filters", None)
        if isinstance(filters, dict):
            expressions = []
            for field, predicate in filters.items():
                path = _field_path(str(field))
                if isinstance(predicate, dict):
                    for op, value in predicate.items():
                        if op not in operators:
                            raise ValueError(f"unsupported dashboard filter {op}")
                        expressions.extend(
                            _expanded_filter(
                                {"field": path, "op": operators[op], "value": value},
                                operator_key="op",
                            )
                        )
                else:
                    expressions.append({"field": path, "op": "eq", "value": predicate})
            source["filters"] = expressions
        elif isinstance(source.get("filters"), list):
            source["filters"] = [
                expanded
                for item in source["filters"]
                for expanded in (
                    _expanded_filter(item, operator_key="op")
                    if isinstance(item, dict)
                    else [item]
                )
            ]
        widget["data_source"] = source
        widgets.append(widget)
    dashboard["widgets"] = widgets
    return dashboard


def _normalize_view(params: Dict[str, Any]) -> Dict[str, Any]:
    view = dict(params)
    config = dict(view.get("config") or {})
    if not view.get("track_id") and config.get("track"):
        # Planners echo the blueprint view item into ``config``; its
        # is_default/decision already live in the approved blueprint.
        view.update(
            track_id=config["track"],
            name=view.get("name") or config.get("name"),
            view_type=view.get("view_type") or config.get("type"),
        )
        config = dict(config.get("config") or {})
    filters = config.pop("filter", None)
    if filters is not None and "filters" not in config:
        config["filters"] = filters
    if isinstance(config.get("filters"), list):
        config["filters"] = [
            expanded
            for item in config["filters"]
            for expanded in (
                _expanded_filter(item, operator_key="operator")
                if isinstance(item, dict)
                else [item]
            )
        ]
    view["config"] = config
    return view


def _reconcile_scaffold_name_fields(
    operations: list[tuple[str, Dict[str, Any]]],
) -> None:
    """Use an Entry's title for a scaffold's redundant text Name field.

    This applies only when every named seed agrees with its title. A distinct
    Name value is real domain data and must retain its authored field.
    Called after approval fidelity checks so the preview's Name promise is
    fulfilled by the visible title control rather than a duplicate input.
    """
    track_refs: set[str] = set()
    for tool, params in operations:
        if tool != "integral_create_app_track":
            continue
        track_ref = f"{{{{track.id:{params.get('name')}}}}}"
        fields = list(params.get("fields") or []) + [
            field
            for entry_type in params.get("entry_types") or []
            if isinstance(entry_type, dict)
            for field in entry_type.get("fields") or []
        ]
        name_fields = [
            field
            for field in fields
            if isinstance(field, dict)
            and str(field.get("key") or "").casefold() == "name"
            and str(field.get("type") or "text").casefold() == "text"
        ]
        if len(name_fields) != 1:
            continue
        seeds = [
            seed
            for seed_tool, seed in operations
            if seed_tool == "integral_create_entry"
            and seed.get("track_id") == track_ref
        ]
        if any(
            str((seed.get("fields") or {}).get("name") or "").strip()
            and str((seed.get("fields") or {}).get("name") or "").strip()
            != str(seed.get("title") or "").strip()
            for seed in seeds
        ):
            continue
        track_refs.add(track_ref)
        params["fields"] = [
            field for field in params.get("fields") or [] if field is not name_fields[0]
        ]
        params["entry_types"] = [
            (
                {
                    **entry_type,
                    "base_fields": {
                        **(entry_type.get("base_fields") or {}),
                        "title": {
                            **(
                                (entry_type.get("base_fields") or {}).get("title") or {}
                            ),
                            "label": "Name",
                        },
                    },
                    "fields": [
                        field
                        for field in entry_type.get("fields") or []
                        if field is not name_fields[0]
                    ],
                }
                if isinstance(entry_type, dict)
                else entry_type
            )
            for entry_type in params.get("entry_types") or []
        ]

    for tool, params in operations:
        if params.get("track_id") not in track_refs:
            continue
        if tool == "integral_create_entry" and isinstance(params.get("fields"), dict):
            params["fields"].pop("name", None)
        if tool != "integral_save_view" or params.get("view_type") != "table":
            continue
        config = params.get("config") or {}
        columns = config.get("columns")
        if not isinstance(columns, list):
            continue
        seen_title = False
        normalized = []
        for column in columns:
            field = column.get("field") if isinstance(column, dict) else column
            if field in {"name", "custom_fields.name"}:
                field = "title"
                column = (
                    {**column, "field": field} if isinstance(column, dict) else field
                )
            if field == "title":
                if seen_title:
                    continue
                seen_title = True
            normalized.append(column)
        config["columns"] = normalized


def _dashboard_from_date_views(
    operations: list[tuple[str, Dict[str, Any]]], app_name: str
) -> Dict[str, Any]:
    widgets = []
    for tool, params in operations:
        if tool != "integral_save_view":
            continue
        name = str(params.get("name") or "")
        if not (name.startswith("Overdue ") or name.startswith("Upcoming ")):
            continue
        filters = [
            {
                "field": item.get("field"),
                "op": _canonical_operator(item.get("operator")),
                "value": item.get("value"),
            }
            for item in (params.get("config") or {}).get("filters", [])
        ]
        widgets.append(
            {
                "type": "recent_entries",
                "title": name,
                "data_source": {
                    "track_id": params.get("track_id"),
                    "filters": filters,
                    "limit": 10,
                },
            }
        )
    return {"app_id": "{{app.id}}", "name": f"{app_name} Dashboard", "widgets": widgets}


def _invalid(code: str, message: str) -> ToolResult:
    return ToolResult(is_error=True, error_code=code, message=message)


def _relation_type_slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().casefold()).strip("-")


def _annotate_plan_cross_track_relations(operations: list[Any]) -> list[Any]:
    """Name sibling tracks on relations that target entry types from other tracks.

    Approved multi-track designs often declare ``target_entry_types: ["business"]``
    on Expenses while Business lives on a sibling track. Runtime then rejects
    seed ``create_entry`` with "cannot reference entries across tracks" unless
    ``target_track_types`` is set (see ``relation_allows_cross_track``).
    """
    type_to_tracks: Dict[str, set[str]] = {}
    type_alias_to_name: Dict[str, str] = {}
    track_to_types: Dict[str, list[str]] = {}
    track_alias_to_name: Dict[str, str] = {}
    for item in operations:
        if (
            not isinstance(item, dict)
            or item.get("tool") != "integral_create_app_track"
        ):
            continue
        args = item.get("args") if isinstance(item.get("args"), dict) else {}
        track_name = str(args.get("name") or "").strip()
        if not track_name:
            continue
        track_alias_to_name[_relation_type_slug(track_name)] = track_name
        for entry_type in args.get("entry_types") or []:
            if not isinstance(entry_type, dict):
                continue
            canonical_name = str(
                entry_type.get("name") or entry_type.get("key") or ""
            ).strip()
            if canonical_name:
                track_to_types.setdefault(_relation_type_slug(track_name), []).append(
                    canonical_name
                )
            for label in (entry_type.get("key"), entry_type.get("name")):
                slug = _relation_type_slug(label)
                if slug:
                    type_to_tracks.setdefault(slug, set()).add(track_name)
                    if canonical_name:
                        type_alias_to_name[slug] = canonical_name

    annotated: list[Any] = []
    for item in operations:
        if (
            not isinstance(item, dict)
            or item.get("tool") != "integral_create_app_track"
        ):
            annotated.append(item)
            continue
        args = dict(item.get("args") or {})
        track_name = str(args.get("name") or "").strip()
        entry_types: list[Any] = []
        for entry_type in args.get("entry_types") or []:
            if not isinstance(entry_type, dict):
                entry_types.append(entry_type)
                continue
            fields: list[Any] = []
            for field in entry_type.get("fields") or []:
                if not isinstance(field, dict) or field.get("type") != "relation":
                    fields.append(field)
                    continue
                relation = field.get("relation")
                if not isinstance(relation, dict):
                    fields.append(field)
                    continue
                targets = relation.get("target_entry_types") or []
                if not isinstance(targets, (list, tuple)):
                    fields.append(field)
                    continue
                normalized_targets = []
                for target in targets:
                    target_slug = _relation_type_slug(target)
                    canonical_name = type_alias_to_name.get(target_slug)
                    # Models often use a sibling Track label as shorthand for
                    # its only EntryType ("Equipment" → "Equipment Item").
                    # Resolve that safely only when the target Track declares
                    # exactly one type; ambiguous Tracks retain strict labels.
                    if canonical_name is None:
                        sibling_types = track_to_types.get(target_slug) or []
                        if len(sibling_types) == 1:
                            canonical_name = sibling_types[0]
                    normalized_targets.append(canonical_name or str(target))
                raw_track_types = relation.get("target_track_types") or []
                if not isinstance(raw_track_types, (list, tuple)):
                    raw_track_types = []
                normalized_track_types: set[str] = set()
                type_targets_from_track_types: list[str] = []
                for target in raw_track_types:
                    target_text = str(target).strip()
                    track_ref = re.fullmatch(r"\{\{track\.id:(.+?)\}\}", target_text)
                    if track_ref:
                        referenced_track = track_ref.group(1).strip()
                        referenced_track_name = track_alias_to_name.get(
                            _relation_type_slug(referenced_track)
                        )
                        if referenced_track_name:
                            normalized_track_types.add(referenced_track_name)
                            sibling_types = track_to_types.get(
                                _relation_type_slug(referenced_track_name), []
                            )
                            if len(sibling_types) == 1:
                                type_targets_from_track_types.append(sibling_types[0])
                            continue
                    slug = _relation_type_slug(target_text)
                    owners = type_to_tracks.get(slug) or set()
                    if owners:
                        normalized_track_types.update(owners)
                        if slug in type_alias_to_name:
                            type_targets_from_track_types.append(
                                type_alias_to_name[slug]
                            )
                    else:
                        normalized_track_types.add(str(target).strip())
                if type_targets_from_track_types:
                    normalized_targets = list(
                        dict.fromkeys(
                            normalized_targets + type_targets_from_track_types
                        )
                    )
                foreign_tracks: set[str] = set()
                for target in normalized_targets:
                    for owner in type_to_tracks.get(_relation_type_slug(target), ()):
                        if owner != track_name:
                            foreign_tracks.add(owner)
                foreign_tracks.update(
                    owner for owner in normalized_track_types if owner != track_name
                )
                if (
                    not foreign_tracks
                    and normalized_targets == list(targets)
                    and normalized_track_types
                    == {str(x).strip() for x in raw_track_types if str(x).strip()}
                ):
                    fields.append(field)
                    continue
                existing = {
                    str(x).strip() for x in normalized_track_types if str(x).strip()
                }
                fields.append(
                    {
                        **field,
                        "relation": {
                            **relation,
                            "target_entry_types": normalized_targets,
                            "target_track_types": sorted(existing | foreign_tracks),
                            "allow_cross_track": (
                                True
                                if foreign_tracks
                                else bool(relation.get("allow_cross_track", False))
                            ),
                        },
                    }
                )
            entry_types.append({**entry_type, "fields": fields})
        annotated.append({**item, "args": {**args, "entry_types": entry_types}})
    return annotated


def _approved_plan_item(
    item: Any,
    *,
    only_track_name: str = "",
    plan_track_types: dict[str, list[str]] | None = None,
) -> Any:
    """Accept familiar display-name shorthand but stage published tool args.

    ``plan_track_types`` maps each Track this plan creates (casefolded name) to
    its record types, so a relation that points at a sibling Track by name
    becomes a link to that Track's records.
    """
    if not isinstance(item, dict) or not isinstance(item.get("args"), dict):
        return item
    tool = item.get("tool")
    params = dict(item["args"])
    if tool == "integral_create_app_track":
        if "track_name" in params:
            params.setdefault("name", params.pop("track_name"))
        if "track_description" in params:
            params.setdefault("description", params.pop("track_description"))
        normalized_types = []
        for entry_type in params.get("entry_types") or []:
            if not isinstance(entry_type, dict):
                normalized_types.append(entry_type)
                continue
            fields = []
            for field in entry_type.get("fields") or []:
                if not isinstance(field, dict) or field.get("type") != "relation":
                    fields.append(field)
                    continue
                flat = {k: field[k] for k in _FLAT_RELATION_KEYS if k in field}
                if flat and isinstance(field.get("relation") or {}, dict):
                    field = {
                        **{k: v for k, v in field.items() if k not in flat},
                        "relation": {**flat, **(field.get("relation") or {})},
                    }
                relation = field.get("relation") or {}
                sibling = (
                    str(
                        relation.get("target_track_name")
                        or relation.get("target_track")
                        or relation.get("track_name")
                        or relation.get("track")
                        or ""
                    )
                    .strip()
                    .casefold()
                    if isinstance(relation, dict)
                    else ""
                )
                if (
                    isinstance(relation, dict)
                    and relation.get("target") == "track"
                    and not relation.get("target_track_template")
                    and not relation.get("target_entry_types")
                    and (plan_track_types or {}).get(sibling)
                ):
                    relation = {
                        k: v
                        for k, v in relation.items()
                        if k
                        not in {
                            "target_track_name",
                            "target_track",
                            "track_name",
                            "track",
                        }
                    }
                    relation["target_entry_types"] = plan_track_types[sibling]
                    field = {**field, "relation": relation}
                if isinstance(relation, dict) and (
                    str(relation.get("target") or "").lower()
                    in {"entry_type", "entry_types", "record", "records"}
                    or (
                        relation.get("target") == "track"
                        and not relation.get("target_track_template")
                        and relation.get("target_entry_types")
                    )
                ):
                    relation = {**relation, "target": "entry"}
                    field = {**field, "relation": relation}
                if isinstance(relation, dict):
                    related_type = relation.get("to_entry_type") or relation.get(
                        "entry_type"
                    )
                    parent_shorthand = relation.get("target") != "entry" and (
                        relation.get("mode") == "parent"
                        or relation.get("track") in {"self", "same"}
                    )
                    if parent_shorthand:
                        types = (
                            [related_type]
                            if isinstance(related_type, str) and related_type
                            else [str(item) for item in related_type or [] if item]
                        )
                        if types:
                            field = {
                                **field,
                                "relation": {
                                    "target": "entry",
                                    "target_entry_types": types,
                                    "allow_cross_track": False,
                                    "many": False,
                                },
                            }
                fields.append(field)
            normalized_types.append({**entry_type, "fields": fields})
        if "entry_types" in params:
            params["entry_types"] = normalized_types
    if tool == "integral_save_view":
        if "view_name" in params:
            params.setdefault("name", params.pop("view_name"))
        if "type" in params:
            params.setdefault("view_type", params.pop("type"))
        params.pop("decision", None)
        config = dict(params.get("config") or {})
        if config.get("name"):
            params.setdefault("name", config.pop("name"))
        if config.get("type"):
            params.setdefault("view_type", config.pop("type"))
        for alias in ("hierarchy_field", "parent"):
            alias_value = config.get(alias)
            if (
                isinstance(alias_value, str)
                and alias_value.strip()
                and not config.get("parent_field")
            ):
                config["parent_field"] = alias_value.strip()
                config.pop(alias, None)
        hint = str(
            config.pop("track_hint", "")
            or params.pop("track_hint", "")
            or params.pop("track_name", "")
            or ""
        ).strip()
        named = config.get("track")
        if (
            isinstance(named, str)
            and named.strip()
            and not named.startswith(("{{", "n."))
        ):
            hint = hint or named.strip()
            config.pop("track")
        if not params.get("track_id") and (hint or only_track_name):
            params["track_id"] = f"{{{{track.id:{hint or only_track_name}}}}}"
        mapping = params.pop("field_mapping", None)
        if mapping is not None:
            if params.get("view_type") != "wiki" or not isinstance(mapping, dict):
                raise ValueError("field_mapping is only supported for a Wiki view")
            for source, target in (
                ("parent", "parent_field"),
                ("title", "title_field"),
                ("body", "body_field"),
            ):
                if mapping.get(source) and not config.get(target):
                    config[target] = str(mapping[source])
        params["config"] = config
    if tool in {"integral_create_entry", "integral_create_tag"}:
        hint = ""
        for key in ("track_hint", "track_name"):
            raw = params.get(key)
            if isinstance(raw, str) and raw.strip():
                hint = raw.strip()
                params.pop(key, None)
                break
        track_id = str(params.get("track_id") or "").strip()
        if track_id and not (track_id.startswith("{{") or track_id.startswith("n.")):
            hint = hint or track_id
            track_id = ""
        if not track_id and (hint or only_track_name):
            params["track_id"] = f"{{{{track.id:{hint or only_track_name}}}}}"
    return {**item, "args": params}


def _name_in_proposal(name: str, proposal: str) -> bool:
    """True when ``name`` is its own token in the already-folded proposal."""
    folded = name.strip().casefold()
    if not folded:
        return False
    return re.search(rf"(?<![\w]){re.escape(folded)}(?![\w])", proposal) is not None


def _positively_requested(proposal: str, term: str) -> bool:
    """True when ``term`` is named and not negated nearby."""
    if re.search(
        rf"\b(?:no|without|not)\b.{{0,40}}\b{re.escape(term)}\b",
        proposal,
        re.IGNORECASE,
    ):
        return False
    return re.search(rf"\b{re.escape(term)}\b", proposal, re.IGNORECASE) is not None


def _named_seed_titles(proposal: str) -> list[str]:
    titles = []
    for match in re.finditer(r"\btitled\s+([^,.\n]+)", proposal, re.IGNORECASE):
        title = match.group(1).strip(" *\"'")
        if title:
            titles.append(title)
    return titles


def _explicitly_empty_design(proposal: str) -> bool:
    """True when the compiler must not invent Example records."""
    if _named_seed_titles(proposal):
        return True
    return bool(
        re.search(
            r"\b(no demo entries|without demo entries|leave (?:the )?track empty|no other entries|without other entries)\b",
            proposal,
            re.IGNORECASE,
        )
    )


def _existing_app_design(marker: Dict[str, Any]) -> bool:
    """Recognize the explicit target, including proposals saved before that field existed."""
    if marker.get("target_app_id"):
        return True
    summary = str(marker.get("summary") or "")
    proposal = str(marker.get("proposal") or "")
    return bool(
        re.search(r"^\s*add\b.*\btrack\b", summary, re.IGNORECASE)
        and re.search(r"\*\*New Track:\*\*", proposal, re.IGNORECASE)
    )


def _plan_binding_error(
    operations: list[tuple[str, Dict[str, Any]]],
    track_fields: Dict[str, list[Dict[str, Any]]],
    proposal: str,
) -> str | None:
    """Check requested Wiki views against the schema before staging writes."""
    wiki_views = 0
    for tool, params in operations:
        if tool != "integral_save_view" or params.get("view_type") != "wiki":
            continue
        wiki_views += 1
        track_ref = str(params.get("track_id") or "")
        fields = track_fields.get(track_ref)
        if fields is None:
            return f"Wiki view targets an undeclared Track: {track_ref}."
        config = params.get("config") or {}
        if not isinstance(config, dict):
            return "Wiki view config must be an object."
        parent = str(config.get("parent_field") or "").removeprefix("custom_fields.")
        if not any(
            isinstance(field, dict)
            and field.get("key") == parent
            and field.get("type") == "relation"
            for field in fields
        ):
            return "Wiki config.parent_field must name a relation field on its Track."
    if _positively_requested(proposal, "wiki") and not wiki_views:
        if len(track_fields) == 1:
            track_ref, fields = next(iter(track_fields.items()))
            parent = next(
                (
                    str(field.get("key"))
                    for field in fields
                    if isinstance(field, dict) and field.get("type") == "relation"
                ),
                "<relation-field-key>",
            )
            return (
                "The approved Wiki view is missing. Add integral_save_view "
                f"with track_id={track_ref!r}, name='Wiki', view_type='wiki', "
                f"config={{'parent_field': {parent!r}}}; retry this approved build "
                "now without asking the user again."
            )
        return (
            "The approved Wiki view is missing. Add integral_save_view with "
            "view_type='wiki' and config.parent_field; retry this approved "
            "build now without asking the user again."
        )
    return None


async def _resume_partial_design(
    marker: Dict[str, Any], *, principal_id: str, session_id: str
) -> ToolResult:
    """Resume the original approved batch using its durable cursor."""
    from app.agentive.services.staging_apply import execute_blessed_change
    from app.agentive.staging import StagingError, get_token
    from app.services.agent_scope import active_workspace_id
    from app.services.chat_threads import record_design_build_receipt

    token = str((marker.get("partial_build") or {}).get("batch_token") or "")
    staged = await get_token(token) if token else None
    workspace_id = active_workspace_id()
    if (
        staged is None
        or staged.kind != "batch"
        or staged.user_id != principal_id
        or staged.session_id != session_id
        or (workspace_id and staged.workspace_id != workspace_id)
    ):
        return _invalid(
            "partial_build_requires_repair",
            "The original approved batch is unavailable in this conversation and workspace. Do not create another App.",
        )
    if staged.state == "consumed":
        progress = staged.progress or {}
        total = len((staged.payload or {}).get("operations") or [])
        if (
            progress.get("completed") != total
            or len(progress.get("results") or []) != total
        ):
            return _invalid(
                "partial_build_requires_repair",
                "The applied batch has no complete durable cursor; inspect the existing App.",
            )
        execution = {"completed": total, "total": total, "results": progress["results"]}
    elif staged.state == "blessed":
        try:
            from app.services.scaffold_repair import apply_partial_revision

            staged = await apply_partial_revision(
                marker,
                staged,
                user_id=principal_id,
                session_id=session_id,
                workspace_id=workspace_id,
            )
            token = staged.token
            outcome = await execute_blessed_change(
                user_id=principal_id, token=token, staged=staged
            )
        except StagingError as exc:
            return _invalid(exc.code, str(exc))
        except (ValueError, RuntimeError) as exc:
            return _invalid("partial_build_requires_repair", str(exc))
        execution = outcome.get("execute_result") or {}
        if not outcome.get("consumed") or execution.get("error"):
            return ToolResult(
                is_error=True,
                error_code=str(execution.get("error_code") or "batch_apply_failed"),
                message=str(
                    execution.get("message") or "The unfinished batch could not apply."
                ),
                data={
                    "batch_token": token,
                    "completed": execution.get("completed"),
                    "total": execution.get("total"),
                },
            )
    else:
        return _invalid(
            "partial_build_requires_repair",
            "The original batch is no longer approved. Do not create another App.",
        )
    receipt = await record_design_build_receipt(
        session_id=session_id,
        user_id=principal_id,
        batch_token=token,
        execute_result=execution,
    )
    if not isinstance(receipt, dict):
        return _invalid(
            "build_receipt_unavailable",
            "The batch applied but its design receipt could not be recorded. Read current state before claiming completion.",
        )
    return ToolResult(
        data={
            "_kind": "batch_applied",
            "applied": True,
            "batch_token": token,
            "completed": execution.get("completed"),
            "total": execution.get("total"),
            "design_id": receipt.get("design_id"),
            "design_revision": receipt.get("design_revision"),
            "execution_receipt_id": receipt.get("id"),
            "next": "Call integral_verify_build with this receipt before claiming completion. Do not build again.",
        }
    )


async def build_approved_design(
    args: Dict[str, Any],
    *,
    principal_id: str,
    scope: Optional[str],
    session_id: Optional[str],
    interaction_id: Optional[str],
) -> ToolResult:
    """Stage a model-authored plan and commit its single affirmed batch.

    The plan is data, not authority. The conversation marker supplies the
    approval; every operation still goes through the published tool dispatcher
    and the existing batch executor applies each operation under policy.
    """
    if not session_id or not await design_chat_affirmed_for_build(session_id):
        pending = await get_thread_by_session(session_id) if session_id else None
        if getattr(pending, "design_proposed", None):
            return _invalid(
                "design_approval_required",
                "A saved design must be affirmed in this conversation before building.",
            )
        return ToolResult(
            is_error=True,
            error_code="design_approval_required",
            message=(
                "No design is saved in this conversation yet. Save it with "
                "integral_propose_design and show it to the user; build only "
                "after they confirm."
            ),
            next_tool="integral_propose_design",
        )
    thread = await get_thread_by_session(session_id)
    marker = getattr(thread, "design_proposed", None) or {}
    if isinstance(marker, dict) and marker.get("build_receipt"):
        return _invalid(
            "design_already_applied",
            "This approved design already has an applied build receipt.",
        )
    if not isinstance(marker, dict) or not marker.get("approved"):
        return _invalid("design_approval_required", "The design is not approved.")
    if getattr(thread, "user_id", None) != principal_id:
        return _invalid("design_owner_mismatch", "The design belongs to another user.")
    if marker.get("partial_build"):
        return await _resume_partial_design(
            marker, principal_id=principal_id, session_id=session_id
        )
    existing_batch = peek_open_batch(principal_id, session_id)
    if existing_batch and existing_batch.get("op_count"):
        return _invalid(
            "scaffold_batch_already_open",
            "An unfinished scaffold batch already exists; resume or cancel it first.",
        )

    raw_operations = args.get("operations")
    if isinstance(raw_operations, list):
        # The resident sometimes includes the manual-batch terminator in a
        # one-call plan. This tool commits itself; a terminal control step is
        # redundant, not a second mutation or a reason to abandon the design.
        raw_operations = list(raw_operations)
        if raw_operations and isinstance(raw_operations[-1], dict):
            if raw_operations[-1].get("tool") == "integral_commit_batch":
                raw_operations.pop()
        try:
            track_names = {
                str(
                    (item.get("args") or {}).get("name")
                    or (item.get("args") or {}).get("track_name")
                    or ""
                ).strip()
                for item in raw_operations
                if isinstance(item, dict)
                and item.get("tool") == "integral_create_app_track"
                and isinstance(item.get("args"), dict)
            }
            track_names.discard("")
            only_track_name = next(iter(track_names)) if len(track_names) == 1 else ""
            plan_track_types = {
                str(item["args"].get("name") or item["args"].get("track_name"))
                .strip()
                .casefold(): [
                    str(t.get("name") or t.get("key"))
                    for t in item["args"].get("entry_types") or []
                    if isinstance(t, dict) and (t.get("name") or t.get("key"))
                ]
                for item in raw_operations
                if isinstance(item, dict)
                and item.get("tool") == "integral_create_app_track"
                and isinstance(item.get("args"), dict)
            }
            raw_operations = [
                _approved_plan_item(
                    item,
                    only_track_name=only_track_name,
                    plan_track_types=plan_track_types,
                )
                for item in raw_operations
            ]
            raw_operations = _coalesce_plan_operations(raw_operations)
            raw_operations = _annotate_plan_cross_track_relations(raw_operations)
            # Templates only register; hoisting them behind the first op keeps
            # every anchoring Track after the template it names.
            templates = [
                item
                for item in raw_operations[1:]
                if isinstance(item, dict)
                and item.get("tool") == "integral_register_track_template"
            ]
            if templates:
                raw_operations = [
                    raw_operations[0],
                    *templates,
                    *(i for i in raw_operations[1:] if i not in templates),
                ]
        except ValueError as exc:
            return _invalid("invalid_scaffold_plan", str(exc))
    if (
        not isinstance(raw_operations, list)
        or not 1 <= len(raw_operations) <= _MAX_OPERATIONS
    ):
        return _invalid(
            "invalid_scaffold_plan",
            f"Supply 1 to {_MAX_OPERATIONS} ordered scaffold operations.",
        )
    proposal = str(marker.get("proposal") or "").casefold()
    if not proposal:
        return _invalid("invalid_scaffold_plan", "The approved design has no preview.")
    # A typed blueprint replaces every prose heuristic below with a
    # structural comparison (plan_fidelity_errors) after expansion.
    blueprint = (
        marker.get("blueprint") if isinstance(marker.get("blueprint"), dict) else None
    )
    if blueprint:
        # Planners echo the blueprint's item ids into batch refs; refs resolve
        # by Track name, so ``{{track.id:track.jobs}}`` becomes ``…:Jobs}}``.
        id_refs = {
            f"{{{{track.id:{t['id']}}}}}": f"{{{{track.id:{t['name']}}}}}"
            for t in blueprint.get("tracks") or []
            if t.get("id") and t.get("name") and t["id"] != t["name"]
        }
        raw_operations = [
            (
                {
                    **item,
                    "args": {
                        **item["args"],
                        "track_id": id_refs[item["args"]["track_id"]],
                    },
                }
                if isinstance(item, dict)
                and isinstance(item.get("args"), dict)
                and item["args"].get("track_id") in id_refs
                else item
            )
            for item in raw_operations
        ]
    first = raw_operations[0]
    first_tool = first.get("tool") if isinstance(first, dict) else None
    target_app_id = str(args.get("target_app_id") or "").strip()
    if not target_app_id and first_tool == "integral_create_app_track":
        first_args = first.get("args") or {}
        if isinstance(first_args, dict):
            target_app_id = str(first_args.get("app_id") or "").strip()
    approved_target = str(marker.get("target_app_id") or "").strip()
    if _existing_app_design(marker) and first_tool == "integral_create_app":
        return _invalid(
            "plan_differs_from_design",
            "The approved design adds a Track to an existing App; do not create another App. Use its real app_id.",
        )
    if approved_target and target_app_id != approved_target:
        return _invalid(
            "plan_differs_from_design",
            "The build target differs from the App in the approved design.",
        )
    existing_app = None
    if target_app_id:
        from app.models.nodes import App
        from app.services.permissions import can_admin_app

        if first_tool != "integral_create_app_track":
            return _invalid(
                "invalid_scaffold_plan",
                "An existing-App plan must start with integral_create_app_track, not create another App.",
            )
        if target_app_id.startswith("{{"):
            return _invalid(
                "invalid_scaffold_plan",
                "An existing-App plan needs the real app_id from integral_list_apps, not {{app.id}}.",
            )
        existing_app = await App.get(target_app_id)
        if existing_app is None or existing_app.workspace_id != scope:
            return _invalid(
                "target_app_unavailable",
                "The target App is not in the active workspace.",
            )
        if not await can_admin_app(principal_id, target_app_id):
            return _invalid(
                "target_app_forbidden", "You cannot configure the target App."
            )
        if (
            blueprint["app"]["name"].casefold() != existing_app.name.casefold()
            if blueprint
            else not _name_in_proposal(existing_app.name, proposal)
        ):
            return _invalid(
                "plan_differs_from_design",
                "The target App name is absent from the approved preview.",
            )
    elif first_tool != "integral_create_app":
        return _invalid(
            "invalid_scaffold_plan",
            "Start a new-App plan with integral_create_app, or provide the real app_id on the first integral_create_app_track for an existing App.",
        )
    if (
        existing_app is None
        and len(raw_operations) < 2
        and not (blueprint is not None and not blueprint["tracks"])
    ):
        return _invalid(
            "invalid_scaffold_plan",
            "A new App plan needs an App and at least one Track.",
        )
    operations = []
    required_fields = {} if blueprint else _approved_field_requirements(marker)
    track_fields: Dict[str, list[Dict[str, Any]]] = {}
    track_tags: Dict[str, set[str]] = {}
    template_keys: set[str] = set()
    anchor_fields: Dict[str, set[str]] = {}
    seed_titles = {
        str(item.get("args", {}).get("title") or "")
        .strip()
        .casefold(): str(item.get("args", {}).get("title") or "")
        .strip()
        for item in raw_operations
        if isinstance(item, dict)
        and item.get("tool") == "integral_create_entry"
        and isinstance(item.get("args"), dict)
    }
    missing_titles = [
        title
        for title in (
            [] if blueprint else _named_seed_titles(str(marker.get("proposal") or ""))
        )
        if title.casefold() not in seed_titles
    ]
    if missing_titles:
        listed = ", ".join(missing_titles)
        return _invalid(
            "plan_differs_from_design",
            "The approved design names entries missing from the plan: "
            f"{listed}. Add integral_create_entry with those exact titles and "
            "structured fields. Do not add Example records. Retry this approved "
            "build now without asking the user again.",
        )
    explicit_view_tracks = {
        str(item.get("args", {}).get("track_id"))
        for item in raw_operations
        if isinstance(item, dict)
        and item.get("tool") == "integral_save_view"
        and isinstance(item.get("args"), dict)
    }
    track_count = 0
    for index, item in enumerate(raw_operations):
        # `depends_on` is explanatory planner metadata. The actual ordered
        # payload references are still checked by validate_batch_references.
        if (
            not isinstance(item, dict)
            or not {"tool", "args"} <= set(item)
            or (set(item) - {"tool", "args"} not in (set(), {"depends_on"}))
        ):
            return _invalid(
                "invalid_scaffold_plan",
                f"Operation {index + 1} must have tool and args (optional depends_on).",
            )
        tool = item["tool"]
        params = item["args"]
        if tool not in _PLAN_TOOLS or not isinstance(params, dict):
            hint = (
                " For an App Track, use integral_create_app_track with inline entry_types."
                if tool == "integral_author_model"
                else " Allowed writes: " + ", ".join(sorted(_PLAN_TOOLS)) + "."
            )
            return _invalid(
                "invalid_scaffold_plan",
                f"Operation {index + 1} ({tool}) is not an allowed scaffold write.{hint}",
            )
        if {"user_id", "principal_id", "workspace_id"} & set(params):
            return _invalid(
                "invalid_scaffold_plan",
                f"Operation {index + 1} contains identity or scope arguments.",
            )
        if index == 0 and tool != (
            "integral_create_app_track" if existing_app else "integral_create_app"
        ):
            return _invalid(
                "invalid_scaffold_plan",
                "The first operation does not match the approved App build mode.",
            )
        if index > 0 and tool == "integral_create_app":
            return _invalid(
                "invalid_scaffold_plan", "One design can create only one App."
            )
        if tool == "integral_register_track_template":
            expected_app_id = target_app_id if existing_app else "{{app.id}}"
            if params.get("app_id") != expected_app_id:
                return _invalid(
                    "invalid_scaffold_plan",
                    f"Track templates in this plan must use app_id={expected_app_id}.",
                )
        if tool in {
            "integral_create_app",
            "integral_create_app_track",
            "integral_register_track_template",
        }:
            name = str(params.get("name") or "").strip()
            if not name or (not blueprint and not _name_in_proposal(name, proposal)):
                return _invalid(
                    "plan_differs_from_design",
                    f"Operation {index + 1} names an App or Track absent from the approved preview.",
                )
            if tool == "integral_create_app_track":
                track_count += 1
                missing_fields = sorted(
                    required_fields.get(name.casefold(), set())
                    - _track_declared_field_names(params)
                )
                if missing_fields:
                    return _invalid(
                        "plan_differs_from_design",
                        f"Track {name!r} omits approved fields: {', '.join(missing_fields)}.",
                    )
                expected_app_id = target_app_id if existing_app else "{{app.id}}"
                if params.get("app_id") != expected_app_id:
                    return _invalid(
                        "invalid_scaffold_plan",
                        f"Tracks in this plan must use app_id={expected_app_id}.",
                    )
                if not params.get("entry_types") and not params.get("fields"):
                    return _invalid(
                        "invalid_scaffold_plan",
                        f"Track {name!r} needs inline entry_types or fields.",
                    )
                for entry_type in params.get("entry_types") or []:
                    for field in (
                        (entry_type.get("fields") or [])
                        if isinstance(entry_type, dict)
                        else []
                    ):
                        if isinstance(field, dict) and field.get("type") == "relation":
                            relation = field.get("relation") or {}
                            if isinstance(relation, dict) and {
                                "track",
                                "entry_type",
                            } & set(relation):
                                return _invalid(
                                    "invalid_scaffold_plan",
                                    "Relation fields use relation.target='entry' and relation.target_entry_types, not relation.track or relation.entry_type.",
                                )
        params = normalize_relative_date(params)
        try:
            if tool == "integral_create_app_track":
                track_ref = f"{{{{track.id:{params['name']}}}}}"
                track_fields[track_ref] = list(params.get("fields") or []) + [
                    field
                    for entry_type in params.get("entry_types") or []
                    if isinstance(entry_type, dict)
                    for field in entry_type.get("fields") or []
                ]
                if params.get("taxonomy") is not None:
                    params = {
                        **params,
                        "taxonomy": {
                            "tag_groups": normalize_inline_taxonomy(params["taxonomy"])
                        },
                    }
                track_tags[track_ref] = {
                    tag["name"].casefold()
                    for group in (params.get("taxonomy") or {}).get("tag_groups") or []
                    for tag in group["tags"]
                }
                anchored_types = []
                for entry_type in params.get("entry_types") or []:
                    if not isinstance(entry_type, dict):
                        anchored_types.append(entry_type)
                        continue
                    fields = []
                    for field in entry_type.get("fields") or []:
                        relation = (
                            field.get("relation") if isinstance(field, dict) else None
                        )
                        if (
                            isinstance(relation, dict)
                            and relation.get("target") == "track"
                        ):
                            template = str(relation.get("target_track_template") or "")
                            if template not in template_keys:
                                raise ValueError(
                                    f"field {field.get('key')!r} anchors to track "
                                    f"template {template!r}, which no earlier "
                                    "integral_register_track_template registers. "
                                    "To link to a record in another Track, use "
                                    "relation.target='entry' with "
                                    "target_entry_types, as in the approved design"
                                )
                            if relation.get("auto_provision") is False:
                                raise ValueError(
                                    f"field {field.get('key')!r} must auto-provision "
                                    "its detail Track"
                                )
                            field = {
                                **field,
                                "relation": {**relation, "auto_provision": True},
                            }
                            anchor_fields.setdefault(track_ref, set()).add(
                                str(field.get("key") or "")
                            )
                        fields.append(field)
                    anchored_types.append({**entry_type, "fields": fields})
                if params.get("entry_types"):
                    params = {**params, "entry_types": anchored_types}
                operations.extend(
                    _expand_track(
                        params,
                        include_default_view=(
                            not blueprint
                            and _positively_requested(proposal, "table")
                            and track_ref not in explicit_view_tracks
                        ),
                    )
                )
            elif tool == "integral_save_view":
                operations.append((tool, _normalize_view(params)))
            elif tool == "integral_create_dashboard":
                operations.append((tool, _normalize_dashboard(params)))
            elif tool == "integral_author_skill" and blueprint:
                # The approved visibility decides scope, not the planner, and
                # the approved purpose stands in for an omitted description.
                approved = next(
                    (
                        s
                        for s in blueprint.get("skills") or []
                        if s["name"].casefold()
                        == str(params.get("name") or "").casefold()
                    ),
                    None,
                )
                if approved:
                    params = {
                        **params,
                        "description": params.get("description") or approved["purpose"],
                        "app_id": target_app_id if existing_app else "{{app.id}}",
                        "private": approved.get("visibility") != "workspace",
                    }
                operations.append((tool, params))
            elif tool == "integral_create_tag":
                track_ref = str(params.get("track_id") or "")
                if params.get("app_id") or track_ref not in track_tags:
                    raise ValueError(
                        "a tag must target a Track created earlier in this plan "
                        "with track_id='{{track.id:<Track name>}}'"
                    )
                track_tags[track_ref].add(str(params.get("name") or "").casefold())
                operations.append((tool, params))
            elif tool == "integral_register_track_template":
                key = slug_manifest_key(str(params["name"]))
                if key in template_keys:
                    raise ValueError(f"track template {params['name']!r} is repeated")
                if not params.get("entry_types"):
                    raise ValueError("a track template needs inline entry_types")
                template_keys.add(key)
                operations.append((tool, params))
            elif tool == "integral_create_entry":
                track_ref = str(params.get("track_id") or "")
                preset = anchor_fields.get(track_ref, set()) & set(
                    params.get("fields") or {}
                )
                if preset:
                    raise ValueError(
                        f"seed {params.get('title')!r} sets anchored field(s) "
                        f"{', '.join(sorted(preset))}; each detail Track is created "
                        "with its entry, so leave them out"
                    )
                undeclared = [
                    str(tag)
                    for tag in params.get("tags") or []
                    if _tag_ref_name(str(tag)).casefold()
                    not in track_tags.get(track_ref, set())
                ]
                if undeclared:
                    raise ValueError(
                        f"seed {params.get('title')!r} uses tags its Track does not "
                        f"declare earlier in this plan: {', '.join(undeclared)}"
                    )
                operations.append(
                    (tool, _structured_seed(params, track_fields, seed_titles))
                )
            else:
                operations.append((tool, params))
        except (KeyError, TypeError, ValueError) as exc:
            return _invalid("invalid_scaffold_plan", f"Operation {index + 1}: {exc}")
    if track_count < 1 and not (blueprint is not None and not blueprint["tracks"]):
        return _invalid(
            "invalid_scaffold_plan", "The plan needs at least one shaped Track."
        )
    binding_error = _plan_binding_error(
        operations, track_fields, "" if blueprint else proposal
    )
    if binding_error:
        return _invalid("plan_differs_from_design", binding_error)
    if blueprint:
        from app.services.design_blueprint import plan_fidelity_errors

        fidelity = plan_fidelity_errors(
            blueprint, operations, new_app=existing_app is None
        )
        if fidelity:
            return _invalid(
                "plan_differs_from_design",
                " ".join(fidelity)
                + " Correct the generated operation plan to match the saved "
                "approved blueprint; remove unapproved additions and restore "
                "omitted approved items. This is plan repair, not a request to "
                "re-approve the unchanged design.",
            )
    # Each Track this plan creates opens on its most useful specific view, not
    # the substrate Feed: the design's choice, else the plan's, else the first
    # non-feed view. Existing Tracks change default only when asked.
    design_defaults = set()
    if blueprint:
        blueprint_tracks = {
            t["id"]: t["name"].casefold() for t in blueprint.get("tracks") or []
        }
        design_defaults = {
            (blueprint_tracks.get(v["track"], ""), v["name"].casefold())
            for v in blueprint.get("views") or []
            if v.get("is_default")
        }
    views_by_track: Dict[str, list] = {}
    for tool, params in operations:
        if tool == "integral_save_view":
            views_by_track.setdefault(str(params.get("track_id") or ""), []).append(
                params
            )
    for track_ref, views in views_by_track.items():
        planned_track = track_ref.startswith("{{track.id:")
        track_name = track_ref.removeprefix("{{track.id:").removesuffix("}}")
        chosen = next(
            (
                v
                for v in views
                if (track_name.casefold(), str(v.get("name") or "").casefold())
                in design_defaults
            ),
            None,
        ) or next((v for v in views if v.get("is_default")), None)
        if chosen is None and planned_track:
            chosen = next((v for v in views if v.get("view_type") != "feed"), None)
        for view in views:
            view["is_default"] = view is chosen
    if (
        not blueprint
        and _positively_requested(proposal, "dashboard")
        and not any(tool == "integral_create_dashboard" for tool, _ in operations)
    ):
        app_name = (
            existing_app.name
            if existing_app
            else str(operations[0][1].get("name") or "App")
        )
        generated_dashboard = _dashboard_from_date_views(operations, app_name)
        if existing_app:
            generated_dashboard["app_id"] = target_app_id
        if "overdue" in proposal and not generated_dashboard["widgets"]:
            return _invalid(
                "plan_differs_from_design",
                "The approved overdue dashboard needs date-filtered views or explicit widgets.",
            )
        operations.append(
            (
                "integral_create_dashboard",
                generated_dashboard,
            )
        )
    if len(operations) > _MAX_OPERATIONS:
        return _invalid("invalid_scaffold_plan", "Expanded plan exceeds 64 writes.")

    _reconcile_scaffold_name_fields(operations)

    # A member field points to a real workspace User, never to a seed Entry.
    # Check it before any write: the batch executor is not transactional and a
    # bad late seed would otherwise strand a partial App.
    from app.services.operational_model_member_field import validate_member_value

    for tool, params in operations:
        if tool != "integral_create_entry":
            continue
        specs = track_fields.get(str(params.get("track_id") or "")) or []
        fields = params.get("fields") or {}
        if not isinstance(fields, dict):
            continue
        for spec in specs:
            if not isinstance(spec, dict) or spec.get("type") != "member":
                continue
            field_key = str(spec.get("key") or "")
            value = fields.get(field_key, fields.get(str(spec.get("name") or "")))
            if value is None:
                continue
            # Agents see the caller's auth id; the member field stores the graph User id.
            from app.services.permissions import get_user_node

            user = await get_user_node(
                principal_id if value == "{{user.id}}" else str(value)
            )
            if user is not None:
                value = user.id
                fields[field_key if field_key in fields else spec["name"]] = value
            if not scope:
                return _invalid(
                    "invalid_scaffold_plan", "A member seed needs workspace scope."
                )
            if str(value).startswith("{{entry.id:"):
                return _invalid(
                    "invalid_scaffold_plan",
                    f"Member field {field_key!r} cannot point to a planned Entry; use a relation field.",
                )
            try:
                await validate_member_value(
                    value,
                    field_key=field_key,
                    source_track=SimpleNamespace(workspace_id=scope),
                )
            except Exception as exc:
                return _invalid(
                    "invalid_scaffold_plan",
                    f"Member seed {field_key!r} is invalid before build: {exc}",
                )

    # Validate dashboard data sources before opening a batch. Dashboard CRUD
    # applies late in the executor; an invalid filter must not leave a partial
    # App, Tracks and entries behind.
    from app.schemas.dashboards import DataSourceSpec

    for tool, params in operations:
        if tool != "integral_create_dashboard":
            continue
        for widget in params.get("widgets") or []:
            try:
                DataSourceSpec.model_validate(widget.get("data_source") or {})
            except Exception as exc:
                return _invalid(
                    "invalid_scaffold_plan",
                    f"Dashboard {widget.get('title') or widget.get('name') or 'widget'} has an invalid data source: {exc}",
                )

    # Import here to avoid a module import cycle with dispatch._dispatch_propose.
    from app.agentive.tooling.dispatch import _dispatch_batch_control, dispatch_tool

    await open_batch(
        user_id=principal_id,
        session_id=session_id,
        label=str(marker.get("summary") or "Build app"),
    )
    for index, (tool, params) in enumerate(operations):
        result = await dispatch_tool(
            tool,
            params,
            principal_id=principal_id,
            scope=scope,
            session_id=session_id,
            interaction_id=interaction_id,
        )
        if (
            result.is_error
            or not isinstance(result.data, dict)
            or not result.data.get("batched")
        ):
            await cancel_batch(user_id=principal_id, session_id=session_id)
            # Only a refusal the model can repair is retried; approval,
            # permission, and policy refusals need the user.
            return _invalid(
                (
                    "scaffold_plan_validation_failed"
                    if result.error_code == "invalid_arguments"
                    else (
                        "scaffold_plan_refused"
                        if result.is_error and not result.next_tool
                        else "scaffold_plan_stage_failed"
                    )
                ),
                f"Operation {index + 1} ({tool}) was refused: "
                + (
                    ": ".join(filter(None, [result.error_code, result.message]))
                    or str(result.data)
                ),
            )

    committed = await _dispatch_batch_control(
        "integral_commit_batch",
        {
            "summary": str(marker.get("summary") or "Build app"),
            "allow_empty": (
                not blueprint.get("seeds")
                if blueprint
                else _explicitly_empty_design(proposal)
            ),
        },
        principal_id=principal_id,
        scope=scope,
        session_id=session_id,
        interaction_id=interaction_id,
        approved_extension=existing_app is not None,
    )
    if committed.is_error:
        # An incomplete plan has not written anything; allow a corrected plan
        # to retry from a clean batch. Applied/partial executor outcomes retain
        # their own durable receipt and are not erased here.
        if is_batch_open(principal_id, session_id):
            await cancel_batch(user_id=principal_id, session_id=session_id)
        if committed.error_code == "batch_partial_failure":
            partial_data = committed.data if isinstance(committed.data, dict) else {}
            await record_design_partial_build(
                session_id=session_id,
                user_id=principal_id,
                batch_token=str(partial_data.get("batch_token") or ""),
            )
        return committed
    data = committed.data if isinstance(committed.data, dict) else {}
    if data.get("_kind") != "batch_applied" or data.get("applied") is not True:
        # A partial executor outcome must be an error to the resident. The
        # previous successful envelope let it narrate an unfinished App as
        # verified while dashboard creation had failed.
        execution = data.get("execute_result") or {}
        if not isinstance(execution, dict):
            execution = {}
        failures = [
            item
            for item in execution.get("results") or []
            if isinstance(item, dict)
            and isinstance(item.get("result"), dict)
            and item["result"].get("error")
        ]
        await record_design_partial_build(
            session_id=session_id,
            user_id=principal_id,
            batch_token=str(data.get("token") or ""),
        )
        return ToolResult(
            data={
                "_kind": "batch_apply_failed",
                "applied": False,
                "batch_token": data.get("token"),
                "completed": execution.get("completed"),
                "total": execution.get("total"),
                "failed_step": failures[-1] if failures else None,
                "next": "Partial writes may exist. Inspect the existing App and repair only the failed remainder; do not create a second App or claim completion.",
            },
            is_error=True,
            error_code=str(execution.get("error_code") or "batch_apply_failed"),
            message=str(execution.get("message") or "Batch did not fully apply."),
        )
    executed = data.get("execute_result") or {}
    applied = {
        "_kind": "batch_applied",
        "applied": True,
        "batch_token": data.get("token"),
        "completed": executed.get("completed"),
        "total": executed.get("total"),
        "design_id": data.get("design_id"),
        "design_revision": data.get("design_revision"),
        "execution_receipt_id": data.get("execution_receipt_id"),
        "next": (
            "Call integral_verify_build now with the design_id, design_revision, "
            "and execution_receipt_id in this result. It only reads; do not build "
            "again. Use its reply field as the closing line, word for word. "
            "If status is not verified, do not open with a completion claim. "
            "Do not list field keys, view types or ids, do not ask for approval "
            "again, and do not end on the system marker."
        ),
    }
    if blueprint:
        applied["blueprint_revision"] = marker.get("blueprint_revision")
        applied["blueprint_digest"] = marker.get("blueprint_digest")
        # Operations that need a trusted package are never built here (W1.7).
        applied["not_built"] = [op["id"] for op in blueprint.get("operations") or []]
    return ToolResult(data=applied)
