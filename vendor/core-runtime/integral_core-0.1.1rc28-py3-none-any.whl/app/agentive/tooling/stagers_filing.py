"""File-content fused stager: resolve hints, then stage or refuse.

``integral_file_content`` stages one entry for user approval. The agent/skill
supplies ``track_id`` or ``track_hint``, ``type_hint``, ``title``, and
``fields`` from ``integral_list_tracks`` + ``integral_get_track_schema``.
This stager performs mechanical resolution and field-key normalization only.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple


def _norm_key(s: str) -> str:
    """Compare the schema's own keys and display names, without semantic guesses."""
    return "".join(c for c in s.casefold() if c.isalnum())


def _normalize_agent_fields(
    agent_fields: Dict[str, Any],
    form_schema: Dict[str, Any],
) -> Dict[str, Any]:
    """Map schema-declared names only; refuse unknown or ambiguous data loss.

    Exact stable keys take precedence. Normalized key/name matching is allowed
    only when it identifies one field. Explicit null/empty values are retained
    for the canonical validator to interpret, not silently discarded.
    """
    fields_spec = form_schema.get("fields", []) if isinstance(form_schema, dict) else []
    exact = {str(f["key"]) for f in fields_spec if isinstance(f, dict) and f.get("key")}
    candidates: Dict[str, set[str]] = {}
    for f in fields_spec:
        if not isinstance(f, dict) or not f.get("key"):
            continue
        key = str(f["key"])
        for label in (key, str(f.get("name") or "")):
            if label:
                candidates.setdefault(_norm_key(label), set()).add(key)

    out: Dict[str, Any] = {}
    for raw_key, value in agent_fields.items():
        if raw_key in exact:
            key = raw_key
        else:
            matches = candidates.get(_norm_key(raw_key), set())
            if len(matches) != 1:
                reason = "ambiguous" if matches else "unknown"
                raise ValueError(
                    f"Field {raw_key!r} is {reason}. Use a stable schema key: "
                    + ", ".join(sorted(exact))
                )
            key = next(iter(matches))
        if key in out:
            raise ValueError(
                f"Multiple supplied fields map to {key!r}; supply it once."
            )
        out[key] = value
    return out


def _missing_required_fields(
    schema: Dict[str, Any],
    fields: Dict[str, Any],
) -> List[Tuple[str, str]]:
    """``[(key, display_name), ...]`` for required fields neither supplied
    nor defaulted.

    ``operational_model_entry_fields.py`` (the actual create-time validator)
    falls back to ``field.default`` when a required field is omitted — a
    field with a default is satisfied either way, so only a required field
    with NO default and no supplied value is genuinely blocking. Checked
    here, before staging, so a create with a real gap (e.g. Pay run's
    ``frequency``, which has no default) surfaces one clear, actionable
    message instead of: stage → bless → execute-time failure → the create/
    drop-field retry dance in staging_executors.py futilely dropping the
    one field that can never be fixed by dropping it.
    """
    missing: List[Tuple[str, str]] = []
    for f in schema.get("fields", []) if isinstance(schema, dict) else []:
        if not isinstance(f, dict) or not f.get("required"):
            continue
        if f.get("default") is not None:
            continue
        key = str(f.get("key") or "")
        if not key or key in fields:
            continue
        missing.append((key, str(f.get("name") or key)))
    return missing


def _derive_title(text: str, *, limit: int = 80) -> str:
    """First non-empty line, trimmed and capped at ``limit`` chars."""
    for line in text.splitlines():
        candidate = line.strip()
        if candidate:
            return (
                candidate if len(candidate) <= limit else candidate[: limit - 1] + "…"
            )
    return "Untitled note"


def _format_fields_for_diff(fields: Dict[str, Any]) -> List[str]:
    """Return one-line-per-field markdown for the diff_human."""
    out: List[str] = []
    for k, v in fields.items():
        if isinstance(v, dict) and v.get("_raw") is not None:
            out.append(f"  - `{k}` = `{v['_raw']}` *(needs refinement)*")
        else:
            rendered = repr(v) if not isinstance(v, str) else v
            if len(rendered) > 60:
                rendered = rendered[:59] + "…"
            out.append(f"  - `{k}` = {rendered}")
    return out


def _filing_diff_human(
    *,
    track_title: str,
    entry_type_name: Optional[str],
    title: str,
    body_snippet: str,
    fields: Dict[str, Any],
    tags: List[Dict[str, Any]],
) -> str:
    """Render the human-readable filing diff (markdown)."""
    lines = [f"**File content** to *{track_title}*", "", f"- **Title:** {title}"]
    if entry_type_name:
        lines.append(f"- **Type:** {entry_type_name}")
    else:
        lines.append("- **Type:** *(not specified)*")
    if tags:
        rendered = ", ".join(f"`{t.get('name', '?')}`" for t in tags)
        lines.append(f"- **Tags:** {rendered}")
    if fields:
        lines.append("- **Fields:**")
        lines.extend(_format_fields_for_diff(fields))
    if body_snippet:
        lines.append("")
        lines.append(f"> {body_snippet}")
    return "\n".join(lines)


def _no_stage_candidates(
    *,
    message: str,
    filing_status: str = "unresolved",
    resolved_track: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "_kind": "filing_candidates",
        "filing_status": filing_status,
        "message": message,
    }
    if filing_status == "error":
        data["error"] = True
    if resolved_track:
        data["resolved_track"] = resolved_track
    return {"_no_stage": True, "data": data}


async def _stage_existing_entry(
    a: Dict[str, Any], *, mode: str, text: str
) -> Dict[str, Any]:
    """Stage an update or append against one existing entry. One facet, one card."""
    from app.models.nodes import Entry

    entry_id = str(a.get("entry_id") or "").strip()
    if not entry_id:
        return _no_stage_candidates(
            message="entry_id is required when mode is update or append.",
            filing_status="error",
        )
    if (
        a.get("expected_record_revision") is None
        or a.get("expected_schema_revision") is None
    ):
        return _no_stage_candidates(
            message=(
                "expected_record_revision and expected_schema_revision are "
                "required so a retry cannot apply a stale write."
            ),
            filing_status="error",
        )
    if mode == "append" and not str(a.get("append_field") or "").strip():
        return _no_stage_candidates(
            message="append_field is required when mode is append.",
            filing_status="error",
        )
    if mode == "append" and not text:
        return _no_stage_candidates(
            message="text is required — it is the passage appended once.",
            filing_status="error",
        )
    entry = await Entry.get(entry_id)
    if entry is None:
        return _no_stage_candidates(
            message=f"No entry {entry_id!r}.",
            filing_status="error",
        )
    fields = a.get("fields") if isinstance(a.get("fields"), dict) else None
    relations = a.get("relations") if isinstance(a.get("relations"), list) else None
    payload: Dict[str, Any] = {
        "mode": mode,
        "entry_id": entry.id,
        "track_id": entry.track_id,
        "text": text,
        "title": (a.get("title") or "").strip() or None,
        "fields": fields,
        "tags": a.get("tags"),
        "relations": relations,
        "append_field": a.get("append_field"),
        "expected_record_revision": a.get("expected_record_revision"),
        "expected_schema_revision": a.get("expected_schema_revision"),
        "idempotency_key": a.get("idempotency_key"),
        "entry_type_key": a.get("entry_type_key") or a.get("type_hint"),
        "replace_body": bool(a.get("replace_body")),
    }
    verb = "Append to" if mode == "append" else "Update"
    summary = f"{verb} “{entry.title or entry.id}”"
    lines = [f"**{verb}** *{entry.title or entry.id}*", ""]
    if fields:
        lines.append("- **Fields:**")
        lines.extend(_format_fields_for_diff(fields))
    if relations:
        lines.append(f"- **Links:** {len(relations)}")
    if a.get("tags") is not None:
        lines.append(f"- **Tags:** {a.get('tags')}")
    if mode == "append":
        lines.append(f"- **Append `{payload['append_field']}`:** {text}")
    return {
        "kind": "file_content",
        "summary": summary,
        "diff_human": "\n".join(lines),
        "diff_machine": {"op": "file_content", "filing_status": "resolved", **payload},
        "payload": payload,
    }


# --------------------------------------------------------------------------- #
# The stager
# --------------------------------------------------------------------------- #
async def stage_file_content(a: Dict[str, Any]) -> Dict[str, Any]:
    """Stage a ``file_content`` change when track + entry type resolve from hints."""
    from app.agentive.personalization import get_filing_defaults
    from app.agentive.tooling.bindings import (
        _bound_propose_principal,
        is_cleanup_instruction,
    )
    from app.services.filing_resolution import (
        resolve_entry_type_for_track,
        resolve_track_for_filing,
    )

    text = (a.get("text") or "").strip()
    fields_in = a.get("fields")
    if not text and isinstance(fields_in, dict):
        # Common agent mistake: the free-text body nested under `fields` (it
        # reads like a domain field named "text") instead of passed as the
        # top-level `text` param the schema actually requires. Recover it
        # rather than fail the whole card — and drop it from `fields` so it
        # isn't also offered to entry-type field normalization below.
        stray = fields_in.get("text")
        if isinstance(stray, str) and stray.strip():
            text = stray.strip()
            fields_in = {k: v for k, v in fields_in.items() if k != "text"}
            a = {**a, "fields": fields_in}
    if not text and str(a.get("mode") or "create").strip().lower() == "create":
        return _no_stage_candidates(
            message=(
                "text is required — pass the entry's freeform content as the "
                "top-level `text` param, not nested inside `fields`."
            ),
            filing_status="error",
        )

    mode = str(a.get("mode") or "create").strip().lower()
    if mode in ("update", "append"):
        return await _stage_existing_entry(a, mode=mode, text=text)

    title = str(a.get("title") or "")
    if is_cleanup_instruction(text) or is_cleanup_instruction(title):
        return _no_stage_candidates(
            message=(
                "This is a cleanup instruction, not content to file. Query "
                "the matching entries and stage integral_delete_entry or "
                "integral_update_entry. Nothing was staged."
            ),
            filing_status="error",
        )

    uid = _bound_propose_principal()
    defaults: Dict[str, Any] = {}
    try:
        learned = await get_filing_defaults(user_id=uid, text=text)
        defaults = learned or {}
    except Exception:  # noqa: BLE001 — personalization is best-effort
        defaults = {}

    track_id = a.get("track_id") or defaults.get("track_id")
    track_hint = a.get("track_hint")
    focused = a.get("focused_track_id")
    type_hint = (
        a.get("type_hint") or a.get("entry_type") or defaults.get("entry_type_name")
    )

    track = await resolve_track_for_filing(
        uid,
        track_id=track_id,
        track_hint=track_hint,
        focused_track_id=focused,
    )
    if not track:
        return _no_stage_candidates(
            message=(
                "Could not resolve a track. Call integral_list_tracks and supply "
                "track_id or track_hint before staging."
            ),
        )

    if not type_hint or not str(type_hint).strip():
        return _no_stage_candidates(
            message=(
                "Entry type required. Call integral_get_track_schema and supply "
                "type_hint matching an entry type name."
            ),
            resolved_track={"id": track.id, "title": track.title or track.id},
        )

    entry_type = await resolve_entry_type_for_track(track, type_hint=str(type_hint))
    if not entry_type:
        return _no_stage_candidates(
            message=(
                f"type_hint {type_hint!r} did not match any entry type on "
                f"'{track.title}'. Re-read integral_get_track_schema."
            ),
            resolved_track={"id": track.id, "title": track.title or track.id},
        )

    schema = entry_type.form_schema if isinstance(entry_type.form_schema, dict) else {}
    explicit = a.get("fields")
    if isinstance(explicit, dict) and explicit:
        try:
            merged = _normalize_agent_fields(explicit, schema)
        except ValueError as exc:
            return _no_stage_candidates(
                message=str(exc),
                filing_status="error",
                resolved_track={"id": track.id, "title": track.title or track.id},
            )
    else:
        merged = {}

    missing_required = _missing_required_fields(schema, merged)
    if missing_required:
        names = ", ".join(f"`{k}` ({n})" for k, n in missing_required)
        return _no_stage_candidates(
            message=(
                f"'{entry_type.name}' requires a value for: {names} — none has a "
                "default and none was supplied. Ask the user with integral_ask_user "
                "for whichever of these the user didn't already state, then retry "
                "with that key set in `fields`. Do not guess a value or stage "
                "anyway — the create will fail server-side and the user sees an "
                "opaque error."
            ),
            resolved_track={"id": track.id, "title": track.title or track.id},
        )

    raw_tags = a.get("tags") or defaults.get("tags") or []
    if raw_tags and isinstance(raw_tags[0], str):
        tag_names = [t for t in raw_tags if t]
        tags_for_diff = [{"name": t} for t in tag_names]
    else:
        tag_names = [
            t.get("name") for t in raw_tags if isinstance(t, dict) and t.get("name")
        ]
        tags_for_diff = [t for t in raw_tags if isinstance(t, dict)]

    track_title = track.title or track.id
    entry_type_name = entry_type.name
    title = (a.get("title") or "").strip() or _derive_title(text)

    from app.agentive.tooling.bindings import duplicate_create_block

    blocked = await duplicate_create_block(
        track_id=track.id,
        title=title,
        text=text,
        fields=merged,
        allow_duplicate_title=bool(a.get("allow_duplicate_title")),
        entry_type=entry_type.id,
    )
    if blocked:
        return _no_stage_candidates(
            message=blocked,
            filing_status="error",
            resolved_track={"id": track.id, "title": track_title},
        )

    from app.agentive.tooling.bindings import date_left_in_title_block

    date_block = await date_left_in_title_block(
        track_id=track.id,
        title=title,
        text=text,
        fields=merged,
        entry_type_name=entry_type_name,
    )
    if date_block:
        return _no_stage_candidates(
            message=f"file_content: {date_block}",
            filing_status="error",
            resolved_track={"id": track.id, "title": track_title},
        )

    payload: Dict[str, Any] = {
        "track_id": track.id,
        "title": title,
        "body": text,
        "entry_type": entry_type_name,
        "tags": tag_names or None,
        "fields": merged or None,
    }

    body_snippet = text if len(text) <= 200 else text[:199] + "…"
    diff_human = _filing_diff_human(
        track_title=track_title,
        entry_type_name=entry_type_name,
        title=title,
        body_snippet=body_snippet,
        fields=merged,
        tags=tags_for_diff,
    )
    if a.get("allow_duplicate_title"):
        diff_human += "\n- **Separate record:** Create a new record; retain all existing records unchanged."
    summary = f"File content as “{title}” in {track_title} ({entry_type_name})"
    diff_machine: Dict[str, Any] = {
        "op": "file_content",
        "filing_status": "resolved",
        **payload,
        "_personalization": {
            "used_learned_track": bool(defaults.get("track_id")),
            "used_learned_type": bool(defaults.get("entry_type_name")),
            "matched_track_id": defaults.get("track_id"),
            "confidence": defaults.get("confidence"),
            "matched_count": defaults.get("matched_count"),
            "explanation": defaults.get("explanation"),
        },
    }
    return {
        "kind": "file_content",
        "summary": summary,
        "diff_human": diff_human,
        "diff_machine": diff_machine,
        "payload": payload,
    }
