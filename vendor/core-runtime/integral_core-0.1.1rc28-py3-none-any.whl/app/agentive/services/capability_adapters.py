"""Adapters the capability broker calls after the snapshot gate."""

from __future__ import annotations

from typing import Any, Dict

from jvspatial.api.exceptions import JVSpatialAPIException
from pydantic import ValidationError

from app.schemas.capability_broker import CapabilityInvocation


async def dispatch_capability(inv: CapabilityInvocation, cap: Dict[str, Any]) -> Any:
    """Run the existing Core, App, or connector implementation."""
    try:
        arguments = dict(inv.arguments or {})
        # agent runtime's JSON tool protocol may wrap a declared tool's fields in
        # ``action_input``. The Core/App capability contracts expose those
        # fields directly, so unwrap only the unambiguous single-key envelope;
        # preserving any sibling fields avoids silently discarding caller data.
        if set(arguments) == {"action_input"} and isinstance(
            arguments.get("action_input"), dict
        ):
            arguments = dict(arguments["action_input"])

        if inv.source == "core" and inv.capability_key == "integral_query_spec":
            from app.agentive.services.query_spec import (
                QuerySpecError,
                execute_query_spec,
            )
            from app.schemas.query_spec import QuerySpec

            try:
                raw_spec = dict(arguments.get("spec") or {})
                scoped_id = arguments.get("result_set_id") or raw_spec.pop(
                    "result_set_id", None
                )
                spec = QuerySpec.model_validate(raw_spec)
                execute_kwargs = {
                    "principal_id": inv.principal_id,
                    "workspace_id": inv.workspace_id,
                    "run_id": inv.run_id,
                    "idempotency_key": inv.idempotency_key,
                    "spec": spec,
                }
                if scoped_id:
                    execute_kwargs["result_set_id"] = scoped_id
                result = await execute_query_spec(**execute_kwargs)
            except (QuerySpecError, ValidationError) as exc:
                raise AdapterError("query.invalid", str(exc)) from exc
            return result.model_dump(mode="json")
        if (
            inv.source == "app"
            and inv.op_class == "read"
            and isinstance(cap.get("query_template"), dict)
        ):
            from app.agentive.services.query_spec import (
                QuerySpecError,
                execute_query_spec,
            )
            from app.schemas.query_spec import QuerySpec
            from app.services.hooks.tool_dispatch import validate_input

            try:
                validate_input(arguments, dict(cap.get("input_schema") or {}))
                template = dict(cap["query_template"])
                declared_inputs = set(
                    (cap.get("input_schema") or {}).get("properties") or {}
                )
                if "cursor" in declared_inputs and "cursor" in arguments:
                    template["cursor"] = arguments["cursor"]
                spec = QuerySpec.model_validate(template)
                result = await execute_query_spec(
                    principal_id=inv.principal_id,
                    workspace_id=inv.workspace_id,
                    run_id=inv.run_id,
                    idempotency_key=inv.idempotency_key,
                    spec=spec,
                    declared_app_id=str(inv.app_id or ""),
                )
            except (JVSpatialAPIException, QuerySpecError, ValidationError) as exc:
                raise AdapterError("query.invalid", str(exc)) from exc
            return result.model_dump(mode="json")
        if inv.source == "app":
            if inv.origin in {"http", "view"}:
                # These origins are bound by the authenticated App operation
                # endpoint, whose button/API request is the human action.
                from app.services.app_operations.dispatch import invoke_app_operation

                return await invoke_app_operation(
                    user_id=inv.principal_id,
                    workspace_id=inv.workspace_id,
                    app_id=str(inv.app_id or ""),
                    operation_key=inv.capability_key,
                    payload=arguments,
                    idempotency_key=inv.idempotency_key,
                    expected_operation_kind="read" if inv.op_class == "read" else None,
                )
            if inv.op_class == "read":
                from app.services.app_operations.dispatch import invoke_app_operation

                # Recheck the current declaration before entering any handler:
                # a former read must never become a command under a read grant.
                return await invoke_app_operation(
                    user_id=inv.principal_id,
                    workspace_id=inv.workspace_id,
                    app_id=str(inv.app_id or ""),
                    operation_key=inv.capability_key,
                    payload=arguments,
                    idempotency_key=inv.idempotency_key,
                    expected_operation_kind="read",
                )
            # Directly materialized App commands share the wrapper's review
            # boundary; discovering the typed capability grants no write bypass.
            from app.agentive.tooling.dispatch import dispatch_tool

            result = await dispatch_tool(
                "integral_invoke_app_operation",
                {
                    "app_id": str(inv.app_id or ""),
                    "operation_key": inv.capability_key,
                    "input": arguments,
                    "idempotency_key": inv.idempotency_key,
                },
                principal_id=inv.principal_id,
                scope=inv.workspace_id,
                session_id=inv.session_id,
                interaction_id=inv.interaction_id,
            )
            if result.is_error:
                raise AdapterError(result.error_code or "error", result.message)
            return result.data
        from app.agentive.tooling.dispatch import dispatch_tool

        dispatch_key = inv.capability_key
        if inv.source == "connector" and inv.connector_id:
            from app.agentive.connectors.mcp_mount import tool_key_for
            from app.agentive.connectors.tool_binding import (
                resolve_mounted_tool_connector,
            )
            from app.services.hooks.registry import get_workspace_tools

            specs = get_workspace_tools(inv.workspace_id)
            declared = specs.get(inv.capability_key) or {}
            remote_name = str(declared.get("_mcp_remote_name") or "")
            dispatch_key = tool_key_for(inv.connector_id, remote_name)
            try:
                row, bound_spec = await resolve_mounted_tool_connector(
                    workspace_id=inv.workspace_id,
                    principal_id=inv.principal_id,
                    capability_key=dispatch_key,
                )
            except Exception as exc:
                raise AdapterError(
                    "capability.revoked", "Bound connector tool is unavailable"
                ) from exc
            if (
                str(row.id) != inv.connector_id
                or bound_spec.get("_mcp_remote_name") != remote_name
            ):
                raise AdapterError(
                    "capability.revoked", "Bound connector tool is unavailable"
                )
        result = await dispatch_tool(
            dispatch_key,
            arguments,
            principal_id=inv.principal_id,
            scope=inv.workspace_id,
            session_id=inv.session_id,
            interaction_id=inv.interaction_id,
            skill_tools_required=inv.skill_tools_required,
        )
        if result.is_error:
            raise AdapterError(
                result.error_code or "error", result.message, next_tool=result.next_tool
            )
        return result.data
    except AdapterError:
        raise
    except JVSpatialAPIException as exc:
        raise AdapterError(exc.error_code, exc.message) from exc


class AdapterError(Exception):
    """Normalized adapter failure the broker turns into a failed receipt."""

    def __init__(self, error_code: str, message: str, next_tool: str = "") -> None:
        super().__init__(error_code, message, next_tool)
        self.error_code = error_code
        self.message = message
        self.next_tool = next_tool
