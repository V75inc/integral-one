"""Read-only scaffold checks shared by commit and continuation hints.

No domain identities live here. A valid build has shaped, visible tracks and
backward-only references; execution still checks policy for every operation.
"""

from typing import Any, Dict, List


def _view_binding_error(
    payload: Dict[str, Any], fields: List[Dict[str, Any]] | None = None
) -> str | None:
    """Return why a scaffold view would render as a generic surface.

    A saved view is not evidence of a usable app merely because its node
    exists.  The built-in widgets fall back to generic platform columns and
    lanes when their schema binding is omitted, which is useful for manual UI
    creation but is a failed result for an agent-authored operational app.
    """
    view_type = str(payload.get("view_type") or "feed")
    config = payload.get("config") or {}
    if not isinstance(config, dict):
        return "config must be an object"
    if view_type == "table":
        columns = config.get("columns")
        if (
            fields == []
            and isinstance(columns, list)
            and any(
                isinstance(column, dict) and column.get("field") == "title"
                for column in columns
            )
        ):
            return None
        if not isinstance(columns, list) or not any(
            isinstance(column, dict)
            and str(column.get("field") or "").startswith("custom_fields.")
            for column in columns
        ):
            return "table views need config.columns using custom_fields.<field_key>"
    if view_type == "kanban":
        group_by = str(config.get("group_by") or "")
        if not group_by.startswith("custom_fields."):
            return "kanban views need group_by: custom_fields.<select_field>"
        field_key = group_by.removeprefix("custom_fields.")
        field = next(
            (
                item
                for item in fields or []
                if item.get("key") == field_key and item.get("type") == "select"
            ),
            None,
        )
        if fields and field is None:
            return "kanban group_by must name a declared select field"
        columns = config.get("kanban_columns")
        if not isinstance(columns, list) or not columns:
            return "kanban views need config.kanban_columns"
        if not all(
            isinstance(column, dict) and str(column.get("key") or "").strip()
            for column in columns
        ):
            return "kanban config.kanban_columns entries must be objects with keys"
        choices = (field or {}).get("enum") or (field or {}).get("options") or []
        if choices and {str(column["key"]) for column in columns} != {
            str(choice) for choice in choices
        }:
            return "kanban columns must match the grouped select field's options"
    if view_type == "calendar":
        mapping = config.get("calendar_mapping") or {}
        if not isinstance(mapping, dict) or not mapping.get("dateField"):
            return "calendar views need calendar_mapping.dateField"
    if view_type == "wiki" and not str(config.get("parent_field") or "").strip():
        return "wiki views need config.parent_field bound to a relation field"
    return None


def _field_specs(entry_types: Any) -> List[Dict[str, Any]]:
    """Return declared field specs from inline track entry types in order."""
    out: List[Dict[str, Any]] = []
    if not isinstance(entry_types, list):
        return out
    for entry_type in entry_types:
        if not isinstance(entry_type, dict):
            continue
        fields = entry_type.get("fields")
        if not isinstance(fields, list):
            continue
        for field in fields:
            if isinstance(field, dict) and str(field.get("key") or "").strip():
                out.append(field)
    return out


def _field_label(field: Dict[str, Any]) -> str:
    return str(field.get("name") or field.get("key") or "Field").strip()


def _write_normalized_config(op: Dict[str, Any], config: Dict[str, Any]) -> None:
    """Keep the executable payload and approval diff describing the same view."""
    payload = op.get("payload")
    if isinstance(payload, dict):
        payload["config"] = config
    diff_machine = op.get("diff_machine")
    if isinstance(diff_machine, dict):
        diff_machine["config"] = config


def materialize_scaffold_view_bindings(ops: List[Dict[str, Any]]) -> int:
    """Fill missing schema bindings for views in a greenfield batch.

    A scaffold creates tracks and views in the same uncommitted operation list,
    so the view stager cannot read a persisted Operational Model.  The declared
    inline entry-type fields are nevertheless authoritative.  This compiler
    pass uses them to make an incomplete *existing* view useful; it never
    invents a view, overwrites a valid schema-bound config, or guesses a field
    when the track did not declare one.

    Returns the number of view payloads repaired.  It is deliberately pure
    aside from mutating the batch operations supplied by the caller.
    """
    from app.agentive.staging_executors import _capture_batch_refs, _resolve_batch_refs

    refs: Dict[str, str] = {}
    track_fields: Dict[str, List[Dict[str, Any]]] = {}
    declared_shapes: set[str] = set()
    repaired = 0
    for index, op in enumerate(ops):
        kind = op.get("kind")
        payload = _resolve_batch_refs(op.get("payload") or {}, refs)
        if kind in {"create_track", "create_app_track"}:
            identity = f"step:{index}"
            track_fields[identity] = _field_specs(payload.get("entry_types"))
            if payload.get("entry_types"):
                declared_shapes.add(identity)
            _capture_batch_refs(
                refs,
                index,
                {
                    "track": {
                        "id": identity,
                        "title": payload.get("title") or payload.get("name"),
                    }
                },
            )
            continue
        if kind != "save_view":
            continue
        track_id = str(payload.get("track_id") or "")
        fields = track_fields.get(track_id, [])
        view_type = str(payload.get("view_type") or "feed")
        if not fields and not (view_type == "table" and track_id in declared_shapes):
            continue
        if _view_binding_error(payload, fields) is None:
            continue
        config = dict(payload.get("config") or {})
        if view_type == "table":
            config["columns"] = [
                {"field": "title", "label": "Name"},
                *[
                    {
                        "field": f"custom_fields.{field['key']}",
                        "label": _field_label(field),
                    }
                    for field in fields
                ],
            ]
        elif view_type == "kanban":
            group_key = str(config.get("group_by") or "").removeprefix("custom_fields.")
            field = (
                next(
                    (
                        item
                        for item in fields
                        if item.get("key") == group_key and item.get("type") == "select"
                    ),
                    None,
                )
                or next(
                    (
                        item
                        for key in ("status", "stage")
                        for item in fields
                        if item.get("key") == key and item.get("type") == "select"
                    ),
                    None,
                )
                or next((item for item in fields if item.get("type") == "select"), None)
            )
            if field is None:
                continue
            config["group_by"] = f"custom_fields.{field['key']}"
            values = field.get("enum") or field.get("options") or []
            if isinstance(values, list) and values:
                config["kanban_columns"] = [
                    {"key": str(value), "label": str(value).replace("_", " ").title()}
                    for value in values
                ]
            else:
                config["kanban_columns"] = [
                    {"key": "unassigned", "label": "Unassigned"}
                ]
        elif view_type == "calendar":
            field = next((item for item in fields if item.get("type") == "date"), None)
            if field is None:
                continue
            config["calendar_mapping"] = {"dateField": f"custom_fields.{field['key']}"}
        elif view_type == "wiki":
            field = next(
                (item for item in fields if item.get("type") == "relation"), None
            )
            if field is None:
                continue
            config["parent_field"] = field["key"]
        else:
            continue
        _write_normalized_config(op, config)
        repaired += 1
    return repaired


def materialize_scaffold_defaults(
    ops: List[Dict[str, Any]], *, allow_empty: bool = False
) -> int:
    """Append omitted example records for a greenfield scaffold.

    Views come from the plan or the approved design. This function does not
    invent a table or a calendar. The platform Feed is added by the substrate,
    not here. Unspecified seed fields remain empty, including on demos.
    This function never changes an existing view or record.
    """
    from app.agentive.staging_executors import _capture_batch_refs, _resolve_batch_refs

    refs: Dict[str, str] = {}
    tracks: Dict[str, Dict[str, Any]] = {}
    additions: List[Dict[str, Any]] = []
    for index, op in enumerate(ops):
        kind = op.get("kind")
        payload = _resolve_batch_refs(op.get("payload") or {}, refs)
        if kind in {"create_track", "create_app_track"}:
            identity = f"step:{index}"
            title = str(payload.get("title") or payload.get("name") or "Track")
            entry_types = payload.get("entry_types")
            first_entry_type = (
                entry_types[0]
                if isinstance(entry_types, list)
                and entry_types
                and isinstance(entry_types[0], dict)
                else {}
            )
            tracks[identity] = {
                "title": title,
                "fields": _field_specs(payload.get("entry_types")),
                "entry_type": str(
                    first_entry_type.get("name") or first_entry_type.get("key") or ""
                ),
                "views": set(),
                "has_seed": False,
                "seed_ops": [],
            }
            _capture_batch_refs(
                refs,
                index,
                {"track": {"id": identity, "title": title}},
            )
            continue
        track = tracks.get(str(payload.get("track_id") or ""))
        if track is None:
            continue
        if kind == "save_view":
            track["views"].add(str(payload.get("view_type") or "feed"))
        elif kind == "create_entry":
            track["has_seed"] = True
            track["seed_ops"].append(op)

    for track in tracks.values():
        # A track without inline fields remains a model repair task: there is
        # no honest schema from which to derive an operational view.
        fields = track["fields"]
        if not fields:
            continue
        title = track["title"]
        track_ref = f"{{{{track.id:{title}}}}}"
        example_entry_type = track.get("entry_type")
        # A clearly named demo can use the declared entry type without
        # inventing any values for its fields.
        for seed_op in track["seed_ops"]:
            seed_payload = seed_op.get("payload")
            if not isinstance(seed_payload, dict):
                continue
            seed_title = str(seed_payload.get("title") or "").strip().lower()
            if not (
                seed_title == "demo"
                or seed_title.startswith(("demo ", "example ", "sample "))
            ):
                continue
            if example_entry_type and not seed_payload.get("entry_type"):
                seed_payload["entry_type"] = example_entry_type
                seed_diff = seed_op.get("diff_machine")
                if isinstance(seed_diff, dict):
                    seed_diff["entry_type"] = example_entry_type
        if not allow_empty and not track["has_seed"]:
            additions.append(
                {
                    "kind": "create_entry",
                    "summary": f"Add example {title} record",
                    "diff_human": "Generated example record for the scaffold.",
                    "diff_machine": {
                        "op": "create_entry",
                        "track_id": track_ref,
                        "title": f"Example {title}",
                        **(
                            {"entry_type": example_entry_type}
                            if example_entry_type
                            else {}
                        ),
                        "fields": {},
                    },
                    "payload": {
                        "track_id": track_ref,
                        "title": f"Example {title}",
                        **(
                            {"entry_type": example_entry_type}
                            if example_entry_type
                            else {}
                        ),
                        "fields": {},
                    },
                }
            )
    ops.extend(additions)
    return len(additions)


def scaffold_missing(
    ops: List[Dict[str, Any]], *, allow_empty: bool = False
) -> List[str]:
    """Return actionable omissions per track, not misleading global counts."""
    from app.agentive.staging_executors import _capture_batch_refs, _resolve_batch_refs

    if not any(op.get("kind") == "create_app" for op in ops):
        return []
    refs: Dict[str, str] = {}
    tracks: Dict[str, Dict[str, Any]] = {}
    apps: Dict[str, str] = {}
    for idx, op in enumerate(ops):
        kind = op.get("kind")
        payload = _resolve_batch_refs(op.get("payload") or {}, refs)
        identity = f"step:{idx}"
        name = payload.get("title") or payload.get("name") or identity
        if kind == "create_app":
            apps[identity] = name
            _capture_batch_refs(refs, idx, {"app": {"id": identity, "name": name}})
        elif kind in {"create_track", "create_app_track"}:
            tracks[identity] = {
                "name": name,
                "app_id": payload.get("app_id"),
                "shaped": bool(payload.get("entry_types")),
                "fields": _field_specs(payload.get("entry_types")),
                "view": False,
                "view_errors": [],
                "seed": False,
            }
            _capture_batch_refs(refs, idx, {"track": {"id": identity, "title": name}})
        elif payload.get("track_id") in tracks:
            target = tracks[payload["track_id"]]
            if kind == "apply_profile_to_track":
                target["shaped"] = True
            elif kind == "save_view":
                binding_error = _view_binding_error(payload, target["fields"])
                if (
                    binding_error is None
                    and payload.get("view_type") == "wiki"
                    and target["fields"]
                ):
                    parent_key = str(
                        (payload.get("config") or {}).get("parent_field") or ""
                    )
                    parent_key = parent_key.removeprefix("custom_fields.")
                    if not any(
                        field.get("key") == parent_key
                        and field.get("type") == "relation"
                        for field in target["fields"]
                    ):
                        binding_error = (
                            "wiki config.parent_field must name a relation field "
                            "on the track entry type"
                        )
                if binding_error is None:
                    target["view"] = True
                else:
                    target["view_errors"].append(binding_error)
            elif kind == "create_entry":
                target["seed"] = True
    missing = []
    for app_id, name in apps.items():
        if not allow_empty and not any(t["app_id"] == app_id for t in tracks.values()):
            missing.append(f"integral_create_app_track for app {name!r}")
    for track in tracks.values():
        name = track["name"]
        if not track["app_id"]:
            missing.append(f"Attach track {name!r} to its app with app_id")
        if not track["shaped"]:
            missing.append(
                f"integral_apply_model_to_track for {name!r} (or inline entry_types)"
            )
        for detail in track["view_errors"]:
            missing.append(f"Configure a schema-bound view for {name!r}: {detail}")
        if not allow_empty and not track["seed"]:
            missing.append(
                f"integral_create_entry demo for {name!r}; allow_empty only if requested"
            )
    return missing


def validate_batch_references(ops: List[Dict[str, Any]]) -> None:
    """Reject dangling/forward or ambiguous named references before any writes."""
    from app.agentive.staging import StagingError
    from app.agentive.staging_executors import (
        _BATCH_POSITIONAL_REF_RE,
        _BATCH_REF_RE,
        _capture_batch_refs,
        _resolve_batch_refs,
    )

    def strings(value):
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            for child in value.values():
                yield from strings(child)
        elif isinstance(value, list):
            for child in value:
                yield from strings(child)

    creators = {
        "create_app": "app",
        "create_track": "track",
        "create_app_track": "track",
        "create_entry": "entry",
        "create_tag": "tag",
        "save_view": "view",
        "create_comment": "comment",
    }
    refs: Dict[str, str] = {}
    names = set()
    for idx, op in enumerate(ops):
        payload = op.get("payload") or {}
        resolved = _resolve_batch_refs(payload, refs)
        unresolved = sorted(
            {
                m.group(0)
                for s in strings(resolved)
                for pattern in (_BATCH_REF_RE, _BATCH_POSITIONAL_REF_RE)
                for m in pattern.finditer(s)
            }
        )
        if unresolved:
            raise StagingError(
                "invalid_batch_reference",
                f"Step {idx + 1} has unresolved references: {', '.join(unresolved)}. "
                "Create the target earlier in this batch and use its exact name. "
                "Cancel and rebuild the unapproved batch to correct existing operations.",
            )
        entity = creators.get(op.get("kind"))
        if entity:
            name = payload.get("title") or payload.get("name")
            if (
                name
                and (entity, name) in names
                and any(
                    f"{entity}.id:{name}" in s or f"{entity}_id:{name}" in s
                    for later in ops
                    for s in strings(later.get("payload") or {})
                )
            ):
                raise StagingError(
                    "invalid_batch_reference",
                    f"Duplicate {entity} name {name!r} makes named references ambiguous.",
                )
            names.add((entity, name))
            inline_tags = [
                {"id": f"step:{idx}:{tag['name']}", "name": tag["name"]}
                for group in (payload.get("taxonomy") or {}).get("tag_groups") or []
                for tag in group.get("tags") or []
            ]
            for tag in inline_tags:
                if ("tag", tag["name"]) in names and any(
                    f"tag.id:{tag['name']}" in s or f"tag_id:{tag['name']}" in s
                    for later in ops
                    for s in strings(later.get("payload") or {})
                ):
                    raise StagingError(
                        "invalid_batch_reference",
                        f"Duplicate tag name {tag['name']!r} makes named references "
                        "ambiguous; seeds can name a Track's tags directly.",
                    )
                names.add(("tag", tag["name"]))
            _capture_batch_refs(
                refs,
                idx,
                {
                    entity: {"id": f"step:{idx}", "name": name},
                    "tags_created": inline_tags,
                },
            )
