"""Blueprint revisions and structural plan fidelity for App designs (W1.3)."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from typing import Any, Dict, Iterator, List, Optional, Tuple

from pydantic import ValidationError

from app.schemas.design_blueprint import DesignBlueprint
from app.services.operational_model_compile import slug_manifest_key

_TRACK_REF = re.compile(r"^\{\{track\.id:(.+)\}\}$")
_TAG_REF = re.compile(r"^\{\{tag[._]id:(.+)\}\}$")


def tag_ref_name(ref: str) -> str:
    """The tag name inside ``{{tag.id:Name}}``, or ``ref`` itself."""
    match = _TAG_REF.match(ref.strip())
    return (match.group(1) if match else ref).strip()


def _group_key(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_")


def validate_blueprint(raw: Any) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Return ``(canonical_dict, None)`` or ``(None, readable_error)``."""
    try:
        blueprint = DesignBlueprint.model_validate(raw)
    except ValidationError as exc:
        problems = [
            f"{'.'.join(str(p) for p in err['loc']) or 'blueprint'}: {err['msg']}"
            for err in exc.errors()[:8]
        ]
        return None, "; ".join(problems)
    from app.exceptions import BadRequestError
    from app.services.operational_model_compile import normalize_view_config
    from app.services.view_authoring_config import adapt_view_config
    from app.views import operational_model_view_types as view_type_registry

    canonical = blueprint.model_dump(mode="json")
    for view in canonical["views"]:
        kind = _canonical_view_type(view["type"])
        view["config"] = adapt_view_config(kind, view["config"])
        # Unknown types belong to the coverage check, which explains supported
        # alternatives. Known types must be buildable before user approval.
        if kind in view_type_registry.allowed_keys():
            try:
                normalize_view_config(kind, view["config"])
            except BadRequestError as exc:
                return None, f"View {view['name']!r}: {exc.message}"
    return canonical, None


def blueprint_digest(blueprint: Dict[str, Any]) -> str:
    """Content digest of a canonical blueprint dict."""
    canonical = json.dumps(blueprint, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _is_child(value: Any) -> bool:
    if isinstance(value, dict):
        return "id" in value
    return (
        isinstance(value, list)
        and bool(value)
        and all(isinstance(x, dict) and "id" in x for x in value)
    )


def _item_contents(value: Any) -> Iterator[Tuple[str, Dict[str, Any]]]:
    """Each identified item's own fields, excluding its identified children."""
    if isinstance(value, dict):
        if "id" in value:
            yield str(value["id"]), {k: v for k, v in value.items() if not _is_child(v)}
        for nested in value.values():
            yield from _item_contents(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from _item_contents(nested)


def blueprint_diff(
    prior: Optional[Dict[str, Any]], current: Dict[str, Any]
) -> Dict[str, List[str]]:
    """Item-ID diff between two blueprint revisions."""
    before = dict(_item_contents(prior or {}))
    after = dict(_item_contents(current))
    return {
        "added": sorted(set(after) - set(before)),
        "removed": sorted(set(before) - set(after)),
        "changed": sorted(
            item_id
            for item_id in set(before) & set(after)
            if before[item_id] != after[item_id]
        ),
    }


def _plan_fields(params: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        field
        for entry_type in params.get("entry_types") or []
        if isinstance(entry_type, dict)
        for field in entry_type.get("fields") or []
        if isinstance(field, dict)
    ]


def _track_name(ref: Any) -> str:
    match = _TRACK_REF.match(str(ref or ""))
    return (match.group(1) if match else str(ref or "")).strip().casefold()


# The palette's column board is ``kanban``. A plan that says ``board`` is that view.
_VIEW_TYPE_ALIASES = {"board": "kanban"}


def _canonical_view_type(value: Any) -> str:
    kind = str(value or "").strip().casefold()
    return _VIEW_TYPE_ALIASES.get(kind, kind)


def _blank_seed_value(value: Any) -> bool:
    """An empty string or null is not a seed value."""
    if value is None:
        return True
    return isinstance(value, str) and value.strip() == ""


def _seed_field_difference(
    title: str,
    approved_fields: Dict[str, Any],
    planned_fields: Dict[str, Any],
    member_keys: set[str],
    relation_targets: Optional[Dict[str, str]] = None,
) -> Optional[str]:
    """Name how a planned seed differs from the approved field map.

    Empty strings and nulls are dropped first, so a stuffed-in blank does not
    fail a seed that otherwise matches. A member key may be added at execution
    to bind the requesting user.
    """
    approved = {
        key: value
        for key, value in approved_fields.items()
        if not _blank_seed_value(value)
    }
    planned = {
        key: value
        for key, value in planned_fields.items()
        if key in member_keys or not _blank_seed_value(value)
    }
    extra = sorted(
        key for key in planned if key not in approved and key not in member_keys
    )
    missing = sorted(key for key in approved if key not in planned)
    mismatched = sorted(
        key
        for key in approved
        if key in planned
        and planned[key] != approved[key]
        and planned[key] != (relation_targets or {}).get(key, approved[key])
    )
    if not extra and not missing and not mismatched:
        return None
    parts = [f"Seed {title!r} fields differ from the approved design."]
    if missing:
        parts.append("Missing: " + ", ".join(missing) + ".")
    if extra:
        parts.append("Extra: " + ", ".join(extra) + ".")
    if mismatched:
        shown = ", ".join(f"{key} (approved {approved[key]!r})" for key in mismatched)
        parts.append("Mismatched: " + shown + ".")
    parts.append("Copy the approved seed fields exactly.")
    return " ".join(parts)


def plan_fidelity_errors(
    blueprint: Dict[str, Any],
    operations: List[Tuple[str, Dict[str, Any]]],
    *,
    new_app: bool,
) -> List[str]:
    """Compare a compiled scaffold plan with the approved blueprint.

    ``operations`` are the expanded ``(tool, args)`` pairs about to be staged.
    Every approved constituent the builder can create must appear exactly;
    anything the plan adds beyond the blueprint is drift, not initiative.
    """
    errors: List[str] = []
    if blueprint.get("open_decisions"):
        open_ids = ", ".join(d["id"] for d in blueprint["open_decisions"])
        return [
            f"The design still has open decisions ({open_ids}); resolve them first."
        ]
    templates = blueprint.get("track_templates") or []
    tagged_templates = [t["id"] for t in templates if t.get("tag_groups")]
    if tagged_templates:
        errors.append(
            "The build cannot yet create tags on track templates: "
            + ", ".join(sorted(tagged_templates))
            + ". Amend the design to drop them or add them after the build."
        )
    template_keys = {t["id"]: slug_manifest_key(t["name"]) for t in templates}

    by_tool: Dict[str, List[Dict[str, Any]]] = {}
    for tool, params in operations:
        by_tool.setdefault(tool, []).append(params)

    def compare_fields(
        label: str, approved: List[Dict[str, Any]], params: Dict[str, Any]
    ) -> None:
        planned = _plan_fields(params)
        planned_by_key = {
            str(f.get("key") or "").casefold(): f for f in planned if f.get("key")
        }
        planned_by_name = {str(f.get("name") or "").casefold(): f for f in planned}
        matched: set[int] = set()
        for spec in approved:
            hit = planned_by_key.get(spec["key"]) or planned_by_name.get(
                spec["name"].casefold()
            )
            if hit is None:
                errors.append(
                    f"{label} omits approved field {spec['key']} ({spec['name']})."
                )
                continue
            matched.add(id(hit))
            if hit.get("key") != spec["key"]:
                errors.append(
                    f"Field {spec['name']!r} must retain approved key "
                    f"{spec['key']!r}, not {hit.get('key')!r}. "
                    "Copy the approved field key and update its references."
                )
            if hit.get("type") and hit["type"] != spec["type"]:
                errors.append(
                    f"Field {spec['key']} must be {spec['type']}, not {hit['type']}."
                )
            relation = spec.get("relation") or {}
            if relation.get("target") == "track":
                want = template_keys.get(relation["target_track_template"])
                got = hit.get("relation") or {}
                if (
                    got.get("target") != "track"
                    or got.get("target_track_template") != want
                ):
                    errors.append(
                        f"Field {spec['key']} must anchor to track template {want!r} "
                        "with relation.target='track'."
                    )
        for extra in (f for f in planned if id(f) not in matched):
            errors.append(
                f"{label} adds field {extra.get('key') or extra.get('name')!r}, "
                "which is not in the design."
            )

    def compare_entry_types(
        label: str, approved: List[Dict[str, Any]], params: Dict[str, Any]
    ) -> None:
        planned = params.get("entry_types") or []
        expected = {item["name"].casefold(): item for item in approved}
        actual = {
            str(item.get("name") or "").casefold(): item
            for item in planned
            if isinstance(item, dict)
        }
        if set(expected) != set(actual) or len(actual) != len(planned):
            errors.append(
                f"{label} entry types must retain the approved names: "
                + ", ".join(repr(item["name"]) for item in approved)
                + ". Copy the saved blueprint names exactly."
            )
        for name in expected.keys() & actual.keys():
            compare_fields(
                (
                    label
                    if len(expected) == 1
                    else f"{label} entry type {expected[name]['name']!r}"
                ),
                expected[name]["fields"],
                {"entry_types": [actual[name]]},
            )

    approved_templates = {t["name"].casefold(): t for t in templates}
    planned_templates = {
        str(p.get("name") or "").casefold(): p
        for p in by_tool.get("integral_register_track_template", [])
    }
    for name in sorted(set(approved_templates) - set(planned_templates)):
        errors.append(
            f"The plan omits approved track template {approved_templates[name]['name']!r}."
        )
    for name in sorted(set(planned_templates) - set(approved_templates)):
        errors.append(f"The plan adds track template {name!r}, not in the design.")
    for name in sorted(set(approved_templates) & set(planned_templates)):
        compare_entry_types(
            f"Track template {approved_templates[name]['name']!r}",
            approved_templates[name]["entry_types"],
            planned_templates[name],
        )

    app_name = blueprint["app"]["name"].casefold()
    if new_app:
        planned_apps = [
            str(p.get("name") or "").casefold()
            for p in by_tool.get("integral_create_app", [])
        ]
        if planned_apps != [app_name]:
            errors.append(
                f"The plan must create exactly the approved App {blueprint['app']['name']!r}."
            )

    tracks = {t["id"]: t for t in blueprint["tracks"]}
    track_names = {t["name"].casefold(): t for t in blueprint["tracks"]}
    planned_tracks = {
        str(p.get("name") or "").casefold(): p
        for p in by_tool.get("integral_create_app_track", [])
    }
    for name in sorted(set(track_names) - set(planned_tracks)):
        errors.append(f"The plan omits approved Track {track_names[name]['name']!r}.")
    for name in sorted(set(planned_tracks) - set(track_names)):
        errors.append(f"The plan adds Track {name!r}, which is not in the design.")

    for name in sorted(set(track_names) & set(planned_tracks)):
        label = track_names[name]["name"]
        compare_entry_types(
            f"Track {label!r}",
            track_names[name]["entry_types"],
            planned_tracks[name],
        )
        approved_tags = {
            tag.casefold(): (_group_key(group["name"]), tag, group["name"])
            for group in track_names[name].get("tag_groups") or []
            for tag in group["tags"]
        }
        planned_tags: Dict[str, Optional[str]] = {
            str(tag["name"]).casefold(): _group_key(str(group.get("key") or ""))
            for group in (planned_tracks[name].get("taxonomy") or {}).get("tag_groups")
            or []
            for tag in group.get("tags") or []
        }
        for p in by_tool.get("integral_create_tag", []):
            if _track_name(p.get("track_id")) == name:
                planned_tags[str(p.get("name") or "").casefold()] = (
                    _group_key(str(p["group_key"])) if p.get("group_key") else None
                )
        for tag_fold, (group_key, tag, group_name) in sorted(approved_tags.items()):
            if tag_fold not in planned_tags:
                errors.append(
                    f"Track {label!r} omits approved tag {tag!r} ({group_name})."
                )
            elif planned_tags[tag_fold] not in (None, group_key):
                errors.append(
                    f"Tag {tag!r} on {label!r} belongs to group {group_name!r}."
                )
        for tag_fold in sorted(set(planned_tags) - set(approved_tags)):
            errors.append(
                f"Track {label!r} adds tag {tag_fold!r}, which is not in the design."
            )

    display = {}
    approved_views = set()
    for v in blueprint.get("views") or []:
        key = (tracks[v["track"]]["name"].casefold(), v["name"].casefold(), v["type"])
        approved_views.add(key)
        display[key] = (tracks[v["track"]]["name"], v["name"])
    planned_views = {
        (
            _track_name(p.get("track_id")),
            str(p.get("name") or "").casefold(),
            _canonical_view_type(p.get("view_type")),
        )
        for p in by_tool.get("integral_save_view", [])
    }
    for key in sorted(approved_views - planned_views):
        track, view = display[key]
        errors.append(f"The plan omits approved {key[2]} view {view!r} on {track!r}.")
    for track, view, kind in sorted(planned_views - approved_views):
        errors.append(
            f"The plan adds {kind} view {view!r} on {track!r}, not in the design."
        )

    approved_seeds = set()
    for s in blueprint.get("seeds") or []:
        key = (tracks[s["track"]]["name"].casefold(), s["title"].casefold())
        approved_seeds.add(key)
        display[key] = (tracks[s["track"]]["name"], s["title"])
    planned_seeds = {
        (_track_name(p.get("track_id")), str(p.get("title") or "").casefold())
        for p in by_tool.get("integral_create_entry", [])
    }
    for key in sorted(approved_seeds - planned_seeds):
        track, title = display[key]
        errors.append(f"The plan omits approved seed {title!r} on {track!r}.")
    for track, title in sorted(planned_seeds - approved_seeds):
        errors.append(
            f"The plan adds seed {title!r} on {track!r}; the design has none such."
        )
    planned_seed_tags = {
        (_track_name(p.get("track_id")), str(p.get("title") or "").casefold()): {
            tag_ref_name(str(tag)).casefold() for tag in p.get("tags") or []
        }
        for p in by_tool.get("integral_create_entry", [])
    }
    seed_titles: Dict[str, List[str]] = {}
    for seed in blueprint.get("seeds") or []:
        seed_titles.setdefault(seed["title"].strip().casefold(), []).append(
            seed["title"]
        )
    for seed in blueprint.get("seeds") or []:
        identity = (tracks[seed["track"]]["name"].casefold(), seed["title"].casefold())
        want = {tag.casefold() for tag in seed.get("tags") or []}
        if identity in planned_seed_tags and planned_seed_tags[identity] != want:
            errors.append(
                f"Seed {seed['title']!r} must carry tags {sorted(want)}, "
                f"not {sorted(planned_seed_tags[identity])}."
            )
        matching = [
            params
            for params in by_tool.get("integral_create_entry", [])
            if (
                _track_name(params.get("track_id")),
                str(params.get("title") or "").casefold(),
            )
            == identity
        ]
        for params in matching:
            approved_fields = seed.get("fields") or {}
            planned_fields = params.get("fields") or {}
            # A member field can bind an approved seed to a real requesting
            # user during execution. All scalar sample values must still be
            # present in the approved blueprint verbatim.
            member_keys = {
                str(field.get("key") or "")
                for entry_type in tracks[seed["track"]].get("entry_types") or []
                for field in entry_type.get("fields") or []
                if field.get("type") == "member"
            }
            # Compilation binds named entry relations to batch references.
            # Accept only the reference derived from this approved value,
            # and only when its title identifies exactly one approved seed.
            # Text fields and redirected relations retain literal equality.
            relation_keys = {
                str(field.get("key") or "")
                for entry_type in tracks[seed["track"]].get("entry_types") or []
                for field in entry_type.get("fields") or []
                if field.get("type") == "relation"
                and (field.get("relation") or {}).get("target") == "entry"
            }
            relation_targets = {}
            for key in relation_keys:
                value = approved_fields.get(key)
                if not isinstance(value, str):
                    continue
                targets = seed_titles.get(value.strip().casefold(), [])
                if len(targets) == 1:
                    relation_targets[key] = "{{entry.id:" + targets[0] + "}}"
            difference = _seed_field_difference(
                seed["title"],
                approved_fields,
                planned_fields,
                member_keys,
                relation_targets,
            )
            if difference:
                errors.append(difference)

    has_dashboard = bool(by_tool.get("integral_create_dashboard"))
    if bool(blueprint.get("dashboard")) != has_dashboard:
        errors.append(
            "The approved dashboard is missing from the plan."
            if blueprint.get("dashboard")
            else "The plan adds a dashboard the design does not include."
        )
    approved_skills = {s["name"].casefold() for s in blueprint.get("skills") or []}
    planned_skills = {
        str(p.get("name") or "").casefold()
        for p in by_tool.get("integral_author_skill", [])
    }
    if approved_skills != planned_skills:
        errors.append(
            "Authored skills must match the design exactly: "
            f"missing {sorted(approved_skills - planned_skills)}, "
            f"extra {sorted(planned_skills - approved_skills)}."
        )
    approved_routines = Counter(
        r.get("cron") or r.get("run_at") for r in blueprint.get("routines") or []
    )
    planned_routines = Counter(
        p.get("cron") or p.get("run_at")
        for p in by_tool.get("integral_schedule_task", [])
    )
    if approved_routines != planned_routines:
        errors.append("Scheduled routines must match the design's schedules exactly.")
    return errors
