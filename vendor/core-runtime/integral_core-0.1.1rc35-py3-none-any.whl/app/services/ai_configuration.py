"""Same-user connection and model-profile records, composing the legacy route."""

from __future__ import annotations

import asyncio
import hashlib
import json
from typing import Any

from app.config import settings
from app.models.credentials import (
    UserModelConnection,
    UserModelCredential,
    UserModelProfile,
)
from app.schemas.ai_configuration import ConnectionWrite, ProfileWrite, RoutingWrite
from app.services.credential_crypto import (
    decrypt_secret_from_storage,
    encrypt_secret_for_storage,
)
from app.services.model_credentials import (
    compute_key_fingerprint,
    get_credential_for_user,
    validate_provider_api_key,
)
from app.services.model_provider_endpoints import normalize_custom_base_url
from app.services.model_settings import validate_model_settings
from app.utils.time import utc_now_iso


def _enabled() -> None:
    if settings.INTEGRAL_AGENT_KEY_MODE == "platform_only":
        raise ValueError(
            "This deployment uses shared model configuration; personal BYOK changes are disabled"
        )


async def _find(cls, query: dict[str, Any], *, limit: int):
    from jvspatial.core.context import get_default_context

    context = get_default_context()
    await context.ensure_indexes(cls)
    return await context.find(cls, query, limit=limit)


async def _save_revision(
    item, previous: str | None, *, only: set[str] | None = None
) -> None:
    """CAS private scalar records; a stale editor must never restore old keys."""
    if previous is None:
        await item.save()
        return
    from jvspatial.core.context import get_default_context

    context = get_default_context()
    from jvspatial.core import Object

    values = {
        key: getattr(item, key)
        for key in type(item).model_fields
        if key not in Object.model_fields
    }
    if only is not None:
        values = {key: value for key, value in values.items() if key in only}
    changed = await context.database.find_one_and_update(
        "object",
        {
            "id": item.id,
            "context.user_id": item.user_id,
            "context.updated_at": previous,
        },
        {"$set": {f"context.{key}": value for key, value in values.items()}},
    )
    if changed is None:
        raise ValueError("Configuration changed while editing. Reload and try again.")


async def _owned(cls, user_id: str, item_id: str):
    item = await cls.get(item_id)
    if item is None or not isinstance(item, cls) or item.user_id != user_id:
        raise ValueError("Configuration item is unavailable")
    return item


def _connection_view(item) -> dict[str, Any]:
    return {
        key: getattr(item, key)
        for key in (
            "id",
            "name",
            "provider",
            "base_url",
            "key_fingerprint",
            "validated_at",
            "updated_at",
            "last_test_ok",
            "last_tested_at",
        )
    }


def _profile_view(item) -> dict[str, Any]:
    return {
        key: getattr(item, key)
        for key in (
            "id",
            "name",
            "connection_id",
            "model",
            "generation_settings",
            "updated_at",
        )
    }


async def _legacy_profile(user_id: str, record) -> str:
    """Idempotently snapshot legacy state without changing execution or secrets.

    Object records have no graph/cascade role (I-GRAPH-02). Do not rewrite the
    legacy record during a GET: concurrent activation must not be overwritten.
    """
    identity = json.dumps(
        [
            record.id,
            record.provider,
            record.base_url,
            record.api_key_enc,
            record.model,
            record.generation_settings,
        ],
        sort_keys=True,
    )
    key = hashlib.sha256(identity.encode()).hexdigest()
    connection_id = f"o.UserModelConnection.legacy-{key}"
    profile_id = f"o.UserModelProfile.legacy-{key}"
    await UserModelConnection.create_if_absent(
        id=connection_id,
        user_id=user_id,
        name=f"{record.provider} connection",
        provider=record.provider,
        base_url=record.base_url,
        api_key_enc=record.api_key_enc,
        key_fingerprint=record.key_fingerprint,
        validated_at=record.validated_at or "",
        updated_at=record.updated_at or "",
    )
    await UserModelProfile.create_if_absent(
        id=profile_id,
        user_id=user_id,
        connection_id=connection_id,
        name="Current model",
        model=record.model,
        generation_settings=record.generation_settings,
        updated_at=record.updated_at or "",
    )
    return profile_id


async def configuration(user_id: str) -> dict[str, Any]:
    """List private connections, profiles, default selection, and host ceilings."""
    record = await get_credential_for_user(user_id)
    default_id = ""
    if record and record.is_active:
        default_id = record.active_profile_id or await _legacy_profile(user_id, record)
    connections = await _find(
        UserModelConnection, {"context.user_id": user_id}, limit=101
    )
    profiles = await _find(UserModelProfile, {"context.user_id": user_id}, limit=101)
    return {
        "connections": [_connection_view(c) for c in connections],
        "profiles": [_profile_view(p) for p in profiles],
        "default_profile_id": default_id,
        "routing": {
            "mode": record.routing_mode if record else "single",
            "light_profile_id": record.light_profile_id if record else "",
            "heavy_profile_id": default_id,
            "revision": record.updated_at or "" if record else "",
        },
        "key_policy": settings.INTEGRAL_AGENT_KEY_MODE,
        "harness_limits": {
            "request_limit": settings.INTEGRAL_NATIVE_TURN_REQUEST_LIMIT,
            "token_limit": settings.INTEGRAL_NATIVE_TURN_TOKEN_LIMIT,
            "run_seconds": settings.INTEGRAL_HARNESS_CHAT_TURN_TIMEOUT_SECONDS,
            "request_timeout": settings.INTEGRAL_NATIVE_MODEL_REQUEST_TIMEOUT_SECONDS,
            "idle_timeout": settings.INTEGRAL_NATIVE_MODEL_IDLE_TIMEOUT_SECONDS,
        },
    }


async def save_connection(user_id: str, body: ConnectionWrite) -> dict[str, Any]:
    """Validate and save an owned provider connection without exposing its secret."""
    _enabled()
    existing = await _owned(UserModelConnection, user_id, body.id) if body.id else None
    if (
        not existing
        and len(
            await _find(UserModelConnection, {"context.user_id": user_id}, limit=101)
        )
        >= 100
    ):
        raise ValueError("Remove an unused connection before adding another")
    base = (
        normalize_custom_base_url(body.base_url)
        if body.provider == "custom_openai"
        else ""
    )
    if body.provider != "custom_openai" and body.base_url:
        raise ValueError("Custom endpoints belong to an OpenAI-compatible connection")
    if body.without_key and body.provider not in {"custom_openai", "ollama_local"}:
        raise ValueError("This provider requires an API key")
    if existing and (existing.provider != body.provider or existing.base_url != base):
        raise ValueError("Add a new connection to change its provider or endpoint")
    previous = existing.updated_at if existing else None
    key = (body.api_key or "").strip()
    if body.provider == "ollama_local" and key:
        raise ValueError("Local Ollama does not use an API key")
    if not key and not body.without_key and body.provider != "ollama_local":
        if (
            existing
            and existing.provider == body.provider
            and existing.base_url == base
        ):
            key = (
                decrypt_secret_from_storage(existing.api_key_enc, aad=user_id)
                if existing.api_key_enc
                else ""
            )
        if not key:
            raise ValueError(
                "Supply a key, or explicitly choose a keyless local/custom endpoint"
            )
    if key and body.without_key:
        raise ValueError("Choose either a key or a keyless connection")
    valid, message = await validate_provider_api_key(body.provider, key, base or None)
    if not valid:
        raise ValueError(message)
    item = existing or UserModelConnection(user_id=user_id)
    # Rebinding an existing connection could send every referencing profile to
    # another endpoint. Require a distinct connection rather than moving keys.
    if existing and (item.provider != body.provider or item.base_url != base):
        raise ValueError("Add a new connection to change its provider or endpoint")
    item.name, item.provider, item.base_url = body.name.strip(), body.provider, base
    if not item.name:
        raise ValueError("Connection name cannot be blank")
    item.api_key_enc = encrypt_secret_for_storage(key, aad=user_id) if key else ""
    item.key_fingerprint = compute_key_fingerprint(key)
    item.validated_at = item.updated_at = item.last_tested_at = utc_now_iso()
    item.last_test_ok = True
    await _save_revision(item, previous)
    record = await get_credential_for_user(user_id)
    if record and record.is_active:
        default_id = record.active_profile_id or await _legacy_profile(user_id, record)
        profile = await _owned(UserModelProfile, user_id, default_id)
        if profile.connection_id == item.id:
            await activate_profile(user_id, profile.id, expected_profile_id=default_id)
    return _connection_view(item)


async def test_connection(user_id: str, item_id: str) -> dict[str, Any]:
    """Test the owned saved connection using its server-side secret."""
    connection = await _owned(UserModelConnection, user_id, item_id)
    previous = connection.updated_at
    key = (
        decrypt_secret_from_storage(connection.api_key_enc, aad=user_id)
        if connection.api_key_enc
        else ""
    )
    if connection.api_key_enc and not key:
        raise ValueError("The saved key could not be read; replace it")
    valid, message = await validate_provider_api_key(
        connection.provider, key, connection.base_url or None
    )
    connection.last_test_ok = valid
    connection.last_tested_at = utc_now_iso()
    if valid:
        connection.validated_at = connection.last_tested_at
    await _save_revision(
        connection, previous, only={"last_test_ok", "last_tested_at", "validated_at"}
    )
    return {"valid": valid, "message": message}


async def save_profile(user_id: str, body: ProfileWrite) -> dict[str, Any]:
    """Validate and save model options against the owned provider connection."""
    _enabled()
    connection = await _owned(UserModelConnection, user_id, body.connection_id)
    configured = await asyncio.to_thread(
        validate_model_settings,
        connection.provider,
        body.model.strip(),
        body.generation_settings.model_dump(exclude_none=True),
    )
    profile = (
        await _owned(UserModelProfile, user_id, body.id)
        if body.id
        else UserModelProfile(user_id=user_id)
    )
    if (
        not body.id
        and len(await _find(UserModelProfile, {"context.user_id": user_id}, limit=101))
        >= 100
    ):
        raise ValueError("Remove an unused profile before adding another")
    if not body.name.strip() or not body.model.strip():
        raise ValueError("Profile name and model ID cannot be blank")
    record = await get_credential_for_user(user_id)
    default_id = (
        (record.active_profile_id or await _legacy_profile(user_id, record))
        if record and record.is_active
        else ""
    )
    previous = profile.updated_at if body.id else None
    profile.name, profile.connection_id, profile.model = (
        body.name.strip(),
        connection.id,
        body.model.strip(),
    )
    profile.generation_settings, profile.updated_at = configured, utc_now_iso()
    if (
        record
        and record.routing_mode == "light_heavy"
        and profile.id in {default_id, record.light_profile_id}
    ):
        (
            await asyncio.to_thread(
                _require_structured_support, connection.provider, profile.model
            )
        )
    await _save_revision(profile, previous)
    record = await get_credential_for_user(user_id)
    if record and record.is_active and default_id == profile.id:
        await activate_profile(user_id, profile.id, expected_profile_id=default_id)
    return _profile_view(profile)


async def activate_profile(
    user_id: str,
    item_id: str,
    *,
    expected_profile_id: str | None = None,
    routing: RoutingWrite | None = None,
) -> None:
    """Select an owned default profile while preserving voice credentials."""
    _enabled()
    profile = await _owned(UserModelProfile, user_id, item_id)
    connection = await _owned(UserModelConnection, user_id, profile.connection_id)
    configured = await asyncio.to_thread(
        validate_model_settings,
        connection.provider,
        profile.model,
        profile.generation_settings,
    )
    if connection.api_key_enc and not decrypt_secret_from_storage(
        connection.api_key_enc, aad=user_id
    ):
        raise ValueError("The saved key could not be read; replace it")
    record = await get_credential_for_user(user_id)
    previous = record.updated_at if record else None
    if routing is not None and routing.revision != (previous or ""):
        raise ValueError("Configuration changed while editing. Reload and try again.")
    if expected_profile_id is not None:
        if not record or not record.is_active:
            return
        current = record.active_profile_id or await _legacy_profile(user_id, record)
        if current != expected_profile_id:
            return
    record = record or UserModelCredential(user_id=user_id)
    if routing is not None:
        record.routing_mode = routing.mode
        record.light_profile_id = routing.light_profile_id
    if record.routing_mode == "light_heavy":
        if not record.light_profile_id:
            raise ValueError("Choose a light model before enabling automatic routing")
        light = await profile_credential(user_id, record.light_profile_id, record)
        if light.api_key_enc and not decrypt_secret_from_storage(
            light.api_key_enc, aad=user_id
        ):
            raise ValueError("The light provider key could not be read; replace it")
        (
            await asyncio.to_thread(
                _require_structured_support, light.provider, light.model
            )
        )
        (
            await asyncio.to_thread(
                _require_structured_support, connection.provider, profile.model
            )
        )
    if record.speech_model and not record.speech_api_key_enc:
        record.speech_provider = record.speech_provider or record.provider
        record.speech_api_key_enc = record.api_key_enc
        record.speech_key_fingerprint = record.key_fingerprint
    record.provider, record.base_url, record.model = (
        connection.provider,
        connection.base_url,
        profile.model,
    )
    record.api_key_enc, record.key_fingerprint = (
        connection.api_key_enc,
        connection.key_fingerprint,
    )
    record.generation_settings, record.active_profile_id = configured, profile.id
    record.is_active, record.validated_at = True, connection.validated_at or None
    record.updated_at = utc_now_iso()
    if not record.created_at:
        record.created_at = record.updated_at
    await _save_revision(
        record,
        previous,
        only={
            "provider",
            "base_url",
            "model",
            "api_key_enc",
            "key_fingerprint",
            "generation_settings",
            "active_profile_id",
            "routing_mode",
            "light_profile_id",
            "is_active",
            "validated_at",
            "updated_at",
            "created_at",
            "speech_provider",
            "speech_api_key_enc",
            "speech_key_fingerprint",
        },
    )


async def remove_item(user_id: str, item_id: str, *, connection: bool) -> None:
    """Refuse removal of referenced private configuration."""
    _enabled()
    cls = UserModelConnection if connection else UserModelProfile
    item = await _owned(cls, user_id, item_id)
    if connection:
        from app.models.nodes import WorkspaceModelConfiguration

        references = await _find(
            WorkspaceModelConfiguration,
            {
                "$or": [
                    {"context.embedding_settings.connection_id": item.id},
                    {"context.voice_settings.connection_id": item.id},
                ]
            },
            limit=1001,
        )
        from app.services.retrieval.embedding_configuration import owner_subject

        # A former workspace owner must retain control of their private key.
        # Stale references after transfer cannot fund requests and must not
        # make revocation depend on the replacement owner's cooperation.
        if len(references) > 1000:
            raise ValueError("This provider has too many references to remove safely")
        for reference in references:
            if await owner_subject(reference.workspace_id) == user_id:
                raise ValueError(
                    "Reassign workspace embedding or voice models before removing this provider"
                )
        profiles = await _find(
            UserModelProfile,
            {"context.user_id": user_id, "context.connection_id": item.id},
            limit=1,
        )
        if profiles:
            raise ValueError(
                "Remove or reassign the profiles using this connection first"
            )
    else:
        record = await get_credential_for_user(user_id)
        if (
            record
            and record.is_active
            and (
                record.active_profile_id == item.id
                or (
                    not record.active_profile_id
                    and item.id == await _legacy_profile(user_id, record)
                )
            )
        ):
            raise ValueError(
                "Choose another default model before removing this profile"
            )
        if record and record.light_profile_id == item.id:
            raise ValueError(
                "Clear or reassign the light model before removing this profile"
            )
        from app.models.nodes import ChatThread

        if await _find(
            ChatThread,
            {"context.user_id": user_id, "context.model_profile_id": item.id},
            limit=1,
        ):
            raise ValueError(
                "Reset conversation overrides using this profile before removing it"
            )
    await item.delete()


async def profile_credential(user_id: str, profile_id: str, record):
    """Resolve an owned profile without mutating the user's saved default."""
    profile = await _owned(UserModelProfile, user_id, profile_id)
    connection = await _owned(UserModelConnection, user_id, profile.connection_id)
    configured = await asyncio.to_thread(
        validate_model_settings,
        connection.provider,
        profile.model,
        profile.generation_settings,
    )
    return record.model_copy(
        update={
            "provider": connection.provider,
            "base_url": connection.base_url,
            "model": profile.model,
            "generation_settings": configured,
            "api_key_enc": connection.api_key_enc,
            "key_fingerprint": connection.key_fingerprint,
            "updated_at": profile.updated_at + ":" + connection.updated_at,
            "active_profile_id": profile.id,
        }
    )


async def conversation_model(
    user_id: str,
    thread_id: str,
    profile_id: str | None = None,
    *,
    routing_mode: str | None = None,
    reasoning_efforts: dict[str, str | None] | None = None,
) -> dict[str, Any]:
    """Read or change an owned idle conversation model selection."""
    from app.models.nodes import ChatThread
    from app.services.permissions import get_user_node
    from app.services.workspace_permissions import (
        can_access_workspace,
        get_workspace_owner_user_id,
    )

    thread = await ChatThread.get(thread_id)
    if (
        thread is None
        or thread.user_id != user_id
        or await can_access_workspace(user_id, thread.workspace_id) == "none"
    ):
        raise ValueError("Conversation is unavailable")
    owner_id = await get_workspace_owner_user_id(thread.workspace_id)
    owner = await get_user_node(owner_id) if owner_id else None
    editable = bool(
        owner
        and owner.user_id == user_id
        and settings.INTEGRAL_AGENT_KEY_MODE != "platform_only"
    )
    selection_change = profile_id is not None or routing_mode is not None
    if selection_change or reasoning_efforts is not None:
        _enabled()
        profile_id = (profile_id or "") if selection_change else thread.model_profile_id
        selected_mode = (
            (routing_mode or ("profile" if profile_id else "inherit"))
            if selection_change
            else ("profile" if thread.model_profile_id else thread.model_routing_mode)
        )
        if (selected_mode == "profile") != bool(profile_id):
            raise ValueError("Choose a profile for fixed model routing")
        if not editable:
            raise ValueError(
                "This conversation uses its workspace owner's model settings"
            )
        if profile_id:
            record = await get_credential_for_user(user_id)
            if record is None or not record.is_active:
                raise ValueError(
                    "Choose a default model before setting a conversation override"
                )
            await profile_credential(user_id, profile_id, record)
        from app.agentive.harness.model_route import resolve_native_model_route
        from app.agentive.harness.model_routing import (
            applicable_reasoning_efforts,
            apply_conversation_reasoning,
            resolve_turn_routes,
        )

        efforts = {} if selection_change else dict(thread.model_reasoning_efforts)
        if reasoning_efforts is not None:
            for role, effort in reasoning_efforts.items():
                if role not in {"heavy", "light"}:
                    raise ValueError("Unknown conversation model role")
                if effort is None:
                    efforts.pop(role, None)
                else:
                    efforts[role] = effort
        if efforts:
            plan = await resolve_turn_routes(
                workspace_id=thread.workspace_id,
                profile_id=profile_id,
                heavy_only=selected_mode == "heavy",
                resolver=resolve_native_model_route,
            )
            # New choices are strict; older preferences fall back to the current
            # profile when the workspace owner changes models or routing mode.
            await asyncio.to_thread(
                apply_conversation_reasoning,
                plan,
                {
                    role: effort
                    for role, effort in (reasoning_efforts or {}).items()
                    if effort is not None
                },
            )
            efforts = await asyncio.to_thread(
                applicable_reasoning_efforts, plan, efforts
            )
        # Field-only CAS: never overwrite an admission pointer from a stale
        # hydrated thread while another request starts a turn.
        from jvspatial.core.context import get_default_context

        if thread.active_work_item_id:
            raise ValueError(
                "Wait for the current turn to finish before switching models"
            )
        changed = await get_default_context().database.find_one_and_update(
            "node",
            {
                "id": thread.id,
                "entity": "ChatThread",
                "context.user_id": user_id,
                "$or": [
                    {"context.active_work_item_id": ""},
                    {"context.active_work_item_id": {"$exists": False}},
                ],
            },
            {
                "$set": {
                    "context.model_profile_id": profile_id,
                    "context.model_routing_mode": selected_mode,
                    "context.model_reasoning_efforts": efforts,
                }
            },
        )
        if changed is None:
            raise ValueError(
                "The conversation changed; wait for its current turn to finish"
            )
        thread.model_profile_id = profile_id
        thread.model_routing_mode = selected_mode
        thread.model_reasoning_efforts = efforts
    choices = {}
    active_efforts = {}
    if editable:
        from app.agentive.harness.model_route import resolve_native_model_route
        from app.agentive.harness.model_routing import (
            applicable_reasoning_efforts,
            reasoning_choices,
            resolve_turn_routes,
        )
        from app.api.errors import ServiceUnavailableError
        from app.services.model_credential_resolver import ModelKeyRequiredError

        try:
            plan = await resolve_turn_routes(
                workspace_id=thread.workspace_id,
                profile_id=thread.model_profile_id,
                heavy_only=thread.model_routing_mode == "heavy",
                resolver=resolve_native_model_route,
            )
            choices = await asyncio.to_thread(reasoning_choices, plan)
            active_efforts = await asyncio.to_thread(
                applicable_reasoning_efforts, plan, thread.model_reasoning_efforts
            )
        except (ValueError, ServiceUnavailableError, ModelKeyRequiredError):
            # Optional controls must not prevent model selection/reset when setup needs repair.
            choices = {}
    return {
        **(
            {
                "reasoning_efforts": active_efforts,
                "reasoning_choices": choices,
            }
            if editable and (choices or thread.model_reasoning_efforts)
            else {}
        ),
        "profile_id": thread.model_profile_id if editable else "",
        "editable": editable,
        "routing_mode": (
            ("profile" if thread.model_profile_id else thread.model_routing_mode)
            if editable
            else "inherit"
        ),
    }


async def save_routing(user_id: str, body: RoutingWrite) -> None:
    """Validate both role assignments and commit one credential revision."""
    _enabled()
    if body.light_profile_id:
        record = await get_credential_for_user(user_id) or UserModelCredential(
            user_id=user_id
        )
        await profile_credential(user_id, body.light_profile_id, record)
    await activate_profile(user_id, body.heavy_profile_id, routing=body)


def _require_structured_support(provider: str, model: str) -> None:
    from app.services.model_settings import model_capabilities

    if model_capabilities(provider, model).get("tool_calling") is False:
        raise ValueError(
            "Automatic routing requires structured tool support; choose another model or Single model"
        )
