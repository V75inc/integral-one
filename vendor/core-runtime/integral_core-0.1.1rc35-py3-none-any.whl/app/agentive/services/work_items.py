"""Deterministic WorkItem enqueue, transitions, and lease authority."""

from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
from contextlib import asynccontextmanager
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator, Dict, Optional

from app.agentive.work_models import WorkItem
from app.schemas.agentive.work import (
    RetryPolicy,
    WorkError,
    WorkFailure,
    WorkKind,
    WorkStatus,
)
from app.utils.time import utc_now_iso

DEFAULT_LEASE_SECONDS = 30.0
CLAIM_PAGE_SIZE = 32
CLAIM_PAGES_PER_STATUS = 2
TOPIC_LEASE_RECLAIMED = "work.lease_reclaimed"
RETRYABLE_FAILURE_CLASSES = frozenset(
    {"transient", "rate_limited", "dependency_unavailable"}
)


def work_item_object_id(
    *,
    kind: str,
    origin: str,
    principal_id: str,
    workspace_id: str,
    idempotency_key: str,
) -> str:
    """Deterministic Object id for a WorkItem identity tuple."""
    canonical = json.dumps(
        [kind, origin, principal_id, workspace_id, idempotency_key],
        separators=(",", ":"),
        sort_keys=False,
    )
    return "o.WorkItem." + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def input_fingerprint(payload: Dict[str, Any]) -> str:
    """Stable fingerprint of immutable enqueue input."""
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return "sha256:" + hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def continuation_fingerprint(
    *,
    input_payload: Dict[str, Any],
    plan_revision: Optional[str] = None,
    plan: Optional[Dict[str, Any]] = None,
    dependency_work_item_ids: Optional[list[str]] = None,
    precommit_draft: Optional[Dict[str, Any]] = None,
    remaining_obligations: Optional[list[Dict[str, Any]]] = None,
    app_id: Optional[str] = None,
    definition_id: Optional[str] = None,
) -> str:
    """Fingerprint the entire immutable continuation request.

    One idempotency key names one revision-bound plan, not merely one adapter
    payload. A changed dependency or obligation must therefore fail closed.
    """
    return input_fingerprint(
        {
            "input_payload": dict(input_payload or {}),
            "plan_revision": str(plan_revision or ""),
            "plan": dict(plan or {}),
            "dependency_work_item_ids": sorted(
                str(value) for value in (dependency_work_item_ids or [])
            ),
            "precommit_draft": dict(precommit_draft or {}),
            "remaining_obligations": list(remaining_obligations or []),
            "app_id": str(app_id or ""),
            "definition_id": str(definition_id or ""),
        }
    )


async def resolve_active_definition_binding(
    *,
    app_id: str,
    workspace_id: str,
    requested_definition_id: Optional[str] = None,
) -> str:
    """Resolve the exact active contract for App-bound work.

    A retryable work request must never float with the mutable App profile.
    The active revision is captured at enqueue, constrained to the request's
    workspace, and later rechecked at the effect boundary.
    """
    from app.models.nodes import App
    from app.services.application_definitions import get_active_application_definition

    app_node = await App.get(app_id)
    if app_node is None:
        raise WorkError("work.app_not_found", f"app {app_id} not found")
    if str(getattr(app_node, "workspace_id", "") or "") != workspace_id:
        raise WorkError(
            "work.app_workspace_mismatch",
            "App does not belong to the requested workspace",
        )
    definition = await get_active_application_definition(app_node)
    if definition is None:
        raise WorkError(
            "work.definition_required",
            "App-bound work requires an active application definition",
        )
    active_definition_id = str(definition.id)
    if requested_definition_id and requested_definition_id != active_definition_id:
        raise WorkError(
            "work.definition_stale",
            "Requested definition is not the App's active definition; replan first",
        )
    return active_definition_id


def recommended_heartbeat_interval(lease_seconds: float) -> float:
    """Heartbeat must run at an interval no greater than lease/3."""
    if lease_seconds <= 0:
        raise ValueError("lease_seconds must be > 0")
    return float(lease_seconds) / 3.0


def _parse_lease_timestamp(value: str | None) -> datetime | None:
    raw = (value or "").strip()
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed


_held_effect_fence: ContextVar[tuple[Any, Any, Any] | None] = ContextVar(
    "integral_held_effect_fence", default=None
)


def _execution_authority(context: Any) -> tuple[Any, ...]:
    return tuple(
        getattr(context, name)
        for name in (
            "work_item_id",
            "attempt",
            "run_id",
            "principal_id",
            "workspace_id",
            "thread_id",
            "lease_token",
            "lease_fence",
            "deadline_at",
        )
    )


def _owns_effect_fence(context: Any, transaction: Any = None) -> bool:
    held = _held_effect_fence.get()
    return bool(
        held is not None
        and held[0] == _execution_authority(context)
        and held[2] is asyncio.current_task()
        and (transaction is None or held[1] is transaction)
    )


async def refresh_owned_effect_lease(context: Any) -> None:
    """Renew a nested preflight only under this task's already-held fence."""
    if _owns_effect_fence(context):
        async with authorized_work_item_effect(context):
            pass


async def _current_work_item(
    work_item_id: str, *, database: Any = None
) -> WorkItem | None:
    """Authority comes from current storage, never an identity-cached lease."""
    from jvspatial.core.context import get_default_context

    from app.agentive.services.work_outbox import _hydrate_work_item

    store = database if database is not None else get_default_context().database
    document = await store.get("object", _object_id(work_item_id))
    if document is None:
        return None
    if document.get("entity") != WorkItem._entity_name():
        raise WorkError("work.not_found", "work item not found")
    return _hydrate_work_item(document)


@asynccontextmanager
async def authorized_work_item_effect(
    context: Any,
) -> AsyncIterator[Any]:
    """Hold a PostgreSQL transaction that fences one durable-work effect.

    The WorkItem row is conditionally updated inside the same transaction as
    the effect writes performed by the caller. This obtains the row lock before
    yielding; cancellation, lease renewal, and lease reclamation serialize
    against the effect. The caller's jvspatial Object/Node writes use the
    transaction-bound default GraphContext until the context exits.

    This is intentionally unavailable for non-transactional databases. A
    preflight lease read followed by an unfenced write is not an acceptable
    substitute for durable worker effects.
    """
    from jvspatial.core.context import get_default_context

    from app.agentive.services.work_execution import (
        deterministic_run_id,
        effect_key,
    )
    from app.schemas.agentive.work import WorkExecutionContext
    from app.services.app_operations.transaction_scope import (
        postgres_graph_transaction,
    )

    if not isinstance(context, WorkExecutionContext):
        raise TypeError("a trusted WorkExecutionContext is required")
    if context.cancellation_signal:
        raise WorkError("work.cancelled", "cancel requested")
    if not context.lease_token or context.lease_fence < 1:
        raise WorkError("work.lease_lost", "execution lease is unavailable")

    async with postgres_graph_transaction(
        database=get_default_context().database
    ) as transaction:
        graph = get_default_context()
        item = await _current_work_item(context.work_item_id, database=transaction)
        if item is None:
            raise WorkError("work.not_found", "work item not found")
        now = datetime.now(timezone.utc)
        if item.status != "running":
            raise WorkError("work.lease_lost", "execution is no longer running")
        if (
            item.attempt != context.attempt
            or item.principal_id != context.principal_id
            or item.workspace_id != context.workspace_id
            or (item.thread_id or "") != context.thread_id
            or item.lease_token != context.lease_token
            or int(item.lease_fence or 0) != context.lease_fence
            or (item.deadline_at or None) != context.deadline_at
            or context.run_id
            != deterministic_run_id(
                work_item_id=item.work_item_id,
                attempt=int(item.attempt or 0),
            )
            or context.effect_key
            != effect_key(
                work_item_id=item.work_item_id,
                logical_step_key=context.logical_step_key,
            )
        ):
            raise WorkError("work.lease_lost", "execution lease is no longer current")
        if item.cancel_requested_at:
            raise WorkError("work.cancelled", "cancel requested")
        lease_expiry = _parse_lease_timestamp(item.lease_expires_at)
        if lease_expiry is None or (
            lease_expiry <= now and not _owns_effect_fence(context, transaction)
        ):
            raise WorkError("work.lease_lost", "execution lease expired")
        deadline = _parse_lease_timestamp(context.deadline_at or item.deadline_at)
        if deadline is not None and deadline <= now:
            raise WorkError("work.deadline_exceeded", "execution deadline passed")
        if (
            lease_expiry is not None
            and lease_expiry <= now
            and _owns_effect_fence(context, transaction)
        ):
            renewed = now + timedelta(seconds=DEFAULT_LEASE_SECONDS)
            if deadline is not None:
                renewed = min(renewed, deadline)
            await _cas_lease_fence_in_transaction(
                context=context,
                lease_expires_at=item.lease_expires_at,
                transaction=transaction,
                renew_until=renewed.isoformat(),
            )
            item.lease_expires_at = renewed.isoformat()
            lease_expiry = renewed
        if lease_expiry is None or lease_expiry <= now:
            raise WorkError("work.lease_lost", "execution lease expired")

        # The CAS holds the authoritative WorkItem row lock until all effect
        # writes in the yielded transaction commit. Keep token values out of
        # normalized errors because the generic CAS diagnostics include values.
        try:
            await _cas_lease_fence_in_transaction(
                context=context,
                lease_expires_at=item.lease_expires_at,
                transaction=transaction,
            )
        except WorkError as exc:
            if exc.code in {"work.lease_lost", "work.cas_conflict"}:
                raise WorkError(
                    "work.lease_lost", "execution lease is no longer current"
                ) from None
            raise
        from app.agentive.services.routine_work_admission import (
            assert_routine_work_current,
        )

        await assert_routine_work_current(item, lock=True)
        held_token = _held_effect_fence.set(
            (_execution_authority(context), transaction, asyncio.current_task())
        )
        try:
            yield graph
            # The effect owns the WorkItem row lock until this transaction commits.
            # An independent heartbeat must wait for that lock. Refresh the same
            # fenced lease before releasing it, even if time elapsed while locked;
            # no competing claimant can have acquired this row in the meantime.
            # A crashed transaction rolls back and leaves the old lease reclaimable.
            now = datetime.now(timezone.utc)
            if deadline is not None and deadline <= now:
                raise WorkError("work.deadline_exceeded", "execution deadline passed")
            current = await transaction.get("object", _object_id(context.work_item_id))
            fields = (current or {}).get("context") or {}
            if fields.get("status") == "running":
                expiry = _parse_lease_timestamp(fields.get("lease_expires_at"))
                renewed = now + timedelta(seconds=DEFAULT_LEASE_SECONDS)
                if deadline is not None:
                    renewed = min(renewed, deadline)
                if expiry is not None and expiry < renewed:
                    await _cas_lease_fence_in_transaction(
                        context=context,
                        lease_expires_at=fields["lease_expires_at"],
                        transaction=transaction,
                        renew_until=renewed.isoformat(),
                    )
        finally:
            _held_effect_fence.reset(held_token)


async def assert_work_item_execution_current(context: Any) -> None:
    """Check durable authority immediately before publishing worker output.

    Output delivery cannot share a database transaction with a remote client,
    but the assertion serializes with cancellation and lease reclamation. The
    caller must invoke it at each publication boundary; persistent effects
    must still use ``authorized_work_item_effect`` around their write.
    """
    async with authorized_work_item_effect(context):
        return None


async def _cas_lease_fence_in_transaction(
    *,
    context: Any,
    lease_expires_at: str,
    transaction: Any,
    renew_until: str | None = None,
) -> None:
    from app.agentive.services.work_outbox import cas_work_item_update

    expected = {
        "status": "running",
        "attempt": context.attempt,
        "principal_id": context.principal_id,
        "workspace_id": context.workspace_id,
        "thread_id": context.thread_id,
        "deadline_at": context.deadline_at or "",
        "lease_token": context.lease_token,
        "lease_fence": context.lease_fence,
        "cancel_requested_at": "",
    }
    expiry = lease_expires_at
    for retry in range(3):
        try:
            await cas_work_item_update(
                context.work_item_id,
                expected={**expected, "lease_expires_at": expiry},
                updates={"lease_expires_at": renew_until} if renew_until else {},
                error_code="work.lease_lost",
                transaction=transaction,
            )
            return
        except WorkError as exc:
            if retry == 2 or exc.code not in {"work.lease_lost", "work.cas_conflict"}:
                raise
            # A heartbeat may extend expiry between the read and the CAS. It
            # does not change execution authority. Re-read on this same held
            # transaction; retry only a live extension with every scope/fence,
            # cancellation and deadline field still exactly matching.
            current = await transaction.get("object", _object_id(context.work_item_id))
            fields = (current or {}).get("context") or {}
            if any(fields.get(key) != value for key, value in expected.items()):
                raise
            renewed = fields.get("lease_expires_at")
            before = _parse_lease_timestamp(expiry)
            after = _parse_lease_timestamp(renewed)
            now = datetime.now(timezone.utc)
            if before is None or after is None or after <= before or after <= now:
                raise
            deadline = _parse_lease_timestamp(context.deadline_at)
            if deadline is not None and deadline <= now:
                raise WorkError("work.deadline_exceeded", "execution deadline passed")
            expiry = renewed


def compute_retry_delay(
    *,
    work_item_id: str,
    attempt: int,
    retry_policy: RetryPolicy,
) -> float:
    """Deterministic symmetric jitter backoff for failed attempt ``n >= 1``."""
    n = int(attempt)
    if n < 1:
        raise ValueError("attempt must be >= 1 for retry delay")
    base = min(
        retry_policy.max_delay_seconds,
        retry_policy.base_delay_seconds * (2 ** (n - 1)),
    )
    digest = hashlib.sha256(f"{work_item_id}:{n}".encode("utf-8")).digest()
    u = int.from_bytes(digest[:8], "big") / float(2**64)
    factor = (1.0 - retry_policy.jitter_ratio) + (2.0 * retry_policy.jitter_ratio * u)
    return min(retry_policy.max_delay_seconds, base * factor)


def normalize_failure(
    *,
    class_: str,
    code: str,
    message: str = "",
    retryable: Optional[bool] = None,
) -> Dict[str, Any]:
    """Build the stored failure record (`class` key)."""
    from app.schemas.agentive.work import WorkFailure

    retry = (
        bool(retryable)
        if retryable is not None
        else class_ in RETRYABLE_FAILURE_CLASSES
    )
    failure = WorkFailure(
        class_=class_,  # type: ignore[arg-type]
        code=code,
        message=message,
        retryable=retry,
    )
    return failure.model_dump(by_alias=True)


def _deadline_passed(item: WorkItem, now: datetime) -> bool:
    deadline = _parse_iso(item.deadline_at)
    if deadline is None:
        return False
    if deadline.tzinfo is None:
        deadline = deadline.replace(tzinfo=timezone.utc)
    return deadline <= now


async def expire_work_item(work_item_id: str, *, reason: str = "deadline") -> WorkItem:
    """Terminalize an overdue queued/waiting item."""
    from app.agentive.services.work_outbox import (
        TOPIC_TRANSITIONED,
        cas_work_item_update,
    )

    item = await WorkItem.get(_object_id(work_item_id))
    if item is None:
        raise WorkError("work.not_found", f"work item {work_item_id} not found")
    if item.status in ("succeeded", "failed", "cancelled", "expired", "dead_letter"):
        return item
    if item.status not in (
        "queued",
        "retry_wait",
        "waiting_for_human",
        "waiting_for_event",
    ):
        raise WorkError(
            "work.invalid_transition",
            f"cannot expire from status {item.status}",
        )
    return await cas_work_item_update(
        item.work_item_id,
        expected={"status": item.status},
        updates={
            "status": "expired",
            "failure": normalize_failure(
                class_="deadline_exceeded",
                code="work.deadline_exceeded",
                message=reason,
                retryable=False,
            ),
            "lease_token": "",
            "lease_owner": "",
            "lease_expires_at": "",
        },
        outbox_topic=TOPIC_TRANSITIONED,
        outbox_payload={
            "from_status": item.status,
            "to_status": "expired",
        },
        bump_transition_seq=True,
        error_code="work.cas_conflict",
    )


async def schedule_retry(
    work_item_id: str,
    *,
    lease_token: str,
    lease_fence: int,
    failure: WorkFailure,
) -> WorkItem:
    """Move a leased running item to retry_wait or dead_letter."""
    if not isinstance(failure, WorkFailure):
        failure = WorkFailure.model_validate(failure)

    item = await WorkItem.get(_object_id(work_item_id))
    if item is None:
        raise WorkError("work.not_found", f"work item {work_item_id} not found")
    policy = RetryPolicy.model_validate(item.retry_policy or {})
    attempt = int(item.attempt or 0)
    failure_doc = failure.model_dump(by_alias=True)
    retryable = bool(failure.retryable) and failure.class_ in RETRYABLE_FAILURE_CLASSES
    if (not retryable) or attempt >= int(policy.max_attempts):
        target = "dead_letter" if retryable else "failed"
        if failure.class_ in {"permanent", "policy_denied", "non_replayable"}:
            target = "failed"
        if failure.class_ == "non_replayable":
            target = "dead_letter"
        return await transition_leased(
            work_item_id,
            lease_token=lease_token,
            lease_fence=lease_fence,
            expected_status="running",
            target=target,  # type: ignore[arg-type]
            fields={"failure": failure_doc},
        )

    delay = compute_retry_delay(
        work_item_id=item.work_item_id, attempt=attempt, retry_policy=policy
    )
    next_at = (datetime.now(timezone.utc) + timedelta(seconds=delay)).isoformat()
    return await transition_leased(
        work_item_id,
        lease_token=lease_token,
        lease_fence=lease_fence,
        expected_status="running",
        target="retry_wait",
        fields={"failure": failure_doc, "next_attempt_at": next_at},
    )


async def cancel_work_item(work_item_id: str) -> WorkItem:
    """Cancel queued/waiting immediately; request cancel for running work."""
    from app.agentive.services.work_outbox import (
        TOPIC_TRANSITIONED,
        cas_work_item_update,
    )

    item = await WorkItem.get(_object_id(work_item_id))
    if item is None:
        raise WorkError("work.not_found", f"work item {work_item_id} not found")
    if item.status in ("succeeded", "failed", "cancelled", "expired", "dead_letter"):
        return item
    now = utc_now_iso()
    if item.status == "running":
        return await cas_work_item_update(
            item.work_item_id,
            expected={"status": "running", "lease_token": item.lease_token},
            updates={"cancel_requested_at": now},
            error_code="work.cas_conflict",
        )
    if item.status not in (
        "queued",
        "retry_wait",
        "waiting_for_human",
        "waiting_for_event",
    ):
        raise WorkError(
            "work.invalid_transition",
            f"cannot cancel from status {item.status}",
        )
    return await cas_work_item_update(
        item.work_item_id,
        expected={"status": item.status},
        updates={
            "status": "cancelled",
            "cancel_requested_at": now,
            "failure": normalize_failure(
                class_="cancelled",
                code="work.cancelled",
                message="cancelled",
                retryable=False,
            ),
            "lease_token": "",
            "lease_owner": "",
            "lease_expires_at": "",
        },
        outbox_topic=TOPIC_TRANSITIONED,
        outbox_payload={"from_status": item.status, "to_status": "cancelled"},
        bump_transition_seq=True,
        error_code="work.cas_conflict",
    )


def _object_id(work_item_id: str) -> str:
    if work_item_id.startswith("o.WorkItem."):
        return work_item_id
    return f"o.WorkItem.{work_item_id}"


def _bare_id(work_item_id: str) -> str:
    return _object_id(work_item_id).removeprefix("o.WorkItem.")


def _parse_iso(value: str) -> Optional[datetime]:
    raw = (value or "").strip()
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def _lease_expiry(lease_seconds: float, *, now: Optional[datetime] = None) -> str:
    base = now or datetime.now(timezone.utc)
    return (base + timedelta(seconds=float(lease_seconds))).isoformat()


def _is_due(item: WorkItem, now: datetime) -> bool:
    if item.status not in ("queued", "retry_wait"):
        return False
    nxt = _parse_iso(item.next_attempt_at)
    if nxt is None:
        return True
    if nxt.tzinfo is None:
        nxt = nxt.replace(tzinfo=timezone.utc)
    return nxt <= now


async def _dependencies_allow_claim(candidate: WorkItem) -> bool:
    """Gate a work item on successful prerequisites and record terminal gaps."""
    dependency_ids = [str(value) for value in candidate.dependency_work_item_ids]
    if not dependency_ids:
        return True
    blockers = []
    for dependency_id in dependency_ids:
        dependency = await WorkItem.get(_object_id(dependency_id))
        if dependency is None:
            blockers.append({"work_item_id": dependency_id, "status": "missing"})
        elif dependency.status != "succeeded":
            blockers.append(
                {"work_item_id": dependency.work_item_id, "status": dependency.status}
            )
    if not blockers:
        return True
    terminal = {"failed", "cancelled", "expired", "dead_letter", "missing"}
    if any(blocker["status"] in terminal for blocker in blockers):
        try:
            await transition_work_item(
                candidate.work_item_id,
                expected_status=candidate.status,
                target="failed",
                fields={
                    "failure": normalize_failure(
                        class_="permanent",
                        code="work.dependency_unmet",
                        message="a prerequisite cannot complete",
                        retryable=False,
                    ),
                    "remaining_obligations": blockers,
                },
            )
        except WorkError:
            pass
    return False


def _lease_expired(item: WorkItem, now: datetime) -> bool:
    exp = _parse_iso(item.lease_expires_at)
    if exp is None:
        return True
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    return exp <= now


async def enqueue_work_item(
    *,
    kind: WorkKind,
    origin: str,
    principal_id: str,
    workspace_id: str,
    idempotency_key: str,
    input_payload: Optional[Dict[str, Any]] = None,
    plan_revision: Optional[str] = None,
    plan: Optional[Dict[str, Any]] = None,
    dependency_work_item_ids: Optional[list[str]] = None,
    precommit_draft: Optional[Dict[str, Any]] = None,
    remaining_obligations: Optional[list[Dict[str, Any]]] = None,
    thread_id: Optional[str] = None,
    app_id: Optional[str] = None,
    definition_id: Optional[str] = None,
    parent_work_item_id: Optional[str] = None,
    causation_id: Optional[str] = None,
    deadline_at: Optional[str] = None,
    retry_policy: Optional[RetryPolicy] = None,
    transaction: Any = None,
) -> WorkItem:
    """Create or reuse a WorkItem; persists the initial outbox fact atomically."""
    from app.agentive.services.work_outbox import enqueue_work_item_unit

    return await enqueue_work_item_unit(
        kind=kind,
        origin=origin,
        principal_id=principal_id,
        workspace_id=workspace_id,
        idempotency_key=idempotency_key,
        input_payload=input_payload,
        plan_revision=plan_revision,
        plan=plan,
        dependency_work_item_ids=dependency_work_item_ids,
        precommit_draft=precommit_draft,
        remaining_obligations=remaining_obligations,
        thread_id=thread_id,
        app_id=app_id,
        definition_id=definition_id,
        parent_work_item_id=parent_work_item_id,
        causation_id=causation_id,
        deadline_at=deadline_at,
        retry_policy=retry_policy,
        transaction=transaction,
    )


async def transition_work_item(
    work_item_id: str,
    *,
    expected_status: WorkStatus,
    target: WorkStatus,
    fields: Optional[Dict[str, Any]] = None,
    transaction: Any = None,
) -> WorkItem:
    """Apply one legal status transition and emit a transition outbox fact."""
    from app.agentive.services.work_outbox import transition_work_item_unit

    return await transition_work_item_unit(
        work_item_id,
        expected_status=expected_status,
        target=target,
        fields=fields,
        transaction=transaction,
    )


async def claim_due_candidate(
    *,
    worker_id: str,
    lease_seconds: float = DEFAULT_LEASE_SECONDS,
    work_item_id: Optional[str] = None,
    transaction: Any = None,
    kinds: Optional[frozenset[str]] = None,
    exclude_kinds: Optional[frozenset[str]] = None,
    claim_cursor: Optional[dict[str, str]] = None,
) -> Optional[WorkItem]:
    """Claim one due queued/retry_wait WorkItem into ``running`` under a lease.

    ``kinds`` / ``exclude_kinds`` let a worker serve only some kinds (App jobs
    run on their own worker so they never hold up chat or lifecycle work).
    """
    from app.agentive.services.work_outbox import (
        TOPIC_TRANSITIONED,
        cas_work_item_update,
    )

    now_dt = datetime.now(timezone.utc)
    expires = _lease_expiry(lease_seconds, now=now_dt)
    token = secrets.token_urlsafe(16)

    async def _try_claim(candidate: WorkItem) -> Optional[WorkItem]:
        if _deadline_passed(candidate, now_dt):
            try:
                await expire_work_item(candidate.work_item_id)
            except WorkError:
                pass
            return None
        if not _is_due(candidate, now_dt):
            return None
        if not await _dependencies_allow_claim(candidate):
            return None
        if candidate.cancel_requested_at:
            try:
                await cancel_work_item(candidate.work_item_id)
            except WorkError:
                pass
            return None
        from_status = candidate.status
        try:
            return await cas_work_item_update(
                candidate.work_item_id,
                expected={
                    "status": from_status,
                    "attempt": int(candidate.attempt or 0),
                    "lease_fence": int(candidate.lease_fence or 0),
                },
                updates={
                    "status": "running",
                    "attempt": int(candidate.attempt or 0) + 1,
                    "lease_owner": worker_id,
                    "lease_token": token,
                    "lease_fence": int(candidate.lease_fence or 0) + 1,
                    "lease_expires_at": expires,
                },
                outbox_topic=TOPIC_TRANSITIONED,
                outbox_payload={
                    "from_status": from_status,
                    "to_status": "running",
                    "lease_owner": worker_id,
                },
                bump_transition_seq=True,
                error_code="work.cas_conflict",
                transaction=transaction,
            )
        except WorkError as exc:
            if exc.code in ("work.cas_conflict", "work.lease_lost"):
                return None
            raise

    if work_item_id:
        item = await WorkItem.get(_object_id(work_item_id))
        if item is None:
            return None
        # A worker that serves only some kinds never takes another, by id either.
        if kinds is not None and item.kind not in kinds:
            return None
        if exclude_kinds is not None and item.kind in exclude_kinds:
            return None
        return await _try_claim(item)

    from jvspatial.core.context import get_default_context

    from app.agentive.services.work_outbox import _hydrate_work_item

    context = get_default_context()
    await context.ensure_indexes(WorkItem)
    cursors = claim_cursor if claim_cursor is not None else {}
    for status in ("queued", "retry_wait"):
        for _ in range(CLAIM_PAGES_PER_STATUS):
            query: dict[str, Any] = {
                "entity": WorkItem._entity_name(),
                "context.status": status,
            }
            kind_filter = {}
            if kinds is not None:
                kind_filter["$in"] = sorted(kinds)
            if exclude_kinds:
                kind_filter["$nin"] = sorted(exclude_kinds)
            if kind_filter:
                query["context.kind"] = kind_filter
            if cursors.get(status):
                query["id"] = {"$gt": cursors[status]}
            rows = await context.database.find(
                "object", query, sort=[("id", 1)], limit=CLAIM_PAGE_SIZE
            )
            if not rows:
                cursors.pop(status, None)
                break
            for row in rows:
                # Advance even past blocked/future/racing candidates. A worker
                # retains only two scalar cursors, never a hydrated backlog.
                cursors[status] = row["id"]
                won = await _try_claim(_hydrate_work_item(row))
                if won is not None:
                    return won
            if len(rows) < CLAIM_PAGE_SIZE:
                cursors.pop(status, None)
                break
    return None


async def heartbeat_lease(
    work_item_id: str,
    *,
    lease_token: str,
    lease_fence: int,
    worker_id: str,
    lease_seconds: float = DEFAULT_LEASE_SECONDS,
    transaction: Any = None,
) -> WorkItem:
    """Extend lease expiry when token and fence still match."""
    from jvspatial.core.context import get_default_context

    from app.agentive.services.work_outbox import (
        _hydrate_work_item,
        cas_work_item_update,
    )
    from app.services.app_operations.transaction_scope import (
        _transaction_database,
        postgres_graph_transaction,
    )

    database = _transaction_database(get_default_context().database)
    if transaction is None and getattr(database, "supports_transactions", False):
        async with postgres_graph_transaction(database) as held:
            return await heartbeat_lease(
                work_item_id,
                lease_token=lease_token,
                lease_fence=lease_fence,
                worker_id=worker_id,
                lease_seconds=lease_seconds,
                transaction=held,
            )
    if transaction is not None:
        # Wait for a same-fence effect's row lock before deciding expiry. That
        # effect may renew on commit; reading its old committed expiry first
        # would incorrectly cancel a live worker while renewal is blocked.
        document = await transaction.find_one_and_update(
            "object",
            {
                "id": _object_id(work_item_id),
                "entity": WorkItem._entity_name(),
                "context.status": "running",
                "context.lease_token": lease_token,
                "context.lease_fence": int(lease_fence),
                "context.lease_owner": worker_id,
                "context.cancel_requested_at": "",
            },
            {"$set": {}},
        )
        if document is None:
            current = await _current_work_item(work_item_id, database=transaction)
            if current is None:
                raise WorkError("work.not_found", "work item not found")
            if current.cancel_requested_at:
                raise WorkError("work.cancelled", "cancel requested")
            raise WorkError("work.lease_lost", "execution lease is no longer current")
        item = _hydrate_work_item(document)
    else:
        item = await _current_work_item(work_item_id, database=transaction)
    if item is None:
        raise WorkError("work.not_found", "work item not found")
    if item.cancel_requested_at:
        raise WorkError("work.cancelled", "cancel requested")
    now = datetime.now(timezone.utc)
    deadline = _parse_lease_timestamp(item.deadline_at)
    if deadline is not None and deadline <= now:
        raise WorkError("work.deadline_exceeded", "execution deadline passed")
    current_expiry = _parse_lease_timestamp(item.lease_expires_at)
    if current_expiry is None or current_expiry <= now:
        raise WorkError("work.lease_lost", "execution lease expired")
    expires = _lease_expiry(lease_seconds)
    try:
        return await cas_work_item_update(
            work_item_id,
            expected={
                "status": "running",
                "lease_token": lease_token,
                "lease_fence": int(lease_fence),
                "lease_owner": worker_id,
                "cancel_requested_at": "",
            },
            updates={"lease_expires_at": expires},
            error_code="work.lease_lost",
            transaction=transaction,
        )
    except WorkError as exc:
        if exc.code in {"work.lease_lost", "work.cas_conflict"}:
            current = await _current_work_item(work_item_id, database=transaction)
            if current is not None and current.cancel_requested_at:
                raise WorkError("work.cancelled", "cancel requested") from None
        raise


async def report_work_progress(
    work_item_id: str,
    progress: Dict[str, Any],
    *,
    lease: Optional[tuple] = None,
) -> bool:
    """Record a running App job's progress; False once it is no longer running.

    Updates only ``progress`` and only while ``running``, so it never races a
    terminal transition. With ``lease=(token, fence)`` the write is accepted
    only from the worker that still holds that lease, so a worker whose lease
    was reclaimed cannot overwrite the new worker's progress.
    """
    from app.agentive.services.work_outbox import cas_work_item_update

    expected: Dict[str, Any] = {"status": "running"}
    if lease:
        expected["lease_token"] = str(lease[0])
        expected["lease_fence"] = int(lease[1])
    try:
        await cas_work_item_update(
            work_item_id,
            expected=expected,
            updates={"progress": dict(progress)},
            error_code="work.not_running",
        )
    except WorkError:
        return False
    return True


async def transition_leased(
    work_item_id: str,
    *,
    lease_token: str,
    lease_fence: int,
    expected_status: WorkStatus,
    target: WorkStatus,
    fields: Optional[Dict[str, Any]] = None,
    transaction: Any = None,
) -> WorkItem:
    """Status transition authorized only by the current lease token/fence."""
    from app.agentive.services.work_outbox import (
        TOPIC_TRANSITIONED,
        cas_work_item_update,
    )
    from app.schemas.agentive.work import LEGAL_WORK_TRANSITIONS

    allowed = LEGAL_WORK_TRANSITIONS.get(expected_status, frozenset())
    if target not in allowed:
        raise WorkError(
            "work.invalid_transition",
            f"cannot transition {expected_status} -> {target}",
        )
    item = await WorkItem.get(_object_id(work_item_id))
    if item is not None and item.cancel_requested_at and target == "succeeded":
        raise WorkError("work.cancelled", "cancel requested; completion blocked")
    if item is not None and _deadline_passed(item, datetime.now(timezone.utc)):
        if target not in {"expired", "cancelled", "failed", "dead_letter"}:
            raise WorkError("work.deadline_exceeded", "deadline passed")
    updates: Dict[str, Any] = {"status": target}
    updates.update(fields or {})
    # Clear lease on terminal / wait states that leave running.
    if target != "running":
        updates.setdefault("lease_token", "")
        updates.setdefault("lease_owner", "")
        updates.setdefault("lease_expires_at", "")
    return await cas_work_item_update(
        work_item_id,
        expected={
            "status": expected_status,
            "lease_token": lease_token,
            "lease_fence": int(lease_fence),
        },
        updates=updates,
        outbox_topic=TOPIC_TRANSITIONED,
        outbox_payload={
            "from_status": expected_status,
            "to_status": target,
        },
        bump_transition_seq=True,
        error_code="work.lease_lost",
        transaction=transaction,
    )


async def reclaim_expired_lease(
    work_item_id: str,
    *,
    worker_id: str,
    lease_seconds: float = DEFAULT_LEASE_SECONDS,
    transaction: Any = None,
) -> WorkItem:
    """Reclaim an expired running lease with a new token and incremented fence."""
    from app.agentive.services.work_outbox import cas_work_item_update

    now_dt = datetime.now(timezone.utc)
    object_id = _object_id(work_item_id)
    item = await WorkItem.get(object_id)
    if item is None:
        raise WorkError("work.not_found", f"work item {work_item_id} not found")
    if item.status != "running":
        raise WorkError(
            "work.invalid_transition",
            f"cannot reclaim lease in status {item.status}",
        )
    if not _lease_expired(item, now_dt):
        raise WorkError("work.lease_active", "lease has not expired")
    new_token = secrets.token_urlsafe(16)
    new_fence = int(item.lease_fence or 0) + 1
    return await cas_work_item_update(
        item.work_item_id,
        expected={
            "status": "running",
            "lease_token": item.lease_token,
            "lease_fence": int(item.lease_fence or 0),
        },
        updates={
            "lease_owner": worker_id,
            "lease_token": new_token,
            "lease_fence": new_fence,
            "lease_expires_at": _lease_expiry(lease_seconds, now=now_dt),
        },
        outbox_topic=TOPIC_LEASE_RECLAIMED,
        outbox_payload={
            "previous_fence": int(item.lease_fence or 0),
            "lease_fence": new_fence,
            "lease_owner": worker_id,
        },
        bump_transition_seq=True,
        error_code="work.lease_lost",
        transaction=transaction,
    )


async def force_expire_lease_for_tests(work_item_id: str) -> WorkItem:
    """Test helper: set lease_expires_at to the past without touching the token."""
    from app.agentive.services.work_outbox import cas_work_item_update

    past = (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()
    item = await WorkItem.get(_object_id(work_item_id))
    if item is None:
        raise WorkError("work.not_found", f"work item {work_item_id} not found")
    return await cas_work_item_update(
        item.work_item_id,
        expected={
            "status": item.status,
            "lease_token": item.lease_token,
            "lease_fence": int(item.lease_fence or 0),
        },
        updates={"lease_expires_at": past},
        error_code="work.cas_conflict",
    )


__all__ = [
    "DEFAULT_LEASE_SECONDS",
    "assert_work_item_execution_current",
    "cancel_work_item",
    "claim_due_candidate",
    "compute_retry_delay",
    "continuation_fingerprint",
    "enqueue_work_item",
    "expire_work_item",
    "force_expire_lease_for_tests",
    "heartbeat_lease",
    "input_fingerprint",
    "normalize_failure",
    "reclaim_expired_lease",
    "recommended_heartbeat_interval",
    "schedule_retry",
    "transition_leased",
    "transition_work_item",
    "work_item_object_id",
]
