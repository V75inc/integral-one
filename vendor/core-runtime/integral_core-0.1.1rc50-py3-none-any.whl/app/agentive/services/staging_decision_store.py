"""Atomic proposal decisions on the same store/fence as canonical effects."""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import Any

from jvspatial.core.context import get_default_context

from app.agentive import staging_store
from app.agentive.staging import StagedChange, StagingError
from app.services.app_operations.transaction_scope import postgres_graph_transaction


def _acknowledged_terminal(snapshot, data, *, token, user_id, target, expected_kind):
    """Acknowledge only an exact terminal fact; never hydrate approval authority."""
    if (
        snapshot is None
        or target not in {"consumed", "revoked", "expired"}
        or snapshot.token != token
        or snapshot.user_id != user_id
        or snapshot.state != target
        or data.get("user_id") != user_id
        or data.get("state") != target
        or snapshot.kind != data.get("kind")
        or (expected_kind is not None and data.get("kind") != expected_kind)
    ):
        return None
    if "intent_fingerprint" in data:
        try:
            expected = staging_store.decision_intent_fingerprint(
                staging_store._sc_to_fields(snapshot)
            )
        except (TypeError, ValueError, RecursionError):
            return None
        if data["intent_fingerprint"] != expected:
            return None
    # Historical markers retain their state-only closure acknowledgment. An
    # approval consumer requiring exact effect reconciliation must require an
    # independent matching intent digest and canonical effect receipt.
    try:
        resolved = datetime.fromisoformat(data.get("resolved_at") or "")
        retained = data.get("retained_until")
        if resolved.tzinfo is None or (
            retained and datetime.fromisoformat(retained) <= datetime.now(timezone.utc)
        ):
            return None
    except (TypeError, ValueError):
        return None
    return replace(snapshot, resolved_at=resolved)


async def _resolve_absent_decision(
    database, *, token, user_id, target, expected_kind, terminal_snapshot
):
    """Resolve only a matching durable terminal fact after a missing live row."""
    terminal = await database.get("object", staging_store._decision_record_id(token))
    if (
        terminal is None
        or terminal.get("entity") != staging_store.StagingDecisionRecord._entity_name()
    ):
        raise StagingError(
            "approval_unavailable", "Current proposal decision is unavailable"
        )
    data = terminal.get("context") or {}
    acknowledged = _acknowledged_terminal(
        terminal_snapshot,
        data,
        token=token,
        user_id=user_id,
        target=target,
        expected_kind=expected_kind,
    )
    if acknowledged is not None:
        return acknowledged
    if data.get("user_id") == user_id and data.get("state") in {
        "consumed",
        "revoked",
        "expired",
    }:
        if expected_kind is not None and data.get("kind") != expected_kind:
            raise StagingError("wrong_kind", "Token is for another operation kind")
        raise StagingError(f"already_{data['state']}", "Proposal is already resolved")
    raise StagingError(
        "approval_unavailable", "Current proposal decision is unavailable"
    )


async def transition_staged_decision(
    *,
    token: str,
    user_id: str,
    target: str,
    expected_kind: str | None = None,
    decision_source: str | None = None,
    terminal_snapshot: StagedChange | None = None,
    pending_only: bool = False,
) -> StagedChange:
    """Use fresh locked facts; stale caches never bless, revoke or consume.

    A closure notifier may acknowledge its matching terminal snapshot without
    raising an expected refusal inside a caller's transaction. Normal decision
    callers retain strict one-time transition semantics, including consumption.
    """
    from app.agentive.services.staging_execution import (
        StagingExecutionRecord,
        execution_record_id,
    )

    if target not in {"blessed", "consumed", "revoked", "expired"}:
        raise ValueError("Unsupported proposal decision")

    async with postgres_graph_transaction(get_default_context().database) as database:
        rows = await database.find(
            "object",
            {
                "entity": staging_store.StagedChangeRecord._entity_name(),
                "context.token": token,
            },
            limit=2,
        )
        if len(rows) != 1:
            return await _resolve_absent_decision(
                database,
                token=token,
                user_id=user_id,
                target=target,
                expected_kind=expected_kind,
                terminal_snapshot=terminal_snapshot,
            )
        row = await database.find_one_and_update(
            "object", {"id": rows[0]["id"]}, {"$set": {}}
        )
        if row is None:
            # A competing transaction can remove the live row after our read
            # but before its lock is acquired. Re-read the committed terminal
            # fact under the same scope rather than losing the decision state.
            return await _resolve_absent_decision(
                database,
                token=token,
                user_id=user_id,
                target=target,
                expected_kind=expected_kind,
                terminal_snapshot=terminal_snapshot,
            )
        data: dict[str, Any] = row.get("context") or {}
        if data.get("user_id") != user_id:
            raise StagingError("wrong_user", "Token does not belong to this user")
        if expected_kind is not None and data.get("kind") != expected_kind:
            raise StagingError("wrong_kind", "Token is for another operation kind")
        state = data.get("state")
        if pending_only and state != "pending":
            raise StagingError(
                "proposal_changed", "The proposal is no longer awaiting review."
            )
        if state not in {"pending", "blessed"}:
            acknowledged = _acknowledged_terminal(
                terminal_snapshot,
                data,
                token=token,
                user_id=user_id,
                target=target,
                expected_kind=expected_kind,
            )
            if acknowledged is not None:
                return acknowledged
            raise StagingError(f"already_{state}", "Proposal is already resolved")
        now = datetime.now(timezone.utc)
        try:
            expires = datetime.fromisoformat(data["expires_at"])
            if expires.tzinfo is None:
                raise ValueError("Proposal expiry must include a timezone")
        except (KeyError, TypeError, ValueError) as exc:
            raise StagingError(
                "approval_unavailable", "Current proposal expiry is unavailable"
            ) from exc
        execution = await database.get("object", execution_record_id(token))
        outcome = (execution or {}).get("context") or {}
        applied = (
            outcome.get("local_effect_state") == "applied"
            or outcome.get("state") == "applied"
        )
        if execution is not None:
            if execution.get(
                "entity"
            ) != StagingExecutionRecord._entity_name() or outcome.get("state") not in {
                "ready",
                "claimed",
                "dispatched",
                "applied",
                "unknown",
            }:
                raise StagingError(
                    "execution_state_invalid", "Execution facts require reconciliation"
                )
            expected = {
                "principal_id": user_id,
                "kind": data.get("kind"),
                "request_hash": hashlib.sha256(
                    json.dumps(
                        data.get("payload"),
                        sort_keys=True,
                        separators=(",", ":"),
                        allow_nan=False,
                    ).encode()
                ).hexdigest(),
            }
            if data.get("workspace_id"):
                expected["workspace_id"] = data["workspace_id"]
            if any(outcome.get(key) != value for key, value in expected.items()):
                raise StagingError(
                    "execution_identity_conflict", "Approved execution identity changed"
                )
        if (
            target == "consumed"
            and execution is not None
            and not (
                outcome.get("state") == "applied"
                and outcome.get("local_effect_state") == "applied"
                and outcome.get("result_ciphertext")
                and outcome.get("external_outcome")
                in {None, "not_dispatched", "returned"}
            )
        ):
            raise StagingError(
                "application_reconciliation_required",
                "Current execution is not fully reconciled",
            )
        if target == "expired":
            if expires > now:
                raise StagingError("not_expired", "Current proposal has not expired")
            held = (
                applied
                or outcome.get("local_effect_state") == "partial"
                or outcome.get("state") in {"dispatched", "unknown"}
            )
            if outcome.get("state") == "claimed":
                try:
                    claim_expiry = datetime.fromisoformat(outcome["expires_at"])
                    held = held or claim_expiry > now
                except (KeyError, TypeError, ValueError):
                    held = True  # Missing lease facts cannot authorize cleanup.
            if held:
                # Expiry removes permission to start new effects, not evidence
                # of a change already committed or sent to an extension.
                partial = outcome.get("local_effect_state") == "partial"
                message = (
                    "The change applied before the approval expired. Reconcile its saved result; do not replay it."
                    if applied
                    else (
                        "Some batch steps applied before the approval expired. Review completed steps before approving remaining work."
                        if partial
                        else "The approval expired while a change was applying. Reconcile its outcome; do not replay it."
                    )
                )
                error = {
                    "error_code": "application_reconciliation_required",
                    "application_state": "reconciliation_required",
                    "applied": applied,
                    "partially_applied": partial,
                    "message": message,
                }
                updated = await database.find_one_and_update(
                    "object",
                    {"id": row["id"]},
                    {"$set": {"context.last_error": error}},
                )
                sc = staging_store._record_to_sc(
                    staging_store.StagedChangeRecord(id=row["id"], **updated["context"])
                )
                if sc is None:
                    raise StagingError(
                        "approval_unavailable", "Proposal could not be decoded"
                    )
                return sc
        elif expires <= now and not (
            state == "blessed"
            and applied
            and outcome.get("result_ciphertext")
            and (
                target == "blessed"  # Idempotent recovery, never a new approval.
                or (
                    target == "consumed"
                    and outcome.get("state") == "applied"
                    and outcome.get("external_outcome")
                    in {None, "not_dispatched", "returned"}
                )
            )
        ):
            raise StagingError("expired", "Token has expired")
        if target == "blessed" and state == "blessed":
            record = staging_store.StagedChangeRecord(id=row["id"], **data)
            sc = staging_store._record_to_sc(record)
            if sc is None:
                raise StagingError(
                    "approval_unavailable", "Proposal could not be decoded"
                )
            return sc
        if target == "consumed" and state != "blessed":
            raise StagingError("not_blessed", "Token has not been approved by the user")
        if target == "revoked":
            if (
                outcome.get("local_effect_state") == "applied"
                or outcome.get("state") == "applied"
            ):
                raise StagingError(
                    "already_applied",
                    "The change already applied; rejecting the approval cannot undo it",
                )
        updates = {"state": target, "resolved_at": now.isoformat()}
        if decision_source is not None:
            updates["decision_source"] = decision_source
        if target == "blessed":
            updates.update(
                blessed_at=now.isoformat(),
                execution_contract_version="durable-staging-v1",
            )
        return await _write_locked_decision(
            database, row=row, data=data, updates=updates, expires=expires
        )


async def _write_locked_decision(database, *, row, data, updates, expires):
    """Write only after the owning caller locks/admit its exact current decision.

    Canonical operation completion shares this writer, not the staging effect
    journal. Authority checks and immutable receipt proof belong to that caller.
    """
    from app.services.app_operations.transaction_scope import (
        current_graph_transaction_database,
    )

    if database is not current_graph_transaction_database():
        raise StagingError(
            "approval_unavailable", "A held decision transaction is required"
        )
    target = updates["state"]
    token, user_id = data["token"], data["user_id"]
    now = datetime.fromisoformat(updates["resolved_at"])
    if data.get("state") in {"pending", "blessed"}:
        terminal = await database.get(
            "object", staging_store._decision_record_id(token)
        )
        if terminal is not None:
            raise StagingError(
                "application_reconciliation_required",
                "Live and terminal decision facts conflict",
            )
    updated = await database.find_one_and_update(
        "object",
        {"id": row["id"], "context.state": data["state"]},
        {
            "$set": {f"context.{key}": value for key, value in updates.items()},
        },
    )
    if updated is None:
        raise StagingError(
            "approval_unavailable", "Current locked decision disappeared"
        )
    if target in {"consumed", "revoked", "expired"}:
        inserted = await database.insert_if_absent(
            "object",
            {
                "id": staging_store._decision_record_id(token),
                "entity": staging_store.StagingDecisionRecord._entity_name(),
                "context": {
                    "user_id": user_id,
                    "state": target,
                    "kind": data["kind"],
                    "superseded_by": updates.get("superseded_by"),
                    "intent_fingerprint": staging_store.decision_intent_fingerprint(
                        data
                    ),
                    "created_at": data["created_at"],
                    "expires_at": data["expires_at"],
                    "resolved_at": now.isoformat(),
                    "retained_until": (
                        max(now, expires) + timedelta(hours=24)
                    ).isoformat(),
                },
            },
        )
        if not inserted.created:
            existing = inserted.record or await database.get(
                "object", staging_store._decision_record_id(token)
            )
            proof = (existing or {}).get("context") or {}
            if (
                (existing or {}).get("entity")
                != staging_store.StagingDecisionRecord._entity_name()
                or proof.get("user_id") != user_id
                or proof.get("kind") != data["kind"]
                or proof.get("state") != target
                or proof.get("intent_fingerprint")
                != staging_store.decision_intent_fingerprint(data)
            ):
                raise StagingError(
                    "approval_identity_conflict", "Terminal decision proof conflicts"
                )
    sc = staging_store._record_to_sc(
        staging_store.StagedChangeRecord(id=row["id"], **updated["context"])
    )
    if sc is None:
        raise StagingError("approval_unavailable", "Proposal could not be decoded")
    return sc
