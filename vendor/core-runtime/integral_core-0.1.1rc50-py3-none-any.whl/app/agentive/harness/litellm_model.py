"""Pydantic AI model transport that keeps requests on Integral's LiteLLM SDK path.

Pydantic AI's LiteLLM provider is backed by an OpenAI-compatible HTTP client.
Integral does not currently configure a LiteLLM Proxy, so this transport
adapts that public client boundary to LiteLLM's in-process async SDK. No request
is sent over the network. A fresh transport is created for each trusted model
route and execution scope.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from builtins import anext
from collections import defaultdict
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any
from uuid import uuid4

import httpx

from app.agentive.harness.contracts import (
    HarnessExecutionScope,
    ModelRequestContextObservation,
    ModelUsageObservation,
    PhysicalModelRequest,
    ResolvedModelRoute,
)
from app.agentive.harness.model_errors import (
    NativeModelRequestError,
    model_request_error,
)
from app.agentive.harness.pydantic_ai_compat import LiteLLMProvider, OpenAIChatModel
from app.schemas.agentive.model_dispatch import ModelDispatchInput, ModelDispatchRoute

logger = logging.getLogger(__name__)

AttemptObserver = Callable[[PhysicalModelRequest], Awaitable[None]]
DispatchReadiness = Callable[[], Awaitable[None]]
ModelAdmission = Callable[[ModelDispatchInput], Awaitable[DispatchReadiness]]


class _ModelStreamOutcome(str, Enum):
    RESPONDED = "responded"
    CANCELLED = "cancelled"
    UNKNOWN = "outcome_unknown"


class AmbiguousToolCallStreamError(ValueError):
    """A provider reused tool indexes without enough identity to disambiguate."""


class _ToolCallIndexNormalizer:
    """Repair provider index collisions before OpenAI's stream parser sees them.

    Some OpenAI-compatible adapters (including the configured Ollama path) emit
    multiple tool calls with the same provider index. Pydantic AI uses that
    index as the identity of a streamed part, so the bridge must provide stable
    unique indexes keyed by the provider's tool-call ID.
    """

    def __init__(self) -> None:
        self._call_indexes: dict[str, int] = {}
        self._provider_index_calls: dict[int, set[str]] = defaultdict(set)
        self._anonymous_indexes: dict[int, int] = {}
        self._used_indexes: set[int] = set()
        self._next_index = 0

    def _allocate(self, preferred: int | None = None) -> int:
        if preferred is not None and preferred not in self._used_indexes:
            index = preferred
        else:
            while self._next_index in self._used_indexes:
                self._next_index += 1
            index = self._next_index
            self._next_index += 1
        self._used_indexes.add(index)
        return index

    def normalize(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Return a JSON-safe copy with collision-free tool-call indexes."""
        choices = payload.get("choices")
        if not isinstance(choices, list):
            return payload

        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta")
            if not isinstance(delta, dict):
                continue
            calls = delta.get("tool_calls")
            if not isinstance(calls, list):
                continue

            for call in calls:
                if not isinstance(call, dict):
                    continue
                raw_index = call.get("index")
                provider_index = (
                    raw_index if type(raw_index) is int and raw_index >= 0 else None
                )
                call_id = call.get("id")
                if isinstance(call_id, str) and call_id:
                    if call_id not in self._call_indexes:
                        known_calls = self._provider_index_calls.get(
                            provider_index, set()
                        )
                        anonymous_index = (
                            self._anonymous_indexes.pop(provider_index, None)
                            if provider_index is not None and not known_calls
                            else None
                        )
                        if anonymous_index is None:
                            if known_calls:
                                logger.warning(
                                    "provider reused streamed tool-call index; "
                                    "normalizing distinct calls"
                                )
                            anonymous_index = self._allocate(provider_index)
                        self._call_indexes[call_id] = anonymous_index
                    normalized_index = self._call_indexes[call_id]
                    if provider_index is not None:
                        self._provider_index_calls[provider_index].add(call_id)
                elif provider_index is not None:
                    known_calls = self._provider_index_calls.get(provider_index, set())
                    if len(known_calls) > 1:
                        raise AmbiguousToolCallStreamError(
                            "provider reused a tool-call index and omitted call identity"
                        )
                    if len(known_calls) == 1:
                        only_call_id = next(iter(known_calls))
                        normalized_index = self._call_indexes[only_call_id]
                    else:
                        normalized_index = self._anonymous_indexes.get(provider_index)
                        if normalized_index is None:
                            normalized_index = self._allocate(provider_index)
                            self._anonymous_indexes[provider_index] = normalized_index
                else:
                    raise AmbiguousToolCallStreamError(
                        "provider omitted both tool-call index and call identity"
                    )
                call["index"] = normalized_index
        return payload


def _plain(value: Any) -> Any:
    """Convert SDK/Pydantic responses to JSON-compatible values."""
    dump = getattr(value, "model_dump", None)
    if callable(dump):
        return dump(mode="json", exclude_none=True)
    if isinstance(value, dict):
        return value
    raise TypeError("LiteLLM returned an unsupported response object")


def _request_context(body: dict[str, Any]) -> ModelRequestContextObservation:
    """Measure serialized request components without retaining their contents."""
    sizes = {"instruction": 0, "conversation": 0, "tool_result": 0}
    messages = body.get("messages") or []
    for message in messages:
        role = message.get("role") if isinstance(message, dict) else None
        component = (
            "instruction"
            if role in {"system", "developer"}
            else "tool_result" if role == "tool" else "conversation"
        )
        sizes[component] += len(
            json.dumps(message, ensure_ascii=False, separators=(",", ":"))
        )
    tools = body.get("tools") or []
    serialized_tools = json.dumps(
        tools, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    )
    return ModelRequestContextObservation(
        instruction_chars=sizes["instruction"],
        conversation_chars=sizes["conversation"],
        tool_result_chars=sizes["tool_result"],
        tool_schema_chars=len(
            json.dumps(tools, ensure_ascii=False, separators=(",", ":"))
        ),
        tool_schema_fingerprint=hashlib.sha256(
            serialized_tools.encode("utf-8")
        ).hexdigest(),
        message_count=len(messages),
        visible_tool_count=len(tools),
    )


def _cost_value(value: Any) -> Decimal | None:
    """Return a finite, non-negative USD amount without coercing bad data."""
    if value is None:
        return None
    try:
        cost = Decimal(str(value))
    except (TypeError, ValueError):
        return None
    return cost if cost.is_finite() and cost >= 0 else None


def _reported_cost(
    response: Any, payload: dict[str, Any]
) -> tuple[Decimal | None, str]:
    """Read explicit provider or LiteLLM cost fields before estimating."""
    hidden = getattr(response, "_hidden_params", None)
    hidden = hidden if isinstance(hidden, dict) else {}
    raw_usage = payload.get("usage")
    raw_usage = raw_usage if isinstance(raw_usage, dict) else {}
    usage_cost = raw_usage.get("cost", raw_usage.get("response_cost"))
    provider_cost = _cost_value(usage_cost)
    if provider_cost is not None:
        return provider_cost, "provider_response"

    for key in ("response_cost", "cost"):
        direct_cost = _cost_value(payload.get(key))
        if direct_cost is not None:
            return direct_cost, "provider_response"
    headers = hidden.get("additional_headers")
    if isinstance(headers, dict):
        header_cost = _cost_value(headers.get("llm_provider-x-litellm-response-cost"))
        if header_cost is not None:
            return header_cost, "provider_response"
    hidden_cost = _cost_value(hidden.get("response_cost"))
    if hidden_cost is not None:
        return hidden_cost, "litellm_response"
    return None, "unavailable"


def _calculate_litellm_cost(
    response: Any,
    *,
    model: str | None,
    provider: str | None,
) -> Decimal | None:
    """Calculate cost only when LiteLLM has a known price for this route."""
    if not model:
        return None
    try:
        import litellm

        model_info = litellm.get_model_info(model=model, custom_llm_provider=provider)
        rates: Iterable[Decimal | None] = (
            (
                _cost_value(model_info.get(rate))
                for rate in ("input_cost_per_token", "output_cost_per_token")
            )
            if isinstance(model_info, dict)
            else ()
        )
        # LiteLLM uses 0.0 for some unknown/local routes. Without explicit
        # provider cost, treating that default as a price would silently
        # under-report metered cloud usage (for example Ollama cloud models).
        if not any(rate is not None and rate > 0 for rate in rates):
            return None
        amount = litellm.completion_cost(
            completion_response=response,
            model=model,
            custom_llm_provider=provider,
            call_type="acompletion",
        )
    except Exception:
        # Missing or incompatible pricing is a visible unavailable value; it
        # must not discard a completed response or be represented as $0.00.
        logger.debug(
            "LiteLLM cost calculation unavailable for model route %s/%s",
            provider,
            model,
            exc_info=True,
        )
        return None
    return _cost_value(amount)


def _usage(
    response: Any,
    *,
    complete: bool,
    model: str | None = None,
    provider: str | None = None,
) -> ModelUsageObservation:
    """Extract reported usage, then use LiteLLM pricing when cost is omitted."""
    payload = _plain(response)
    raw_usage = payload.get("usage") if isinstance(payload, dict) else None
    raw_usage = raw_usage if isinstance(raw_usage, dict) else {}
    prompt_details = raw_usage.get("prompt_tokens_details") or {}
    completion_details = raw_usage.get("completion_tokens_details") or {}
    normalized_cost, cost_source = _reported_cost(response, payload)
    hidden = getattr(response, "_hidden_params", None)
    sdk_cost = (
        _cost_value(hidden.get("response_cost")) if isinstance(hidden, dict) else None
    )
    if cost_source == "litellm_response" and normalized_cost == 0:
        # LiteLLM streaming accounting coerces unavailable calculated cost to
        # 0.0. Keep that raw value, but require known pricing before presenting
        # it as a cost. Explicit zero from the provider remains authoritative.
        normalized_cost, cost_source = None, "unavailable"
    if (
        normalized_cost is None
        and raw_usage.get("prompt_tokens") is not None
        and raw_usage.get("completion_tokens") is not None
    ):
        normalized_cost = _calculate_litellm_cost(
            response, model=model, provider=provider
        )
        if normalized_cost is not None:
            cost_source = "litellm_calculated"
    return ModelUsageObservation(
        input_tokens=raw_usage.get("prompt_tokens"),
        output_tokens=raw_usage.get("completion_tokens"),
        cached_input_tokens=prompt_details.get("cached_tokens"),
        reasoning_tokens=completion_details.get("reasoning_tokens"),
        provider_cost_usd=normalized_cost,
        litellm_response_cost_usd=sdk_cost,
        cost_source=cost_source,
        complete=complete
        and raw_usage.get("prompt_tokens") is not None
        and raw_usage.get("completion_tokens") is not None,
    )


def _provider_request_id(response: Any) -> str | None:
    """Return a provider-generated ID when the SDK response exposes one."""
    value = getattr(response, "id", None)
    if value is None and isinstance(response, dict):
        value = response.get("id")
    return str(value) if value else None


class _StreamAccountingResponse:
    """Small merged response used only for a stream's usage observation."""

    def __init__(
        self,
        *,
        payload: dict[str, Any],
        hidden_params: dict[str, Any],
    ) -> None:
        self._payload = payload
        self._hidden_params = hidden_params
        self.id = payload.get("id")

    def model_dump(self, **_kwargs: Any) -> dict[str, Any]:
        return self._payload


class _LiteLLMStream(httpx.AsyncByteStream):
    """Render LiteLLM stream chunks as the SSE shape expected by OpenAI SDK."""

    def __init__(
        self,
        *,
        chunks: AsyncIterator[Any],
        finish: Callable[[Any | None, _ModelStreamOutcome], Awaitable[None]],
        response: Any = None,
        deadline: float | None = None,
        idle_timeout_seconds: float = 30.0,
    ) -> None:
        self._chunks = chunks
        self._deadline = deadline
        self._idle_timeout_seconds = idle_timeout_seconds
        self._finish = finish
        self._last: Any | None = None
        self._usage: dict[str, Any] = {}
        self._reported_usage_cost: Any = None
        self._reported_direct_cost: Any = None
        self._hidden_params: dict[str, Any] = {}
        self._hidden_cost: Any = None
        self._additional_headers: dict[str, Any] = {}
        self._provider_request_id: Any = None
        self._capture(response)
        self._finished = False
        self._tool_call_indexes = _ToolCallIndexNormalizer()

    def _capture(self, response: Any) -> None:
        """Retain accounting metadata without retaining every streamed token."""
        try:
            payload = _plain(response)
        except (TypeError, ValueError):
            payload = {}
        if isinstance(payload, dict):
            for key in ("cost", "response_cost"):
                if _cost_value(payload.get(key)) is not None:
                    self._reported_direct_cost = payload[key]
            usage = payload.get("usage")
            if isinstance(usage, dict):
                self._usage.update(usage)
                for key in ("cost", "response_cost"):
                    if _cost_value(usage.get(key)) is not None:
                        self._reported_usage_cost = usage[key]
            request_id = payload.get("id")
            if request_id:
                self._provider_request_id = request_id

        hidden = getattr(response, "_hidden_params", None)
        if isinstance(hidden, dict):
            self._hidden_params.update(hidden)
            hidden_cost = _cost_value(hidden.get("response_cost"))
            # Prefer a later non-zero hidden cost if LiteLLM first exposes its
            # streaming placeholder (0.0) and then the settled amount.
            if hidden_cost is not None and (
                self._hidden_cost is None or hidden_cost > 0
            ):
                self._hidden_cost = hidden["response_cost"]
            headers = hidden.get("additional_headers")
            if isinstance(headers, dict):
                self._additional_headers.update(headers)

    def _accounting_response(self) -> Any:
        """Expose merged stream metadata in the shape consumed by ``_usage``."""
        payload: dict[str, Any] = {}
        if self._last is not None:
            try:
                last_payload = _plain(self._last)
            except (TypeError, ValueError):
                last_payload = {}
            if isinstance(last_payload, dict):
                payload.update(last_payload)
        payload["id"] = self._provider_request_id or payload.get("id")
        merged_usage = dict(self._usage)
        if self._reported_usage_cost is not None:
            merged_usage["cost"] = self._reported_usage_cost
        payload["usage"] = merged_usage
        if self._reported_direct_cost is not None:
            payload["response_cost"] = self._reported_direct_cost

        hidden = dict(self._hidden_params)
        if self._hidden_cost is not None:
            hidden["response_cost"] = self._hidden_cost
        if self._additional_headers:
            hidden["additional_headers"] = self._additional_headers
        return _StreamAccountingResponse(payload=payload, hidden_params=hidden)

    async def __aiter__(self) -> AsyncIterator[bytes]:
        try:
            iterator = self._chunks.__aiter__()
            while True:
                remaining = (
                    self._deadline - asyncio.get_running_loop().time()
                    if self._deadline is not None
                    else self._idle_timeout_seconds
                )
                try:
                    chunk = await asyncio.wait_for(
                        anext(iterator),
                        timeout=max(0, min(self._idle_timeout_seconds, remaining)),
                    )
                except StopAsyncIteration:
                    break
                self._last = chunk
                self._capture(chunk)
                payload = _plain(chunk)
                if isinstance(payload, dict):
                    payload = self._tool_call_indexes.normalize(deepcopy(payload))
                data = json.dumps(payload, separators=(",", ":"))
                yield f"data: {data}\n\n".encode("utf-8")
            # Claim settlement before awaiting persistence. The HTTP client may
            # close the response concurrently while the terminal observation is
            # being written; allowing aclose() to win that race would append an
            # outcome_unknown after the known response and permanently block
            # safe session continuation.
            self._finished = True
            await self._finish(
                self._accounting_response(), _ModelStreamOutcome.RESPONDED
            )
            yield b"data: [DONE]\n\n"
        except BaseException as exc:
            if not self._finished:
                self._finished = True
                outcome = (
                    _ModelStreamOutcome.CANCELLED
                    if isinstance(exc, (asyncio.CancelledError, GeneratorExit))
                    else _ModelStreamOutcome.UNKNOWN
                )
                await self._finish(self._accounting_response(), outcome)
                classified = (
                    NativeModelRequestError("model_empty_response")
                    if isinstance(exc, StopAsyncIteration)
                    else model_request_error(exc)
                )
                if classified is not None:
                    raise classified from exc
            raise

    async def aclose(self) -> None:
        close = getattr(self._chunks, "aclose", None)
        if not self._finished:
            self._finished = True
            try:
                if callable(close):
                    await close()
            finally:
                await self._finish(
                    self._accounting_response(), _ModelStreamOutcome.CANCELLED
                )
        elif callable(close):
            await close()


class LiteLLMSDKTransport(httpx.AsyncBaseTransport):
    """Translate one OpenAI-compatible client request into LiteLLM SDK work."""

    def __init__(
        self,
        *,
        route: ResolvedModelRoute,
        scope: HarnessExecutionScope,
        observer: AttemptObserver | None = None,
        completion: Callable[..., Awaitable[Any]] | None = None,
        timeout_seconds: float = 180.0,
        idle_timeout_seconds: float = 30.0,
        admission: ModelAdmission | None = None,
        dispatch_guard: Callable[[], None] | None = None,
        request_validator: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
        max_attempts: int = 1,
        retry_status: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> None:
        if timeout_seconds <= 0:
            raise ValueError("model request timeout must be positive")
        if idle_timeout_seconds <= 0:
            raise ValueError("model idle timeout must be positive")
        if not 1 <= max_attempts <= 3:
            raise ValueError("model attempts must be between one and three")
        self._max_attempts = max_attempts
        self._retry_status = retry_status
        self._route = route
        self._scope = scope
        self._observer = observer
        self._completion = completion
        self._timeout_seconds = timeout_seconds
        self._idle_timeout_seconds = min(idle_timeout_seconds, timeout_seconds)
        self._admission = admission
        self._dispatch_guard = dispatch_guard
        self._request_validator = request_validator
        self._custom_session = None

    async def aclose(self) -> None:
        if self._custom_session is not None:
            await self._custom_session.aclose()

    async def _sdk_completion(self, **kwargs: Any) -> Any:
        completion = self._completion
        if completion is None:
            import litellm

            completion = litellm.acompletion
        if (
            self._route.provider == "openai"
            and self._route.credential_source == "workspace_byok"
            and self._route.api_base is not None
        ):
            from app.services.custom_model_transport import (
                CustomModelSession,
                custom_endpoint_completion,
            )

            if self._custom_session is None:
                self._custom_session = CustomModelSession(
                    kwargs, keyless_endpoint=self._route.keyless_endpoint
                )

            return await custom_endpoint_completion(
                completion,
                kwargs,
                keyless_endpoint=self._route.keyless_endpoint,
                session=self._custom_session,
            )
        return await completion(**kwargs)

    async def _observe(
        self,
        *,
        request_id: str,
        started_at: datetime,
        outcome: str,
        response: Any | None = None,
        complete: bool = False,
        required: bool = False,
        request_context: ModelRequestContextObservation | None = None,
        attempt: int = 1,
    ) -> None:
        if self._observer is None:
            if required:
                raise RuntimeError(
                    "native model dispatch requires a durable attempt observer"
                )
            return
        usage = (
            _usage(
                response,
                complete=complete,
                model=self._route.model,
                provider=self._route.provider,
            )
            if response is not None
            else None
        )
        observation = PhysicalModelRequest(
            request_id=request_id,
            scope=self._scope,
            provider=self._route.provider,
            model=self._route.model,
            credential_source=self._route.credential_source,
            credential_ref=self._route.credential_ref,
            attempt=attempt,
            dispatched_at=started_at,
            observed_at=datetime.now(timezone.utc),
            outcome=outcome,
            provider_request_id=(
                _provider_request_id(response) if response is not None else None
            ),
            usage=usage,
            request_context=request_context,
        )
        try:
            await self._observer(observation)
        except Exception:
            if required:
                raise
            # Accounting persistence failure must be visible operationally;
            # it must not turn a completed provider response into a lost turn.
            logger.exception("native model attempt observation failed")

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        if request.method != "POST" or not request.url.path.endswith(
            "/chat/completions"
        ):
            return httpx.Response(
                404,
                json={"error": {"message": "Unsupported LiteLLM SDK bridge route"}},
                request=request,
            )

        try:
            body = json.loads(await request.aread())
        except (json.JSONDecodeError, UnicodeDecodeError):
            return httpx.Response(
                400,
                json={"error": {"message": "Malformed model request"}},
                request=request,
            )
        if not isinstance(body, dict) or body.get("model") != self._route.model:
            return httpx.Response(
                400,
                json={
                    "error": {"message": "Model route does not match execution scope"}
                },
                request=request,
            )

        request_context = _request_context(body)
        request_id = str(uuid4())
        started_at = datetime.now(timezone.utc)
        from app.services.model_settings import provider_model_options

        kwargs = dict(body)
        if "max_tokens" in self._route.generation_settings:
            kwargs.pop("max_completion_tokens", None)
        kwargs.update(provider_model_options(self._route.generation_settings))
        kwargs["num_retries"] = 0  # Core owns retry identity and accounting.
        # LiteLLM has provider-specific default timeouts, which can leave a
        # broken streaming response waiting far beyond Integral's intended
        # chat latency. Bound each physical request while preserving Core's
        # longer run budget for legitimate multi-step work.
        kwargs["timeout"] = self._timeout_seconds
        if self._route.ollama_num_ctx is not None:
            # LiteLLM's `ollama_chat` mapper does not translate `num_ctx` from
            # arbitrary kwargs. Pass it through OpenAI's extra_body so LiteLLM
            # merges Ollama's native `{options: {num_ctx: ...}}` into the final
            # `/api/chat` payload. A top-level `num_ctx` silently disappears.
            extra_body = kwargs.get("extra_body")
            extra_body = dict(extra_body) if isinstance(extra_body, dict) else {}
            ollama_options = extra_body.get("options")
            ollama_options = (
                dict(ollama_options) if isinstance(ollama_options, dict) else {}
            )
            ollama_options["num_ctx"] = self._route.generation_settings.get(
                "context_window", self._route.ollama_num_ctx
            )
            extra_body["options"] = ollama_options
            kwargs["extra_body"] = extra_body
        if self._route.ollama_num_predict is not None:
            # Pydantic AI may encode its max_tokens setting as
            # `max_completion_tokens` for this OpenAI-compatible model profile.
            # LiteLLM's Ollama adapter accepts both spellings; passing both can
            # let the smaller generic value win. Collapse the aliases to the
            # route-owned max_tokens, which LiteLLM maps to num_predict.
            kwargs.pop("max_completion_tokens", None)
            kwargs["max_tokens"] = self._route.generation_settings.get(
                "max_tokens", self._route.ollama_num_predict
            )
        if self._route.ollama_num_ctx is not None:
            # LiteLLM shallow-merges extra_body into the final Ollama payload.
            # Preserve every generated native sampling option when supplying
            # options.num_ctx, or that merge silently drops num_predict etc.
            options = kwargs["extra_body"]["options"]
            for parameter, native in {
                "max_tokens": "num_predict",
                "temperature": "temperature",
                "top_p": "top_p",
                "seed": "seed",
                "frequency_penalty": "repeat_penalty",
                "stop": "stop",
            }.items():
                if kwargs.get(parameter) is not None:
                    options[native] = kwargs[parameter]
        if (
            self._route.ollama_think is not None
            or self._route.ollama_clear_thinking is not None
        ):
            # Thinking options are model-defined in Ollama's API. Keep them
            # inside this route adapter, and omit them unless the deployment
            # explicitly configures a value supported by its selected model.
            extra_body = kwargs.get("extra_body")
            extra_body = dict(extra_body) if isinstance(extra_body, dict) else {}
            if self._route.ollama_think is not None:
                extra_body["think"] = self._route.ollama_think
            if self._route.ollama_clear_thinking is not None:
                extra_body["clear_thinking"] = self._route.ollama_clear_thinking
            kwargs["extra_body"] = extra_body
        if (
            self._route.provider == "ollama_chat"
            and "reasoning_effort" in self._route.generation_settings
        ):
            # The pinned LiteLLM adapter turns non-GPT-OSS effort levels into
            # bools (and "max" into false). Preserve verified native levels;
            # the saved profile overrides the deployment's think default.
            effort = kwargs.pop("reasoning_effort")
            extra_body = dict(kwargs.get("extra_body") or {})
            extra_body["think"] = False if effort == "none" else effort
            kwargs["extra_body"] = extra_body
        if (
            self._route.provider == "ollama_chat"
            and "thinking_enabled" in self._route.generation_settings
        ):
            extra_body = dict(kwargs.get("extra_body") or {})
            extra_body["think"] = self._route.generation_settings["thinking_enabled"]
            kwargs["extra_body"] = extra_body
        if (
            self._route.provider == "anthropic"
            and self._route.generation_settings.get("reasoning_effort") == "none"
        ):
            # Omitting thinking can restore an adaptive model's on default.
            # An explicit Off choice must reach Anthropic as disabled.
            kwargs.pop("reasoning_effort", None)
            extra_body = dict(kwargs.get("extra_body") or {})
            extra_body["thinking"] = {"type": "disabled"}
            kwargs["extra_body"] = extra_body
        if self._route.provider == "openrouter":
            # OpenRouter's native reasoning object preserves model-defined
            # effort names and budgets; the pinned adapter rewrites max to xhigh.
            reasoning = {}
            if "reasoning_effort" in self._route.generation_settings:
                reasoning["effort"] = kwargs.pop("reasoning_effort")
            if "thinking_budget" in self._route.generation_settings:
                kwargs.pop("thinking", None)
                reasoning["max_tokens"] = self._route.generation_settings[
                    "thinking_budget"
                ]
            if reasoning:
                extra_body = dict(kwargs.get("extra_body") or {})
                extra_body["reasoning"] = reasoning
                kwargs["extra_body"] = extra_body
        if self._route.api_base is not None:
            kwargs["api_base"] = self._route.api_base
        else:
            kwargs.pop("api_base", None)
        if self._route.api_key is not None:
            kwargs["api_key"] = self._route.api_key.get_secret_value()
        else:
            kwargs.pop("api_key", None)

        for attempt in range(1, self._max_attempts + 1):
            request_id = str(uuid4())
            started_at = datetime.now(timezone.utc)
            readiness = None
            if self._dispatch_guard is not None:
                self._dispatch_guard()
            if self._admission is not None:
                # Use final mapped SDK kwargs, including tools, reasoning controls
                # and enforced output settings. Do not pass credential material to
                # the host payload resolver or persist plaintext input there.
                payload = {
                    key: value
                    for key, value in kwargs.items()
                    if key not in {"api_key", "api_base"}
                }
                readiness = await self._admission(
                    ModelDispatchInput(
                        scope=self._scope,
                        route=ModelDispatchRoute(
                            provider=self._route.provider,
                            model=self._route.model,
                            credential_source=self._route.credential_source,
                            credential_ref=self._route.credential_ref,
                        ),
                        request_id=request_id,
                        sdk_payload_json=json.dumps(
                            payload,
                            sort_keys=True,
                            separators=(",", ":"),
                            allow_nan=False,
                        ),
                        endpoint_fingerprint=hashlib.sha256(
                            (self._route.api_base or "provider-default").encode()
                        ).hexdigest(),
                    )
                )
                if not callable(readiness):
                    raise RuntimeError(
                        "model admission requires final dispatch readiness"
                    )

            from app.services.chat_latency import measure_latency_phase

            with measure_latency_phase("dispatchReceipt"):
                await self._observe(
                    request_id=request_id,
                    request_context=request_context,
                    attempt=attempt,
                    started_at=started_at,
                    outcome="dispatch_intent",
                    required=True,
                )

            if readiness is not None:
                # Receipt persistence can outlive pricing or current authority.
                # A rejected readiness check has no SDK dispatch; retain its hold
                # conservatively for the separate no-dispatch recovery path.
                await readiness()

            if self._request_validator is not None:
                try:
                    await self._request_validator(body)
                except BaseException as exc:
                    # The SDK was never entered. Settle the dispatch intent as
                    # a known refusal so revoked uploads cannot leave an
                    # unknown request that blocks durable chat continuation.
                    await self._observe(
                        request_id=request_id,
                        request_context=request_context,
                        attempt=attempt,
                        started_at=started_at,
                        outcome=(
                            "cancelled"
                            if isinstance(exc, asyncio.CancelledError)
                            else "failed"
                        ),
                    )
                    raise

            try:
                deadline = asyncio.get_running_loop().time() + self._timeout_seconds
                with measure_latency_phase("providerStart"):
                    response = await asyncio.wait_for(
                        self._sdk_completion(**kwargs),
                        timeout=(
                            self._idle_timeout_seconds
                            if body.get("stream") is True
                            else self._timeout_seconds
                        ),
                    )
                if self._max_attempts > 1:
                    if body.get("stream") is True and hasattr(response, "__aiter__"):
                        original_stream = response
                        iterator = original_stream.__aiter__()
                        buffered = []
                        try:
                            async with asyncio.timeout(
                                max(0, deadline - asyncio.get_running_loop().time())
                            ):
                                for _ in range(64):
                                    chunk = await asyncio.wait_for(
                                        anext(iterator),
                                        timeout=min(
                                            self._idle_timeout_seconds,
                                            max(
                                                0,
                                                deadline
                                                - asyncio.get_running_loop().time(),
                                            ),
                                        ),
                                    )
                                    buffered.append(chunk)
                                    choices = _plain(chunk).get("choices") or []
                                    if any(
                                        any(
                                            (choice.get("delta") or {}).get(key)
                                            for key in (
                                                "content",
                                                "tool_calls",
                                                "function_call",
                                                "refusal",
                                                "reasoning_content",
                                            )
                                        )
                                        for choice in choices
                                    ):
                                        from app.services.chat_latency import (
                                            mark_latency,
                                        )

                                        mark_latency("providerFirstTokenMs")
                                        break
                                    if any(
                                        choice.get("finish_reason")
                                        for choice in choices
                                    ):
                                        raise NativeModelRequestError(
                                            "model_empty_response"
                                        )
                                else:
                                    raise NativeModelRequestError(
                                        "model_empty_response"
                                    )
                        except BaseException:
                            close = getattr(original_stream, "aclose", None)
                            if callable(close):
                                await close()
                            raise

                        async def prefetched(
                            buffered=buffered,
                            iterator=iterator,
                            original_stream=original_stream,
                        ):
                            try:
                                for chunk in buffered:
                                    yield chunk
                                async for chunk in iterator:
                                    yield chunk
                            finally:
                                close = getattr(original_stream, "aclose", None)
                                if callable(close):
                                    await close()

                        response = prefetched()
                    elif body.get("stream") is not True:
                        plain = _plain(response)
                        choices = plain.get("choices") or []
                        if not any(
                            any(
                                (choice.get("message") or {}).get(key)
                                for key in (
                                    "content",
                                    "tool_calls",
                                    "function_call",
                                    "refusal",
                                )
                            )
                            for choice in choices
                        ):
                            raise NativeModelRequestError("model_empty_response")
            except asyncio.CancelledError:
                await self._observe(
                    request_id=request_id,
                    request_context=request_context,
                    attempt=attempt,
                    started_at=started_at,
                    outcome="cancelled",
                )
                raise
            except BaseException as exc:
                classified = (
                    NativeModelRequestError("model_empty_response")
                    if isinstance(exc, StopAsyncIteration)
                    else model_request_error(exc)
                )
                if (
                    classified is not None
                    and classified.code == "model_request_rejected"
                    and any(
                        isinstance(m.get("content"), list)
                        and any(
                            isinstance(p, dict) and p.get("type") == "image_url"
                            for p in m["content"]
                        )
                        for m in body.get("messages") or []
                    )
                ):
                    classified = NativeModelRequestError("model_image_request_rejected")
                # Explicit rejection before a response is a failed attempt. Network
                # loss/timeouts still retain unknown outcome and billing; each
                # retry retains this evidence and obtains fresh admission.
                rejected = classified is not None and classified.code in {
                    "model_context_limit",
                    "model_authentication_failed",
                    "model_rate_limited",
                    "model_unavailable",
                    "model_request_rejected",
                    "model_image_request_rejected",
                }
                await self._observe(
                    request_id=request_id,
                    request_context=request_context,
                    attempt=attempt,
                    started_at=started_at,
                    outcome="failed" if rejected else "outcome_unknown",
                )
                if (
                    classified is not None
                    and classified.code
                    in {
                        "model_rate_limited",
                        "model_provider_unavailable",
                        "model_request_timeout",
                        "model_endpoint_unreachable",
                        "model_empty_response",
                    }
                    and attempt < self._max_attempts
                ):
                    if self._retry_status is not None:
                        await self._retry_status(attempt + 1, self._max_attempts)
                    await asyncio.sleep(0.5 * 2 ** (attempt - 1))
                    continue
                if classified is not None:
                    raise classified from exc
                raise

            if attempt > 1 and self._retry_status is not None:
                await self._retry_status(0, self._max_attempts)
            break

        if body.get("stream") is True:
            if not hasattr(response, "__aiter__"):
                await self._observe(
                    request_id=request_id,
                    request_context=request_context,
                    attempt=attempt,
                    started_at=started_at,
                    outcome="failed",
                )
                return httpx.Response(
                    502,
                    json={"error": {"message": "LiteLLM stream was not asynchronous"}},
                    request=request,
                )

            async def finish(last: Any | None, outcome: _ModelStreamOutcome) -> None:
                await self._observe(
                    request_id=request_id,
                    request_context=request_context,
                    attempt=attempt,
                    started_at=started_at,
                    outcome=outcome.value,
                    response=last,
                    complete=outcome is _ModelStreamOutcome.RESPONDED,
                )

            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=_LiteLLMStream(
                    chunks=response,
                    response=response,
                    finish=finish,
                    deadline=deadline,
                    idle_timeout_seconds=self._idle_timeout_seconds,
                ),
                request=request,
            )

        try:
            payload = _plain(response)
            encoded = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        except Exception:
            await self._observe(
                request_id=request_id,
                request_context=request_context,
                attempt=attempt,
                started_at=started_at,
                outcome="failed",
            )
            return httpx.Response(
                502,
                json={"error": {"message": "LiteLLM returned an unsupported response"}},
                request=request,
            )

        await self._observe(
            request_id=request_id,
            request_context=request_context,
            attempt=attempt,
            started_at=started_at,
            outcome="responded",
            response=response,
            complete=True,
        )
        return httpx.Response(
            200,
            headers={"content-type": "application/json"},
            content=encoded,
            request=request,
        )


def build_litellm_sdk_model(
    *,
    route: ResolvedModelRoute,
    scope: HarnessExecutionScope,
    observer: AttemptObserver,
    completion: Callable[..., Awaitable[Any]] | None = None,
    timeout_seconds: float = 180.0,
    idle_timeout_seconds: float = 30.0,
    admission: ModelAdmission | None = None,
    dispatch_guard: Callable[[], None] | None = None,
    request_validator: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    max_attempts: int = 1,
    retry_status: Callable[[int, int], Awaitable[None]] | None = None,
) -> OpenAIChatModel:
    """Build an OpenAI-compatible Pydantic model over LiteLLM's in-process SDK."""
    transport = LiteLLMSDKTransport(
        route=route,
        scope=scope,
        observer=observer,
        completion=completion,
        timeout_seconds=timeout_seconds,
        idle_timeout_seconds=idle_timeout_seconds,
        admission=admission,
        dispatch_guard=dispatch_guard,
        request_validator=request_validator,
        max_attempts=max_attempts,
        retry_status=retry_status,
    )
    http_client = httpx.AsyncClient(
        transport=transport, timeout=httpx.Timeout(timeout_seconds)
    )
    from openai import AsyncOpenAI

    client = AsyncOpenAI(
        api_key="integral-litellm-sdk-bridge",
        base_url="http://litellm-sdk.invalid/v1",
        http_client=http_client,
        max_retries=0,
    )
    provider = LiteLLMProvider(openai_client=client)
    # Admission and native compaction must see the same explicit capacity as
    # the provider transport. Custom/Ollama identifiers may have no registry
    # entry; otherwise their configured window silently became the fallback.
    context_window = route.generation_settings.get("context_window")
    if context_window is None:
        context_window = route.ollama_num_ctx
    if context_window is None:
        from app.services.model_provider_endpoints import OLLAMA_CLOUD_API_BASE
        from app.services.model_settings import model_capabilities

        # Use the same pinned, network-free capability metadata as Settings.
        # A custom endpoint borrowing a vendor model name does not establish
        # that vendor's capacity; leave it unknown unless explicitly configured.
        cloud_ollama = (
            route.provider == "ollama_chat" and route.api_base == OLLAMA_CLOUD_API_BASE
        )
        if route.api_base is None or cloud_ollama:
            provider_name = "ollama" if cloud_ollama else route.provider
            model_name = route.model.removeprefix(f"{route.provider}/")
            context_window = model_capabilities(provider_name, model_name).get(
                "native_context"
            )
    profile = (
        {"context_window": context_window}
        if isinstance(context_window, int)
        and not isinstance(context_window, bool)
        and context_window > 0
        else None
    )
    return OpenAIChatModel(route.model, provider=provider, profile=profile)
