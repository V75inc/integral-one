---
name: integral-scaffold
description: 'Designs and delivers a new operational App or an app-level schema extension: an equipment or tool tracker, inventory register, maintenance log, or multi-part team workflow. Use when the requested outcome needs new or changed structure; check whether an existing App fits, propose the smallest useful design, build it after approval, and verify it. General how-to advice about an existing workflow does not need a proposal when current structure supports the request. For adding, finding, or changing one record in an existing Track or list, use integral-entries. Keep delivery ownership while consulting integral-model for schema choices and integral-scheduling for requested routines. Use integral-onboard first only when the user needs workspace orientation before choosing what to build.'
allowed-tools: integral_find_workspace_resources integral_get_page_context integral_whoami integral_describe_substrate integral_list_models integral_list_apps integral_ask_user integral_check_design_coverage integral_verify_build integral_propose_design integral_get_artifact integral_list_artifacts integral_begin_batch integral_build_approved_design integral_create_app integral_create_app_track integral_apply_model_to_track integral_author_model integral_save_view integral_create_entry integral_create_dashboard integral_author_skill integral_create_tag integral_register_track_template integral_commit_batch integral_list_tracks integral_get_track_schema integral_query_entries integral_list_views integral_schedule_task integral_list_routines integral_cancel_batch
---

# Operational app delivery

Before changing existing Apps or Tracks, identify every source and destination.
Use current-turn verified page context only when it and the user request clearly
identify the targets. Otherwise use `integral_find_workspace_resources` to find
candidates; follow further pages or use current navigation if incomplete, and
clarify genuine ambiguity. Suggestions are metadata, not evidence of records,
permission, or approval.

## App settings placement (required)

All App-specific settings controls MUST use the standard App settings dialog
opened from the App header. Declare configuration in `app.settings_schema`;
never create settings editors on Home, dashboards, Tracks, Entries or extension
views. Keep record-entry and other operational forms on their working surfaces.
Preserve settings values when revising an App. If the shared settings renderer
cannot express a control, identify the required contract extension rather than
inventing a separate UI or unsupported settings-write tool. Use available
canonical authoring/approval paths and verify saved values before claiming success.

## Delivery ownership and status

This skill coordinates a new app or an addition to an existing app. Follow this sequence without
skipping or repeating a settled phase: **discover → clarify → propose →
preview → authorize → execute → verify → explain**.

Specialists advise without taking over this lifecycle: `integral-model` owns
existing-schema judgment, `integral-models` owns model/package lifecycle,
`integral-entries` owns records, and `integral-scheduling` owns cadence.

Use state words precisely: **proposed** is not authorized; **prepared** or
**awaiting approval** is not applied; **applied** is not verified. Say “built”
only after a receipt reports the batch applied. Say “verified” only after the
readback succeeds. A failed, rejected, cancelled, or partial receipt must be
named as such and must never be rendered as a saved result.

### Explicit design-only boundary

When the user says **“design only,” “do not build,” “do not create,”** or gives
an equivalent instruction, this turn is proposal-only. Call the grounding and
`integral_propose_design` tools, then stop. Do **not** call
`integral_begin_batch`, `integral_create_app`, `integral_create_app_track`,
`integral_apply_model_to_track`, `integral_save_view`,
`integral_create_entry`, `integral_author_skill`, `integral_schedule_task`, or
`integral_commit_batch` in that turn.

In the user-facing reply, begin with **“Proposed — nothing has been built.”**
Paste the full proposal, then end with this exact sentence on its own line:
**Confirm this design, or tell me what to change.** A design proposal, a stored blueprint, a staged receipt, and an
applied app are distinct states; never describe one as another.

## When to use

User wants a new operational app, an addition to one, or to finish / repair one. Own
**discover → design → build → verify → handoff**. Chat affirm of the design
outline is greenfield approval; the scaffold batch applies on
`integral_commit_batch` (no second Prompt Sheet bless). An App node alone is
not a complete operational app — schema, views, relations, procedures, and acceptance
evidence must land. An explicitly requested **blank App** is a valid exception:
propose its exact name with `tracks: []`, no views, seeds, dashboard, skills or
routines, and an acceptance assertion of zero Tracks. After the user approves,
build only `integral_create_app` through `integral_build_approved_design` and
verify that empty container. Never invent a minimum Track requirement.

General how-to advice about using an existing workflow is not, by itself, a
request for new structure. When the current App and its schema cover the stated
need, answer with the verified path and do not stage a proposal. Propose an
extension only when existing structure is missing a capability the user asked
for.

Propose from the field and view types in this skill. Check the blueprint with
`integral_check_design_coverage` right before proposing. Call
`integral_describe_substrate` only when a tool rejects a type or config key.
Do not spend a turn on whoami, model listing, or substrate introspection
for a clear new-app or existing-app request.

**Ground every design in the workspace.** Before proposing any app or app
extension, call `integral_list_apps` once—even when the request sounds
greenfield. This is required grounding, not optional discovery: a useful
destination may already exist. If one clearly fits, inspect only that App's
tracks and the schema of the one relevant track, then propose the smallest
useful extension. If none fits, propose a new App. Do not call
`integral_list_models` or read existing entries just to design an App; existing
records matter only when the user asks to find, assess, or change those records.
Do not repeat `integral_check_design_coverage` with the same blueprint. Apply
every reported correction in one revision; once the result is `buildable`, call
`integral_propose_design` next.

**Do not narrate a shadow workflow.** For a request to create an app, or a
description of a problem the user wants solved, first determine whether an
existing App already supports the complete workflow. If it does, show the
relevant destination and concise steps. If it covers only part of the need,
propose the smallest useful extension to that App before replying; do not
describe a possible improvement and leave the user to ask for it again. A
current value such as next service due date does not record past service
events. When the need is to keep a service history, propose a linked history
Track in the matching equipment App. If no existing App fits, propose a new
App. Never ask whether to check the workspace or whether to draft a design;
do both. A prose outline with no `integral_propose_design` record is not a
design step. Once a
recorded proposal is affirmed with "go ahead", "build it", or equivalent,
begin and commit the build in that same turn. Do not reproduce a long design,
ask for the same confirmation again, or imply that a further approval is
needed. A reminder is only part of the delivered app when its routine is in
the batch with a stated cadence and timezone; otherwise call it a proposed
follow-up, never an automated reminder.

## When NOT to use — delegate

Existing-record CRUD → skill `integral-entries`. Existing-schema changes →
skill `integral-model`. Library lifecycle → skill `integral-models`.
Routine-only work → skill `integral-scheduling`. For greenfield, consult those
as specialists but **retain delivery ownership**. Do not stop at an empty
skeleton or bounce the user between skills mid-build.

## Substrate constituents

Canonical mental model: **App ≈ schema / database**, **Track ≈ table**,
**Entry ≈ record**. Everything below is what you compose into a complete app.

| Constituent | Role |
|-------------|------|
| **App** | Workspace-scoped container; groups tracks; may host app-scoped skills. |
| **Track** | Typed table under an app; owns an attached Operational Model. |
| **EntryType** | Record shape under the track profile (`key`, `name`, `fields[]`). One track may declare multiple entry types; views can slice via `entry_type_keys`. |
| **Field** | Column on an entry type. Built-ins below; live set from `integral_describe_substrate`. |
| **Relation** | Field `type: relation` — the only first-class cross-record pointer. |
| **View** | Projection of a track (or app surface) via a palette `view_type` + `config`. |
| **Operational Model** | Schema document attached to app/track (entry types, taxonomy, views). Inline on `create_app_track`, apply a library package, or author/modify. |
| **Library package** | Reusable profile template. Track-scope packages shape a track; app-scope packages are not per-track templates — never apply an app package to every track. |
| **Entry** | Concrete record. Demo seeds use structured `fields` + `entry_type`. |
| **App skill** | Authored SOP (`integral_author_skill`) for multi-step operating procedures. Agent-guided behavior, not a DB constraint. |
| **Routine** | Scheduled reminder (`integral_schedule_task`) — personal cadence in chat; date fields do not notify by themselves. |
| **Batch** | Single approval unit: begin → append ops → commit. Greenfield chat-affirm applies on commit. |
| **Artifact** | Session notes (e.g. `app_design_blueprint` from `integral_propose_design`). |

### Field palette

| `type` | Use |
|--------|-----|
| `text`, `markdown` | Free-form / long form |
| `number`, `boolean` | Scalar |
| `date`, `datetime` | Time placement (calendar / timeline / reminders) |
| `select`, `multi_select` | Closed option sets (`enum` / options) — boards group on these |
| `relation` | Lookup or anchor (see Weave) — config **nested** under `spec.relation` |
| `computed` | Derived values the substrate supports |
| `file`, `files` | Attachments — gallery image source |
| `json` | Structured blob when no typed field fits |
| `member` | Workspace member reference; a seed value of `{{user.id}}` means the requesting user |

Always confirm advanced shapes and required config keys via
`integral_describe_substrate` — do not invent field types.

**Selects for workflow state, tags for cross-cutting classification.** A
closed set a board groups on (status, stage) is a `select` field. A vocabulary
that cuts across records (priority, region, topic) is a tag group on the
Track: declare it under the Track's `tag_groups` in the blueprint, and build
it inline with `integral_create_app_track.args.taxonomy`
(`{tag_groups: [{name: "Priority", tags: ["Urgent", "Routine"]}]}`). Seeds
list tag names in `args.tags`; a view filters by tag with
`{field: "tags", operator: "eq", value: "{{tag.id:Urgent}}"}`.

### View palette

Profiles reference **palette keys**, not UI code. Prefer the smallest view that
answers an operational decision. Every non-baseline view needs supporting
fields already on the track.

#### Core widgets

| `view_type` | What it is | Weave contract |
|-------------|------------|----------------|
| `table` | Sortable/filterable grid; `config.columns` optional | Working surface. **Add one when the design names it**; the builder does not add one otherwise. |
| `feed` | Chronological stream (`default_always_on`) | Activity / update-shaped tracks. Do not add for “completeness” on every table. |
| `kanban` | Column board; `group_by: custom_fields.<field>`, `kanban_columns: [{key: "<exact select value>", label: "<display label>"}]` | Needs a `select` (or equivalent discrete field) whose values are columns. |
| `calendar` | Month/week/day; `calendar_mapping: { dateField: "custom_fields.<date>", endDateField: "custom_fields.<end>" }` | Needs `date` / `datetime` fields; endDateField is optional. |
| `gallery` | Card grid with image preview | Needs `file`/`files` (or image URL field); else do not promise gallery. |
| `wiki` | Hierarchical pages (UI label **Wiki**); `parent_field`, `body_field`, `title_field` | Needs parent `relation` → entry + markdown body. |

#### Composable meta-widgets

Declarative grouping/sort/filter/projection — use when a core widget’s fixed UX
is not enough, without inventing new React.

| `view_type` | Role | Key config |
|-------------|------|------------|
| `composable_list` | Generic list | `group_by`, `sort`, `filter`, `projection`, `density` |
| `composable_grid` | Card grid | `group_by`, `color_by`, `projection`, `card_layout` |
| `composable_board` | Board via config (swimlanes, color) | `group_by`, `color_by`, `swimlanes`, `sort_within_column` |
| `composable_timeline` | Vertical time axis | `date_field`, `end_date_field?`, `group_by`, `color_by` |

#### Other palette entries

| `view_type` | Notes |
|-------------|--------|
| `extension_view` | Sandboxed app-package view (`extension_view_key`) — only when an installed extension exposes one. |
| Manifest `view_types[]` composites | Profile-local aliases over a base palette key (e.g. a named board). Not new palette entries; resolve via profile tooling. |

Dashboard / region contracts (`summary_tiles`, chart regions, layout containers,
…) exist in the contract catalog for richer surfaces — only use when
`integral_describe_substrate` (or profile tooling) lists them as creatable for
your path. Prefer core + composable for first apps.

**View selection rule:** name the decision the user must make, pick one view
type that answers it, ensure required fields exist, then stop. Do not sprinkle
feed/gallery/kanban on every track. A track with a specific view opens on it,
not on the Feed: when a track has several, mark the most useful one
`is_default` (the build otherwise picks the first non-feed view).

## Weave patterns — how constituents form a complete app

1. **Tables first.** Map managed nouns → tracks; attributes → fields; closed
   operational states → `select` / `multi_select`. Prefer a small coherent set
   of tracks over a sprawling schema.
2. **Entity vs attribute.** Own track only when the thing has several fields,
   its own list/views, or is referenced from **two or more** other tracks.
   Otherwise keep a scalar/text field on the parent record.
3. **One source of truth.** Do not mirror the same fact in two fields. Pick one
   authoritative representation; procedures and views read that.
4. **Two reference patterns — pick one per relationship** (skill
   `integral-model` for edge cases):
   - **Lookup** — `relation` with `target: entry` → `REFERENCES`. Many records
     point at one independently managed record. Put the relation on the side
     that *points*. Cross-track lookups are allowed and are the normal case.
     Set `allow_cross_track: true` and `target_track_types`. Never tell the
     user that relation fields must stay inside one track.
     Config nested under `relation`:
     ```json
     {"key":"…","name":"…","type":"relation","relation":{
       "target":"entry","target_track_types":["…"],
       "target_entry_types":["…"],"allow_cross_track":true,"many":false}}
     ```
   - **Anchor** — `relation` with `target: track` → `ANCHORS`. Parent owns a
     heavyweight detail collection with its own views/ACLs. Prefer **multiple
     EntryTypes under one anchored track** + `entry_type_keys` on views over
     one anchored track per child category.
   - Never both for the same relationship. Never invent reverse “list of X”
     relation fields on the looked-up side — reverse browse is a view/query.
5. **Views bind to fields.** Board ↔ select; calendar/timeline ↔ date(s);
   gallery ↔ file/image; wiki ↔ parent relation + markdown; table ↔ any
   fields, when the design names it.
6. **Procedures close the loop.** Multi-record consistency that users expect
   (“doing A also updates B”) is an `integral_author_skill` in the same batch —
   prose in the design is not acceptance. Skills guide; they are not locks.
7. **Time → routines only on request.** A due or service date can be tracked
   with a date field and a useful sorted view. Add `integral_schedule_task`
   only when the user asks for a reminder, notification, or recurring action;
   do not infer one just because the App tracks dates. When a routine is
   requested, use the known workspace timezone or ask for it if unavailable,
   and state its cadence and timezone in the proposal. If discovered only after
   approval, ask only for the timezone and do not request build approval again.
   A date field alone does not notify.
8. **Seeds prove the graph.** Demo entries (unless user wants empty) should
   exercise each track and each lookup edge with fictional labels — no real PII.
9. **Honesty.** Say what the substrate cannot enforce (concurrency locks,
   automatic side effects without a skill/routine). Never silently downgrade a
   requirement.
10. **Acceptance is inspectable.** Checklist lines map to concrete fields,
    views, relations, skills, routines, or demo rows you will create.

## Grounding (read before write)

1. `integral_list_apps` before every app design. Continue a partial build via
   `integral_list_tracks` rather than duplicating.
2. `integral_describe_substrate` only after a type or config key is rejected.
3. `integral_list_routines` when scheduling — avoid duplicates; establish IANA
   timezone (ask if unknown).

Batch tokens for new objects: `{{app.id}}`, `{{track.id:<Name>}}`,
`{{entry.id:<Label>}}`. A token only references objects created **earlier in
the same batch**. Never fabricate ids. Unique names within the build.

## Procedure

### 1. Guide the design

Translate need → tracks, fields, relations, views, procedures, reminders using
the weave patterns above. Ask only questions that change the operational
result (`integral_ask_user` for real forks). Offer defaults; distinguish manual
status, agent-guided skills, and enforced rules. Never ask "anything else?"
or about optional extras before proposing: include the sensible ones in the
proposal and let the user trim it.

**Respect resolved scope.** When the user says an app must be *distinct*,
*separate*, or *new*, that is an explicit decision to create a new App with
the requested name even if similarly shaped apps already exist. Mention the
nearby apps only when they create a concrete naming conflict; do not reopen
the reuse-versus-create question after the user has affirmed the design.

**Reuse discovered structure.** If a discovered App already covers the same
real-world items, propose against it and pass its exact `target_app_id` from
`integral_list_apps`; do not restate that App or one of its Tracks as new. Add
only the missing capability. A current status or next-due date is not event
history: when the user needs history over time, add a linked history Track to
the fitting App rather than duplicating its register. Propose a new App only
when none of the discovered Apps fits or the user explicitly asks for a
distinct one.

Before designing an extension, identify whether an existing Track already
represents the real-world thing whose new events must be recorded. If it does,
the event Track's relation must point to that existing Track's entry type.
Never create a parallel register for the same things just to make the new
history Track easier to model; preserve existing fields and views and do not
copy their values into a second source of truth. Add only the event Track and
its necessary relation and event fields. Add a view only when it directly
serves the requested workflow (normally one table for a new history Track).
Do not infer a board, calendar, current-status redesign, or extra tracking
fields from a request for historical events. For example, when an existing
Tools Track already stores each mower and its next service date, a request to
keep service history calls for a Service Log linked to the existing Tool
entries, not a second Mowers Track.

Call `integral_propose_design` with a concise design in `proposal`. Include
only the requested scope and necessary setup. This tool persists both the
proposal and its blueprint; do not store them separately with an artifact
write before proposing. For a simple request, a short
paragraph or a few bullets with one approval question is sufficient; do not
add a separate offer, plan review, or confirmation round. When adding a
Track to an existing App, include its real `target_app_id` from
`integral_list_apps`; this binds the approved design to that App. The user
reads the proposal, so write it for someone non-technical: display names
only (no field keys, types, ids or tool terms), each part described by what
it lets them do:
- App + each track (what it keeps track of, its fields by display name, and
  which other lists it links to)
- Views and the question each one answers
- Routines it will remember, each usable only in this App (default) or from
  anywhere in the workspace
- Reminders (when, how far ahead, how often, delivered in this chat)
- Sample records to add, or none
- A short checklist the user can check once it is built

Always pass the same design as the typed `blueprint` argument: `app`,
`tracks` (entry types, fields with lowercase `key` plus display `name`),
`views` (each names its `track` item id and the `decision` it answers; at
most one per track has `is_default: true` — the view the track opens on), and
only the optional sections the design includes — omit `dashboard`, `skills`,
`routines`, `seeds` when there are none. Give every item a stable lowercase
`id` (`track.jobs`, `f.due_date`, `view.board`); on an amendment keep the ids
of unchanged items and pass the whole revised blueprint. Record platform
defaults you rely on under `platform_defaults`; the Feed on every Track is
`{"id": "default.feed", "kind": "feed", "detail": "..."}` (`kind` is the key
the build checks, so write it exactly), and code-backed actions under `operations`. Unresolved questions go in
`open_decisions`; the build refuses until they are resolved. Include only
unresolved choices necessary for the requested setup. Optional features that
the user did not request are omitted, not open decisions or extra approval
questions. A Track's
`tag_groups` list tag names; a seed's `tags` must come from its Track's
groups. An anchor goes **only** under `track_templates` (same shape as a
Track, no `tag_groups` yet) — never also under `tracks` — and the parent
entry type carries the field that anchors it:
`{"key":"details","name":"Details","type":"relation","relation":{"target":"track","target_track_template":"tpl.details"}}`.

Start empty unless the user requested sample records or supplied records to
include. Do not introduce demonstration rows or offer them as a default.
For each requested seed, put only values the user supplied or explicitly approved in
`fields`. Leave every other field absent, including dates, locations, status,
and contact details on a Demo or Example record. Show the exact proposed seed
values in the design preview. Ask before adding an illustrative value: it
becomes a saved record after the build. Do not fill blanks just to populate a
table or calendar.

**Check coverage first.** Pass the blueprint to
`integral_check_design_coverage` before `integral_propose_design`. Replace
every `unsupported` item with what its `detail` offers (a board needs a select
field, a calendar a date field, a wiki a relation field) — the proposal tool
refuses a design that still has one. Behaviour that needs custom code (a
payment charge, an external API call) goes under `operations`; each
`requires_trusted_package` item must be named in the proposal, never promised
as part of this build. Tell the user in plain words that it needs a custom
add-on that can't be set up from chat; never call it a package or integration.
When the proposal is recorded, that add-on is written up as a developer
specification on the conversation (`operation_bridge`). It is not installed
and it is not a tool you can call. Do not tell the user the action works.

**Preview the same proposal markdown in your reply** — the user reads chat,
not an internal artifact. The tool stores the revision as
`app_design_blueprint` (`integral_get_artifact`). End turn; wait for confirm
or correct. This preview is not authorization and creates nothing. For an
explicit design-only request, begin the reply
“Proposed — nothing has been built.” and end with “Confirm this design, or
tell me what to change.”; do not call a build tool. Correction → `integral_propose_design`
again from prior body + deltas only. Affirm with no shape change → build (no
re-propose and no second approval).

### 2. Build the confirmed design

Chat affirm ("looks good", "proceed", "build it") **is** approval. Finish in
the same turn. `integral_build_approved_design` applies the affirmed design
immediately for new Apps and approved existing-App additions. Do not request
a second approval or promise a Prompt Sheet on this path.

Use one `integral_build_approved_design` call with the complete ordered
`operations` array. Each item is `{tool: "integral_…", args: {...}}`. The only
valid `tool` values inside that array are `integral_create_app`,
`integral_register_track_template`, `integral_create_app_track`,
`integral_create_tag`, `integral_save_view`, `integral_create_entry`,
`integral_create_dashboard`, `integral_author_skill`, and
`integral_schedule_task`. Never put `integral_author_model` inside this array:
it creates a detached library model, not an App Track. Put each Track's fields
inside `integral_create_app_track.args.entry_types`.

For an anchor, register the template **before** the parent Track:
`integral_register_track_template` with `app_id`, `name` and `entry_types`.
The parent's relation field is `{target: "track", target_track_template:
"<template name slug>"}` (`Project Details` → `project_details`). No detail
Track exists after the build: each parent entry gets its own when it is
created, so seeds leave the anchored field out.

For a **new App**, first use `integral_create_app`, then create its Tracks with
`app_id: "{{app.id}}"`. For an **addition to an existing App**, look up its
real ID, pass `target_app_id`, and make the first operation
`integral_create_app_track` with that same real `app_id`. Never create the App
again. Then add the requested views, records, dashboard, skills and routines.
App and Track names must match the approved proposal. Use the published
field keys from the saved blueprint verbatim, including every view reference;
do not regenerate keys from the prose labels. View `sort` is an array of
`{field: "custom_fields.<key>", direction: "asc" | "desc"}`. Each board
column uses `key` equal to the exact approved select value and an optional
`label`; a label is not a substitute for the stored value. Use the published
argument names `name` and `description` on track creation and `name`,
`view_type`, `track_id`, `config` on view creation. Keep the view name, type,
and track reference at the top level of `integral_save_view.args`, not inside
`config`. A Wiki view uses
`config.parent_field` with the key of a `relation` field on the new Track;
its Body field should be `markdown`. For a parent-page relation use
`relation: {target: "entry", target_entry_types: ["Wiki Page"],
allow_cross_track: false, many: false}`. Do not use `relation.track`,
`relation.entry_type`, or `hierarchy_field`. Plan only the views the approved design names. Do not add an
"All {Track}" table or a calendar unless that design asked for one. The
platform Feed is already on every Track. If the approved
design says no demo entries, add none; the builder honors that choice.
After `applied: true`, verify the saved result, then finish the same turn with
one or two short sentences linking the App and confirming the outcome.
Mention sample entries only when relevant; do not repeat the schema or views.
Do not ask for another approval and do not end on the system marker alone.
Copy the approved App and Track names exactly; do not rename the App at build
time. This operation commits its own batch: do not put `integral_begin_batch`
or `integral_commit_batch` inside the operations array, and do not stop after
an error if the same approved design can be corrected. Include the requested
dashboard in this same plan. For dynamic date filters, use typed values
`{"relative_date_days": 0}` (today) or `{"relative_date_days": 7}` (seven
days ahead); saved-view filters use `config.filters` entries with `field`,
`operator`, and `value`, while dashboard `data_source.filters` uses `field`,
`op`, and `value`.
If it returns `invalid_scaffold_plan` or `plan_differs_from_design`, revise
the `operations` array and call **the same tool again in this turn**. These
preflight errors have made no writes and need no second user approval. Do not
switch to `integral_begin_batch` or author detached library models to work
around a rejected fresh plan. If the tool reports a partial apply, inspect
its receipt and repair only the unfinished portion of that existing App.
If an unfinished sample needs different values, propose the complete revised
blueprint with the same item IDs, changing only fields of unapplied samples.
State the missing required values explicitly, retain all tracks, views and
routines, and wait for approval of that revision. The approved build resumes
the successful cursor; its operations cannot recreate completed resources.
Expired or unavailable partial batches require inspecting the existing app
and explaining what remains; never start another app to bypass recovery.

The saved blueprint is the source of truth for build-plan details. A model-
generated mismatch is plan repair, not a reason to ask the user to approve the
same design again: remove unapproved additions and restore omitted approved
items, then retry in this turn. If the approved design itself needs a material
change to be buildable or to meet the request, do not silently change it. Show
the user only the specific change and its consequence, ask once whether that
delta is acceptable, and preserve approval for everything else. After the user
approves the revised design, continue without another general go-ahead. Ask
only for genuinely unresolved details that change the result (for example, a
timezone needed for a requested reminder); acknowledge the approved design and
proceed as soon as that detail is answered.

With a blueprint, the builder compares the plan structurally: every
blueprint Track, track template, field key, anchor target, view, seed,
dashboard, skill, and routine must
appear, and anything extra is refused as `plan_differs_from_design`; the
message names each item. Match field `key`s exactly.

The operation uses the same policy-bound staging and batch executor as the
individual tools, commits once, and returns an applied receipt. Without a
blueprint it adds a table only when the approved design asks for one, and a
dashboard only when the design asks for one and the plan omits it. It never invents demo records:
seeds come only from `integral_create_entry` operations in the plan, and every
entry the design names must be among them.
Use the individual calls below only when resuming an already
open batch that contains writes; never submit the same new App through both
paths. Do not open a manual batch for a freshly approved design.

1. `integral_begin_batch` once (re-enter keeps prior ops).
2. `integral_create_app` (or extend existing by real id).
3. `integral_create_app_track` for every planned track with inline
   `entry_types`/fields. A detached library model is not an attached schema.
4. `integral_save_view` per view the design names — only with
   real field keys and valid config for that `view_type`. A table must include
   `config.columns` using `custom_fields.<field_key>`; a kanban must include
   `group_by: custom_fields.<select_field>` and `kanban_columns`; a calendar
   must include `calendar_mapping.dateField`. An empty config produces a
   generic platform view and does not complete a scaffold.
5. `integral_create_entry` only for requested records — `entry_type` +
   structured `fields`; referenced records before dependents. Never put
   `Field: value` lines only in `text`: that supplies a title but leaves every
   operational field empty. For a linked record use a named batch reference,
   e.g. `fields: {vehicle: "{{entry.id:Honda Civic}}", status: "Active"}`
   after the Honda Civic entry. The approved-plan builder converts exact
   labelled seed text when possible and rejects ambiguous lines.
6. `integral_author_skill` for agreed multi-step procedures (`app_id`,
   discovery description, `tools_required`, `body_override`; portable Markdown instructions). The build scopes each skill from its blueprint `visibility`:
   `app_private` (default) or `workspace`. Set `workspace` only when the user
   chose it, in whatever language they speak; if it is unclear, ask. Say
   plainly in the proposal which skills work from anywhere, because approving
   the design is the user's choice.
7. `integral_schedule_task` in the same batch after referenced tracks exist
   (skill `integral-scheduling`). Cron + IANA timezone; self-contained
   instruction with batch tokens; read-only reminders stay free of write_scope.
8. Checklist vs ops, then `integral_commit_batch`. Explicitly empty app only:
   `allow_empty=true`; schema and views remain mandatory.

Dependency order inside the batch: app → tracks/schemas → views → seed
entries (parents before linked children) → skills → routines → commit.

### 3. Recover without duplication

- `design_amend_required` — re-propose prior+deltas; do not build stale outline.
- `affirm_build_instead` / `already_proposed` — build, do not re-propose.
- `batch_incomplete` / `ready:false` — append missing ops to **same** batch,
  commit again.
- Invalid args — fix from error + live contract; do not repeat identical fails.
- Bad refs/order in open batch — `integral_cancel_batch`, rebuild in order.
- Partial execution — resume retryable batch; do not recreate completed objects.
- User rejection — stop.

### 4. Verify and hand off

After an apply returns `design_id`, `design_revision`, and
`execution_receipt_id`, call `integral_verify_build` with those three values
before telling the user anything was built. The call only reads the objects
from that apply. Calling it again does not build again. A later amendment or
a later change to those objects needs a new apply and a new verification.

`verified` — confirm in one or two short sentences with the App link. For a
new build, include one useful starting action only if needed. A recheck needs
only the outcome. Do not repeat fields, views, the design, or internal checks.
Give a full inventory or operating guide only if the user asks for it.
`partial` — say what is missing in plain words and repair only that.
`blocked` or `failed` — say you could not check. Do not claim it is ready.
A rejected revision or receipt means you passed the wrong ids; do not rebuild
to get a different answer.

Do not claim a routine has fired merely because it is active. No apply
receipt means nothing was built.

## Staging discipline

Design confirmation in chat; greenfield apply on `integral_commit_batch` after
affirm. Propose tools only accumulate while a batch is open. Wait for apply /
consumption before claiming creation. Never execute around the approval path.
Sequential batches are resumable, not atomic transactions.

## Forbidden patterns

- Skeleton app (no field-bearing schemas / no views) called “done”.
- Field or view types not in live substrate; guessed config keys.
- Views without their weave-contract fields.
- Reverse-list relation fields; dual lookup+anchor for one relationship;
  duplicate state fields.
- Forward batch token refs; fabricated ids; duplicate apps/tracks on recovery.
- Procedures described in prose with no `author_skill` / batch step.
- Date fields treated as notifications; reminders without timezone/cadence.
- Prompt Sheet language for chat-affirmed greenfield.
- Realistic PII in demos; demos when user asked for empty; silent destructive
  automation.
- Scaffold ↔ model ownership ping-pong; one card per create instead of one
  batch; repeating identical failing tool calls.

## Example — abstract weave

User asks for an operational app. Propose directly from the types in this skill:

**Propose (chat):** App with tracks **A** (assets/items), **B** (parties),
**C** (events/transactions). C holds lookups → A and → B (one-sided,
`allow_cross_track: true`). A has a `select` for operational state and
`date`/`datetime` fields for due/expiry where needed. Views: table on each
track; kanban or `composable_board` on A only if the select exists; calendar
or `composable_timeline` on C only if date fields exist; no gallery without
`file`/`files`. Name skills that keep A and C consistent; name any routine
that watches date fields. If requested, demo seeds exercise A, B, then linked C. Checklist
maps 1:1 to those objects.

**On affirm:** one batch — create app → create/shape tracks → save views →
seed entries → author skills → schedule routines → commit. Verify via list/
schema/query tools. Hand off with link and operating notes.

Leave domain naming, track count, and which palette keys fit to judgment
guided by the user’s need and the weave contracts above.
