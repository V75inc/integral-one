---
name: integral-dashboards
description: Create and edit distinct App Home tabs, and compose app-scoped analytics dashboards — create, adjust, add/remove widgets, change layout, rename. Use for bar charts, KPI tiles, edits to an existing board, or vague requests like the best dashboard for this App.
allowed-tools: integral_find_workspace_resources integral_get_page_context integral_preview_app_home integral_describe_dashboard_substrate integral_list_dashboards integral_read_dashboard_data integral_suggest_dashboard integral_create_dashboard integral_update_dashboard integral_delete_dashboard integral_update_app integral_read_app_home integral_list_tracks integral_describe_model integral_activity_digest integral_count_entries integral_list_apps
---

# Integral dashboards — SOP

Before changing existing Apps or Tracks, identify every source and destination.
Use current-turn verified page context only when it and the user request clearly
identify the targets. Otherwise use `integral_find_workspace_resources` to find
candidates; follow further pages or use current navigation if incomplete, and
clarify genuine ambiguity. Suggestions are metadata, not evidence of records,
permission, or approval.

## When to use

The user wants an **app-level dashboard** — KPI tiles, bar/line/pie charts,
activity summaries, or a full layout of widgets across the app's tracks.

## When NOT to use

- Deleting a whole **App** or Track, including after creating a dashboard —
  use `integral-workspace`. Never substitute `integral_delete_dashboard`
  for an App deletion. The latest requested resource type takes precedence
  over the previously edited dashboard; resolve ambiguous selections from
  current-turn page context, or ask before staging a destructive change.
- Saving a **track view** (kanban, table, feed) — delegate to the
  `integral-insights` skill for operational surfaces on one track.
- Schema changes — delegate to the `integral-models` skill.

## App settings placement (required)

All App-specific settings controls MUST use the standard App settings dialog
opened from the App header. Declare configuration in `app.settings_schema`;
never create settings editors on Home, dashboards, Tracks, Entries or extension
views. Keep record-entry and other operational forms on their working surfaces.
Preserve settings values when revising an App. If the shared settings renderer
cannot express a control, identify the required contract extension rather than
inventing a separate UI or unsupported settings-write tool. Use available
canonical authoring/approval paths and verify saved values before claiming success.

## Shared native Home authoring

Developers and the resident agent share one installed-App Home contract.
Read `integral_read_app_home` before editing and record `home_revision`. Its
`components` expose the native component schema; `bindings` list the owning
App's declared queries and operations. Preserve unrelated sections and IDs.

Use dashboard widgets, mixed `type: native_component` blocks with `content`, or
a complete `renderer: native` Home with a `content` tree. Compose stack/grid,
cards, headings/text/markdown, metrics/charts/records, forms/actions and
tabs/accordions. Forms name declared operation input fields; data components
use declared query keys. Do not use iframes, HTML, scripts or arbitrary CSS.
Preview with `integral_preview_app_home`; data is opt-in and actions disabled.
Stage `integral_update_app` with the observed `expected_home_revision`. Approval
persists separately from package defaults. On conflict reread and reconcile.
`{}` restores the package Home. Read back after approval and link the App Home.
Never claim a proposed change was saved or execute an action while rendering.

## App Home is a separate surface

A request to create an App Home or Home tab is not a request for another
analytics dashboard. Use `integral_update_app(app_id, home={title, description,
widgets})`. Ground its content with `integral_suggest_dashboard` sources and
published fields. Home supports up to 12 nonoverlapping widgets, an introduction
and ordinary approval. Do not create a dashboard named Home or claim a default
dashboard creates a Home tab. Call `integral_read_app_home` after approval to verify it.

### Home authoring and repair

Use the `home` schema advertised by `integral_update_app`; it is the same
composition contract the server validates. A minimal shape is:

```json
{"title":"Home","description":"Start here","widgets":[{"id":"overview","type":"metric_card","grid":{"x":0,"y":0,"w":4,"h":2},"data_source":{"kind":"declared_query","query_key":"<returned source key>","query_params":{},"rows_path":"<returned rows path>","total_path":"<returned total path>"}}]}
```

The placeholders above are structural examples, never callable source names.
Copy actual bindings from `integral_suggest_dashboard`. Prefer its `home` object
as the starting composition: it is already checked against Home rules and excludes
analytics-only preview metadata. If `home` is null, there is no eligible starter;
explain what is missing instead of repeatedly submitting the same invalid layout.
Reuse its returned widgets when appropriate; adapt titles and layout to the App's purpose. Read
current Home once to preserve any existing content. Do not list unrelated
analytics dashboards or search conversation history to rediscover a known App.
Use focused schema reads only for fields the chosen composition actually needs.

On `invalid_arguments`, correct the named fields against the disclosed schema
and retry the proposal. On source denial, use an eligible returned source or
explain the missing contract. Do not repeat unchanged arguments, re-run broad
discovery after a shape error, or treat a failed proposal as a pending approval.
Once a proposal is staged, present it and stop until the user decides.

## Grounding

- Confirm `app_id` from page focus or `integral_list_apps` before staging.
- Call `integral_describe_dashboard_substrate` this turn for widget types and
  default grid sizes — do not invent widget `type` strings.
- For chart breakdowns, resolve `track_id` via `integral_list_tracks` when the
  user names a track; otherwise app-wide `grouped_count` is valid.
- Read the published Track model before binding business status, due dates, costs,
  or categories. Draft fields are unavailable until publication. Use explicit
  `custom_fields.<key>` paths; business Status is not platform status.
- For installed Apps, call `integral_suggest_dashboard(app_id)` before building
  or repairing widgets. Its `sources` contain eligible per-Track declared query
  bindings and published fields. Copy each source's query key, Track identity,
  rows/total paths and parameters exactly. Use `op`, `field` and `group_by` to
  compose KPI tiles, sums, categorical/date charts or typed record summaries.
  Never substitute generic Core counts/scans on package-owned Tracks. Core can
  qualify portable record query templates and complete their pagination.
  Treat a missing source or a preview error as unavailable, never as zero.
- A starter suggestion is optional inspiration, not proof it answers the request.
  Preserve the user's requested scope and explain unsupported details.
- `recent_entries` shows titles only. `table_widget` shows Record, platform Status,
  and Updated; neither currently renders arbitrary `config.columns`. Do not
  promise due dates, assignees or an upcoming sort these renderers lack. Offer
  the existing saved Track view for those details.
- Currency and scale must come from the published schema or explicit user input.
  A unitless number is not cents. Preserve provided currency; never invent a
  currency or divide amounts by 100. Distinguish estimates from paid costs.
- Only cite dashboard names and widget titles returned by tools in this turn.

## Procedure

1. **Ground** — confirm `app_id` (page focus or `integral_list_apps`). Optionally
   `integral_list_tracks`, `integral_activity_digest(scope=app, scope_id=app_id)`.

2. **Introspect** — `integral_describe_dashboard_substrate` for widget types and
   default sizes.

3. **Always include widgets** — never stage `integral_create_dashboard` with an
   empty or omitted `widgets` array. A name-only create is a bug.

3a. **Adjust an existing dashboard** ("add a chart", "change layout", "rename"):
   - `integral_list_dashboards(app_id)` → pick `dashboard_id` (prefer page
     focus `focused_dashboard_id` when present).
   - Read current `widgets` from that list result — do not invent a fresh set.
   - Merge the requested change into the full widgets array, then stage
     `integral_update_dashboard(app_id, dashboard_id, widgets=[…])`.
   - Never call `integral_create_dashboard` when a board already exists for
     this request unless the user explicitly asks for a second dashboard.

4. **Specific requests** (e.g. "bar chart of pipeline by stage"):
   - Resolve track + field via profile / track list.
   - Pick `chart_bar` with `data_source: { kind: grouped_count, track_id,
     group_by: custom_fields.<field_key> }` for an operational profile field.
     Bare `status` means Integral's platform lifecycle status, not a business
     field named Status. Read the track schema first and use the exact field
     key. Do not rely on fallback grouping.
   - Stage via `integral_create_dashboard` or `integral_update_dashboard` **with
     the full `widgets` list**.

5. **Vague requests** ("best dashboard for this app" / "create a dashboard"):
   - Call `integral_suggest_dashboard(app_id)`.
   - Explain the rationale, then stage `integral_create_dashboard` with the
     returned `name`, `layout`, **and `widgets`** (copy the widgets array
     verbatim — do not drop it).

6. **Bless** — user approves the staging card; executor persists the dashboard.
   Confirm the staging card shows a non-zero widget count before asking for
   approval.

7. **Read back after approval.** On the following turn, call
   `integral_list_dashboards(app_id)` and `integral_read_dashboard_data(app_id, dashboard_id)` before describing the dashboard. Name
   the dashboard and its persisted widgets from that result. Never say you do
   not know its layout immediately after creating it, and never describe a
   generic starter set as a domain dashboard when the app has operational
   tracks available for a better suggestion.

### Widget palette (common)

| Type | Use when |
|------|----------|
| `metric_card` | Single count KPI |
| `chart_bar` / `chart_pie` | Breakdown by status, tag, entry_type |
| `chart_line` | Trend over time (`group_by: date`) |
| `activity_digest` | What's happening per track |
| `recent_entries` | Latest updates |
| `track_breakdown` | Multi-track overview |

### Grid layout (12 columns)

Place widgets on a **12-column grid**. Spread them across rows — do not stack
everything at `x: 0`.

| Pattern | Example grid positions |
|---------|------------------------|
| Full-width KPI row | `metric_row` at `{x:0, y:0, w:12, h:2}` |
| Two charts side-by-side | `{x:0, w:6}` and `{x:6, w:6}` on same `y` |
| Three KPI tiles | `{x:0,w:4}`, `{x:4,w:4}`, `{x:8,w:4}` |

Use `integral_describe_dashboard_substrate` for each widget's `default_size`.
After composing widgets, verify no two widgets overlap and rows use horizontal
space (not a single column at `x: 0` unless intentional).

## Staging discipline

- `integral_create_dashboard` and `integral_update_dashboard` are **propose**
  tools — they return a staged-change envelope; the user blesses before the
  dashboard is persisted.
- Present the approval card and wait; do not claim the dashboard exists until
  `[SYSTEM:STAGING-RESOLVED] … state=consumed`.
- Explain observed errors without echoing private inputs; correct actionable
  validation errors against the schema and never retry unchanged arguments.

## Forbidden patterns

- Do not invent `app_id`, `dashboard_id`, or widget ids — resolve via
  `integral_list_dashboards` / page focus.
- Do not stage a create with zero widgets. If unsure, call
  `integral_suggest_dashboard` and forward its `widgets`.
- Do not stack every widget at `x: 0` on a 12-column grid unless intentional.
- Do not use track-view tools for dashboard layout — delegate to
  `integral-insights` for per-track saved views.

## Example

> **User:** "Add a status pie chart to this app's dashboard."

1. `integral_list_apps` or read page focus → `app_id`.
2. `integral_list_dashboards(app_id)` → pick target dashboard id (or stage a create).
3. `integral_describe_dashboard_substrate` → confirm `chart_pie` and default size.
4. `integral_update_dashboard(app_id, dashboard_id, widgets=[…])` with
   `data_source: { kind: grouped_count, track_id, group_by: custom_fields.<field_key> }`
   after reading the profile to resolve `<field_key>` → present card and wait.
5. Only after `state=consumed` confirm the chart is live.

## Result verification

After publication or a record update, read live widget values with
`integral_read_dashboard_data`. Report only values returned by that read, not
predictions from the configuration or cached record counts. If a widget returns
an error, report the error and remedy that widget rather than claiming the board
works. Revise the existing board when requested; preserve unrelated widgets.
