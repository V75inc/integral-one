"""Agent-facing attachment reads.

The resident agent needs a DIFFERENT shape than the HTTP attachment routes.
``list_entry_attachments`` (in ``app/api/attachments.py``) serializes via
``export_node(flat=True)``, which includes every node field — including
``extracted_text`` (capped at 10 MB). Shipping that inline per attachment
would blow the model context, so this module strips the body from the list
(summary only) and reads the full text through a single, context-capped tool.

Both functions enforce ``entry.read`` on the parent entry — the same gate the
HTTP routes use — and run as the ``service_ref`` target of the
``integral_list_attachments`` / ``integral_get_attachment_text`` tool bindings,
called as ``await fn(user_id=<principal_id>, ...)``.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import re
import stat
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.api.utils import export_node
from app.config import settings
from app.models.nodes import Attachment, ChatThread, Entry
from app.schemas.policy import Resource, Subject
from app.services.attachment_urls import (
    enrich_attachment_export,
    is_visible_to_user,
)
from app.services.policy_engine import evaluate as policy_evaluate
from app.utils.time import utc_now_iso

# Heavy fields dropped from each list item — the body is read on demand via
# ``get_attachment_text``; the summary fields below replace it.
_LIST_OMIT_FIELDS = ("extracted_text",)


def _agent_metadata(attachment: Attachment) -> dict:
    """Keep internal section maps and duplicate image bodies out of context."""
    metadata = dict(attachment.metadata or {})
    metadata.pop("semantic", None)
    typed = metadata.get("type_specific")
    if isinstance(typed, dict):
        metadata["type_specific"] = {
            key: value for key, value in typed.items() if key != "text_locations"
        }
    return metadata


async def _require_entry_read(user_id: str, entry: Entry) -> None:
    if not await _can_read_entry(user_id, entry):
        raise PermissionError(
            "You do not have permission to view this entry's attachments"
        )


async def _can_read_entry(user_id: str, entry: Entry) -> bool:
    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="entry.read",
        resource=Resource(
            kind="entry",
            id=entry.id,
            scope=f"track:{getattr(entry, 'track_id', '') or ''}",
        ),
    )
    return bool(decision.allowed)


async def _attachment_summary_items(
    entry: Entry,
    *,
    include_entry_ref: bool = False,
) -> List[Dict[str, Any]]:
    """Build the summary list items for an entry's visible attachments.

    Shared by the entry- and track-level listers so both emit the identical
    shape (identity + provenance + dims + delivery URLs, ``extracted_text``
    stripped to ``has_text`` / ``text_length``). ``include_entry_ref`` adds
    ``entry_id`` / ``entry_title`` so the track-level card can group files by
    their parent entry.
    """
    neighbours = await entry.nodes(edge=["HAS_ATTACHMENT"], direction="out")
    visible = [
        a for a in neighbours if isinstance(a, Attachment) and is_visible_to_user(a)
    ]
    items: List[Dict[str, Any]] = []
    for a in visible:
        item = await export_node(a)
        await enrich_attachment_export(item, a)
        item["metadata"] = _agent_metadata(a)
        body = item.get("extracted_text") or ""
        if a.mime_type.startswith("image/"):
            from app.services.attachment_metadata.observations import (
                image_description_text,
            )

            body = image_description_text(a)
        for field in _LIST_OMIT_FIELDS:
            item.pop(field, None)
        item["has_text"] = bool(body)
        item["text_length"] = len(body)
        if include_entry_ref:
            item["entry_id"] = entry.id
            item["entry_title"] = getattr(entry, "title", "") or ""
        items.append(item)
    return items


async def list_attachments_for_entry(user_id: str, entry_id: str) -> Dict[str, Any]:
    """List an entry's visible attachments as a deliverable summary.

    Each item carries identity, provenance, derived dimensions, metadata, and
    delivery URLs — but NOT ``extracted_text`` (summarised as ``has_text`` /
    ``text_length``). ``_kind`` lets the chat transcript render the result as a
    download card.
    """
    entry = await Entry.get(entry_id)
    if not entry:
        raise ValueError("Entry not found")
    await _require_entry_read(user_id, entry)

    items = await _attachment_summary_items(entry)

    result: Dict[str, Any] = {
        "_kind": "attachment_list",
        "entry_id": entry_id,
        "attachments": items,
        "total": len(items),
    }
    if items:
        # The chat renders this list as a download card BELOW the assistant's
        # reply. Steer phrasing deterministically so the model never claims the
        # card is "above" (it is not) and never pastes raw download URLs.
        result["assistant_reply_hint"] = (
            "The files are shown to the user as a download card below your "
            "reply. Refer to them as 'the files below' or just 'the files' — "
            "never say 'above'. Do not paste raw download URLs into your reply."
        )
    return result


async def list_attachments_for_track(user_id: str, track_id: str) -> Dict[str, Any]:
    """List EVERY visible attachment across ALL entries in a track, in one call.

    The per-entry :func:`list_attachments_for_entry` forces the agent to first
    enumerate a track's entries (a paginated read) and then fan out one list
    call per entry — so any entry past the first page silently drops its files,
    and the agent reports only a partial set (June 29 QA #6). This walks the
    track's full CONTAINS→Entry set server-side and returns the union, so "list
    the files in this track" is complete and deterministic.

    Gated on ``track.read``; entries the caller can't read (per-entry
    ``EXCLUDED_FROM``) are skipped, never leaked. Each item carries
    ``entry_id`` / ``entry_title`` so the chat card can group by source entry.
    """
    from app.models.edges import CONTAINS
    from app.models.nodes import Track

    track = await Track.get(track_id)
    if not track:
        raise ValueError("Track not found")

    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="track.read",
        resource=Resource(kind="track", id=track_id, scope=f"track:{track_id}"),
    )
    if not decision.allowed:
        raise PermissionError(
            "You do not have permission to view this track's attachments"
        )

    entries = await track.nodes(edge=[CONTAINS], node=["Entry"])
    items: List[Dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, Entry):
            continue
        # Honor per-entry read (EXCLUDED_FROM overrides the track cascade); skip
        # rather than raise so the listing stays complete for what's visible.
        if not await _can_read_entry(user_id, entry):
            continue
        items.extend(await _attachment_summary_items(entry, include_entry_ref=True))

    result: Dict[str, Any] = {
        "_kind": "attachment_list",
        "track_id": track_id,
        "attachments": items,
        "total": len(items),
    }
    if items:
        result["assistant_reply_hint"] = (
            "The files are shown to the user as a download card below your "
            "reply. Refer to them as 'the files below' or just 'the files' — "
            "never say 'above'. Do not paste raw download URLs into your reply."
        )
    return result


async def list_attachments_for_workspace(
    user_id: str, workspace_id: str
) -> Dict[str, Any]:
    """List EVERY visible attachment across ALL accessible tracks in a workspace.

    Mirrors :func:`list_attachments_for_track` at workspace scope so
    "show me all files in this workspace" is one deterministic call instead of
    a paginated entry fan-out that silently drops files (same failure mode as
    the pre-track-lister June 29 QA #6, now at workspace scope).

    Gated on workspace membership; walks tracks the caller can read via
    ``get_user_accessible_tracks``, then per-entry ``entry.read``. Each item
    carries ``entry_id`` / ``entry_title`` / ``track_id`` for grouping.
    """
    from app.models.edges import CONTAINS
    from app.models.nodes import Workspace
    from app.services.agent_scope import current_scope_workspace_id
    from app.services.permissions import get_user_accessible_tracks
    from app.services.workspace_permissions import can_access_workspace

    # Membership alone is not enough under a bound scope. This is the one
    # attachment reader that takes a workspace by argument, and gating it on
    # membership let an agent conversation scoped to workspace A read every
    # file in workspace B — legal by membership, but exactly the cross-workspace
    # read PC-2 says is refused. When no scope is bound (direct service or API
    # callers) the membership gate below remains the whole check.
    #
    # Checked BEFORE the lookup: an out-of-scope workspace should not cost a
    # round-trip, and "not found" must not be distinguishable from "exists but
    # out of scope" — otherwise this probes which workspace ids are real.
    bound = current_scope_workspace_id.get()
    if bound and bound != workspace_id:
        raise PermissionError(
            "This conversation is scoped to another workspace; attachments "
            "cannot be read across workspaces. Switch workspace and ask again."
        )

    workspace = await Workspace.get(workspace_id)
    if not workspace:
        raise ValueError("Workspace not found")

    if await can_access_workspace(user_id, workspace_id) == "none":
        raise PermissionError(
            "You do not have permission to view this workspace's attachments"
        )

    tracks = await get_user_accessible_tracks(user_id)
    scoped = [
        t for t in tracks if (getattr(t, "workspace_id", "") or "") == workspace_id
    ]

    items: List[Dict[str, Any]] = []
    for track in scoped:
        entries = await track.nodes(edge=[CONTAINS], node=["Entry"])
        for entry in entries:
            if not isinstance(entry, Entry):
                continue
            if not await _can_read_entry(user_id, entry):
                continue
            for item in await _attachment_summary_items(entry, include_entry_ref=True):
                item["track_id"] = track.id
                item["track_title"] = getattr(track, "title", "") or ""
                items.append(item)

    result: Dict[str, Any] = {
        "_kind": "attachment_list",
        "workspace_id": workspace_id,
        "attachments": items,
        "total": len(items),
    }
    if items:
        result["assistant_reply_hint"] = (
            "The files are shown to the user as a download card below your "
            "reply. Refer to them as 'the files below' or just 'the files' — "
            "never say 'above'. Do not paste raw download URLs into your reply."
        )
    return result


async def resolve_readable_attachment(
    user_id: str, attachment_id: str
) -> Tuple[Attachment, Optional[Entry], Optional[ChatThread]]:
    """Load an attachment the caller may read, with its owning entry or thread.

    Gated on ``entry.read`` of the parent entry for entry-owned attachments,
    or thread ownership for chat-owned attachments. Unknown, hidden and
    other users' chat attachments all read as "not found". Shared by every
    agent-facing attachment read (text, transcription).
    """
    attachment = await Attachment.find_one({"id": attachment_id})
    if not attachment or not is_visible_to_user(attachment):
        raise ValueError("Attachment not found")

    owners = await attachment.nodes(edge=["HAS_ATTACHMENT"], direction="in")
    entry_parents = [e for e in owners if isinstance(e, Entry)]
    if entry_parents:
        await _require_entry_read(user_id, entry_parents[0])
        return attachment, entry_parents[0], None
    thread_parents = [e for e in owners if isinstance(e, ChatThread)]
    if not thread_parents:
        raise ValueError("Attachment not linked to any entry")
    if thread_parents[0].user_id != user_id:
        raise ValueError("Attachment not found")
    return attachment, None, thread_parents[0]


async def get_attachment_text(
    user_id: str,
    attachment_id: str,
    max_chars: Optional[int] = None,
) -> Dict[str, Any]:
    """Return an attachment's extracted text, capped for the model context.

    Gated on ``entry.read`` of the parent entry for entry-owned attachments,
    or thread ownership for chat-owned attachments (Slice B — general file
    persistence). The returned ``text`` is UNTRUSTED content
    (``content_untrusted: true``) — the agent treats it as data to
    summarize/file, never as instructions (anti-injection).
    """
    cap = max_chars or settings.ATTACHMENT_AGENT_TEXT_MAX_CHARS
    attachment, _, _ = await resolve_readable_attachment(user_id, attachment_id)

    full = getattr(attachment, "extracted_text", "") or ""
    origin = "extracted_text"
    if attachment.mime_type.startswith("image/"):
        from app.services.attachment_metadata.observations import image_description_text

        full = image_description_text(attachment)
        origin = "generated_description" if full else "file_metadata"
    metadata = _agent_metadata(attachment)
    truncated = len(full) > cap
    text = full[:cap]

    return {
        "attachment_id": attachment.id,
        "filename": getattr(attachment, "filename", "") or "",
        "mime_type": getattr(attachment, "mime_type", "") or "",
        "metadata_status": getattr(attachment, "metadata_status", "") or "",
        "page_count": getattr(attachment, "page_count", None),
        "metadata": metadata,
        "text": text,
        "char_count": len(text),
        "truncated": truncated,
        "content_untrusted": True,
        "content_origin": origin,
    }


def _validate_sandbox_relative_path(path: str) -> str:
    """Reject absolute paths and ``..`` segments (PC-7)."""
    raw = (path or "").strip().replace("\\", "/")
    if not raw or raw.startswith("/") or ".." in raw.split("/"):
        raise ValueError("sandbox_path must be a relative path without '..' segments")
    return raw


def _read_sandbox_file(user_id: str, sandbox_path: str) -> bytes:
    """Read a bounded caller-owned file without following path symlinks.

    The configured root is trusted, but every component below it is untrusted.
    Open directories relative to already-open descriptors so renames or symlink
    swaps cannot redirect a file read outside the caller's slice.
    """
    rel = _validate_sandbox_relative_path(sandbox_path)
    if not user_id or user_id in {".", ".."} or "/" in user_id or "\\" in user_id:
        raise ValueError("Invalid sandbox owner")
    root = (os.environ.get("INTEGRAL_SANDBOX_ROOT") or "").strip()
    if not root:
        raise ValueError("Sandbox file bridge is not configured")
    parts = [user_id, *Path(rel).parts]
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Invalid sandbox path")
    descriptors = []
    try:
        fd = os.open(Path(root).resolve(strict=True), os.O_RDONLY | os.O_DIRECTORY)
        descriptors.append(fd)
        for part in parts[:-1]:
            fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            descriptors.append(fd)
        file_fd = os.open(
            parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd
        )
        descriptors.append(file_fd)
        info = os.fstat(file_fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("Sandbox source is not a regular file")
        maximum = settings.ATTACHMENT_MAX_UPLOAD_BYTES
        if info.st_size > maximum:
            raise ValueError("Sandbox file exceeds the attachment size limit")
        with os.fdopen(os.dup(file_fd), "rb") as source:
            content = source.read(maximum + 1)
        if len(content) > maximum:
            raise ValueError("Sandbox file exceeds the attachment size limit")
        return content
    except OSError as exc:
        raise ValueError(
            "Sandbox file is unavailable or cannot be safely read"
        ) from exc
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


async def inspect_sandbox_file(user_id: str, sandbox_path: str) -> Dict[str, Any]:
    """Identify the exact bytes and prepare a bounded plain-text preview."""
    content = await asyncio.to_thread(_read_sandbox_file, user_id, sandbox_path)
    result: Dict[str, Any] = {
        "sha256": hashlib.sha256(content).hexdigest(),
        "size": len(content),
        "preview": {"available": False},
    }
    if Path(sandbox_path).suffix.lower() in {".txt", ".md", ".csv", ".tsv", ".json"}:
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            return result
        # Treat control-rich content as binary, not a safe text preview.
        if any(ord(ch) < 32 and ch not in "\n\r\t" for ch in text):
            return result
        max_chars = 12_000
        result["preview"] = {
            "available": True,
            "text": text[:max_chars],
            "complete": len(text) <= max_chars,
        }
    return result


async def attach_sandbox_file_to_entry(
    user_id: str,
    entry_id: str,
    sandbox_path: str,
    expected_sha256: str = "",
) -> Dict[str, Any]:
    """Attach a sandbox-produced file to an entry.

    Reads bytes from ``INTEGRAL_SANDBOX_ROOT/<user_id>/<sandbox_path>`` when that
    root is configured (co-located agent runtime). Returns a structured error when
    the bridge is unavailable or the file is missing.
    """

    from app.models.edges import HAS_ATTACHMENT
    from app.models.nodes import Attachment
    from app.schemas.policy import Resource, Subject
    from app.services.attachment_storage import get_attachment_storage_service
    from app.services.policy_engine import evaluate as policy_evaluate

    rel = _validate_sandbox_relative_path(sandbox_path)
    entry = await Entry.get(entry_id)
    if not entry:
        return {
            "error": True,
            "error_code": "entry_not_found",
            "message": "Entry not found",
        }

    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="entry.update",
        resource=Resource(kind="entry", id=entry.id, scope=f"entry:{entry.id}"),
    )
    if not decision.allowed:
        return {
            "error": True,
            "error_code": "permission_denied",
            "message": "You do not have permission to add attachments to this entry",
        }

    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256 or ""):
        return {
            "error": True,
            "error_code": "file_review_required",
            "message": "Review the file again before attaching it.",
        }
    try:
        content = await asyncio.to_thread(_read_sandbox_file, user_id, rel)
    except ValueError as exc:
        return {
            "error": True,
            "error_code": "sandbox_file_unavailable",
            "message": str(exc),
        }
    if not hmac.compare_digest(hashlib.sha256(content).hexdigest(), expected_sha256):
        return {
            "error": True,
            "error_code": "sandbox_file_changed",
            "message": "The file changed after review. Review it again before attaching it.",
        }
    filename = Path(rel).name
    from app.services.attachment_upload_shared import fallback_mime_from_filename

    mime_type = fallback_mime_from_filename(filename) or "application/octet-stream"
    attachment = await Attachment.create(
        filename=filename,
        mime_type=mime_type,
        size=len(content),
        storage_key="",
        source_type="file",
        external_url="",
        uploaded_by=user_id,
        scan_status="pending",
        metadata_status="pending",
        created_at=utc_now_iso(),
    )
    storage = get_attachment_storage_service()
    try:
        stored = await storage.save_attachment(
            entry_id=entry.id,
            attachment_id=attachment.id,
            filename=filename,
            content=content,
            mime_type=mime_type,
        )
    except Exception as exc:  # noqa: BLE001
        await attachment.delete()
        return {
            "error": True,
            "error_code": "attach_failed",
            "message": str(exc) or "Attachment persist failed",
        }

    attachment.storage_key = str(stored.get("path") or "")
    await attachment.save()
    await entry.connect(
        attachment,
        edge=HAS_ATTACHMENT,
        attached_at=utc_now_iso(),
        attached_by=user_id,
    )
    if attachment.id not in (entry.attachment_ids or []):
        entry.attachment_ids = list(entry.attachment_ids or []) + [attachment.id]
        await entry.save()

    item = await export_node(attachment)
    return {"attachment": item, "entry_id": entry_id, "sandbox_path": rel}


async def attach_image_bytes_to_entry(
    user_id: str,
    entry_id: str,
    filename: str,
    mime_type: str,
    content: bytes,
) -> Dict[str, Any]:
    """Materialize an uploaded chat image (raw bytes) into an entry attachment.

    On-demand counterpart to the file path: composer images are retained as
    base64 on the chat message, not written to attachment storage on upload.
    When the user asks to attach one, this writes the bytes to storage and
    wires the ``HAS_ATTACHMENT`` edge — so storage is only consumed on the
    approved attach. Mirrors ``attach_sandbox_file_to_entry``.
    """

    from app.models.edges import HAS_ATTACHMENT
    from app.models.nodes import Attachment
    from app.schemas.policy import Resource, Subject
    from app.services.attachment_storage import get_attachment_storage_service

    if not content:
        return {
            "error": True,
            "error_code": "image_bytes_missing",
            "message": "Uploaded image has no retained bytes to attach",
        }

    entry = await Entry.get(entry_id)
    if not entry:
        return {
            "error": True,
            "error_code": "entry_not_found",
            "message": "Entry not found",
        }

    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="entry.update",
        resource=Resource(kind="entry", id=entry.id, scope=f"entry:{entry.id}"),
    )
    if not decision.allowed:
        return {
            "error": True,
            "error_code": "permission_denied",
            "message": "You do not have permission to add attachments to this entry",
        }

    attachment = await Attachment.create(
        filename=filename,
        mime_type=mime_type or "image/png",
        size=len(content),
        storage_key="",
        source_type="file",
        external_url="",
        uploaded_by=user_id,
        scan_status="pending",
        metadata_status="pending",
        created_at=utc_now_iso(),
    )
    storage = get_attachment_storage_service()
    try:
        stored = await storage.save_attachment(
            entry_id=entry.id,
            attachment_id=attachment.id,
            filename=filename,
            content=content,
            mime_type=mime_type or "image/png",
        )
    except Exception as exc:  # noqa: BLE001
        await attachment.delete()
        return {
            "error": True,
            "error_code": "attach_failed",
            "message": str(exc) or "Attachment persist failed",
        }

    attachment.storage_key = str(stored.get("path") or "")
    await attachment.save()
    await entry.connect(
        attachment,
        edge=HAS_ATTACHMENT,
        attached_at=utc_now_iso(),
        attached_by=user_id,
    )
    if attachment.id not in (entry.attachment_ids or []):
        entry.attachment_ids = list(entry.attachment_ids or []) + [attachment.id]
        await entry.save()

    item = await export_node(attachment)
    return {"attachment": item, "entry_id": entry.id}


async def validate_chat_attachment_source(
    *,
    user_id: str,
    attachment_id: str,
    thread_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
) -> tuple[Any, Any, Optional[Dict[str, Any]]]:
    """Validate an uploaded source independently of a future batch target."""
    from app.models.nodes import ChatThread

    attachment = await Attachment.get(attachment_id)
    if not attachment or not is_visible_to_user(attachment):
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "attachment_not_found",
                "message": "Attachment not found",
            },
        )
    if getattr(attachment, "owner_kind", "entry") != "chat":
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "not_chat_owned",
                "message": (
                    "Only files uploaded in this chat can be attached this way"
                ),
            },
        )

    owners = await attachment.nodes(
        edge=["HAS_ATTACHMENT"], node=["ChatThread"], direction="in", limit=2
    )
    thread = next((o for o in owners if isinstance(o, ChatThread)), None)
    if (
        thread is None
        or thread.user_id != user_id
        or (thread_id is not None and thread.id != thread_id)
        or (workspace_id is not None and thread.workspace_id != workspace_id)
    ):
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "permission_denied",
                "message": "You do not own this file",
            },
        )

    return attachment, thread, None


async def validate_chat_attachment_for_entry(
    *, user_id: str, attachment_id: str, entry_id: str
) -> tuple[Any, Any, Optional[Dict[str, Any]]]:
    """Shared read-only preflight; execution repeats it at the write boundary."""
    from app.services.agent_scope import active_workspace_id, current_chat_thread_id

    attachment, _thread, error = await validate_chat_attachment_source(
        user_id=user_id,
        attachment_id=attachment_id,
        workspace_id=active_workspace_id(),
        thread_id=current_chat_thread_id.get(),
    )
    if error:
        return None, None, error
    entry = await Entry.get(entry_id)
    if not entry:
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "entry_not_found",
                "message": "Entry not found",
            },
        )

    decision = await policy_evaluate(
        subject=Subject(kind="human", id=user_id),
        action="entry.update",
        resource=Resource(kind="entry", id=entry.id, scope=f"entry:{entry.id}"),
    )
    if not decision.allowed:
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "permission_denied",
                "message": "You do not have permission to add attachments to this entry",
            },
        )

    from app.config import settings

    if (
        str(getattr(attachment, "mime_type", "") or "").lower().startswith("image/")
        and int(getattr(attachment, "size", 0) or 0)
        > settings.ATTACHMENT_MAX_IMAGE_BYTES
    ):
        return (
            None,
            None,
            {
                "error": True,
                "error_code": "image_too_large",
                "message": f"Image too large (maximum {settings.ATTACHMENT_MAX_IMAGE_BYTES // (1024 * 1024)} MB).",
            },
        )

    return attachment, entry, None


async def attach_uploaded_file_to_entry(
    user_id: str,
    attachment_id: str,
    entry_id: str,
) -> Dict[str, Any]:
    """File a chat-uploaded attachment (Slice B) into an entry.

    The attachment must be chat-owned (``owner_kind == "chat"``) and belong
    to a thread the caller owns — it already has bytes/scan/metadata from
    the chat-upload pipeline, so this only wires a second ``HAS_ATTACHMENT``
    edge from the target entry (multi-owner, same pattern as the User
    avatar-variant edges) and flips ``owner_kind`` to ``"entry"`` so it
    surfaces as the entry's canonical home. No new bytes are written, so
    workspace storage accounting is untouched.
    """

    from app.services.entry_attachment_filing import file_chat_attachment

    _, _, error = await validate_chat_attachment_for_entry(
        user_id=user_id, attachment_id=attachment_id, entry_id=entry_id
    )
    if error:
        return error
    return await file_chat_attachment(
        user_id=user_id, attachment_id=attachment_id, entry_id=entry_id
    )
